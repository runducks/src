/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hoiuc.template;
//Scr By SHIN
/**
 *
 * @author Admin
 */
public class Itemcay {
    public String name;
    public int x;
    public int y;

    // Constructor cho Itemcay
    public Itemcay(String name, int x, int y) {
        this.name = name;
        this.x = x;
        this.y = y;
    }
}