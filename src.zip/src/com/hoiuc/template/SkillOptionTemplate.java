package com.hoiuc.template;
//Scr By SHIN
import com.hoiuc.assembly.Option;
//Scr By SHIN
import java.util.ArrayList;
//Scr By SHIN
public class SkillOptionTemplate {
    public short skillId;
    public byte point;
    public int level;
    public short manaUse;
    public int coolDown;
    public short dx;
    public short dy;
    public byte maxFight;
    public ArrayList<Option> options;

    public SkillOptionTemplate() {
        this.options = new ArrayList<Option>();
    }
}
