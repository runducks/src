package com.hoiuc.template;
//Scr By SHIN
public class TaskTemplate {
    public short taskId;
    public String name;
    public String detail;
    public String[] subNames;
    public short[] counts;
}
