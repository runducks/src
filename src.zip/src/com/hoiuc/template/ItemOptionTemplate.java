package com.hoiuc.template;
//Scr By SHIN
public class ItemOptionTemplate {
    public int id;
    public String name;
    public byte type;
}
