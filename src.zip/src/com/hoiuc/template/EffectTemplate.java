package com.hoiuc.template;
//Scr By SHIN
import java.util.ArrayList;
//Scr By SHIN
public class EffectTemplate {
    public int id;
    public byte type;
    public String name;
    public short iconId;
    public static ArrayList<EffectTemplate> entrys = new ArrayList();
}
