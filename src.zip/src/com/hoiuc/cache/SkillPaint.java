package com.hoiuc.cache;

public class SkillPaint {

    public int id;
    public int effId;
    public int numEff;
    public SkillInfoPaint[] skillStand;
    public SkillInfoPaint[] skillfly;
}
