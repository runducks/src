package com.hoiuc.cache;

public class SkillOptionTemplates {
    public int id;
    public String name;
}
