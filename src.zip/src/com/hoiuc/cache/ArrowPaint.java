package com.hoiuc.cache;

public class ArrowPaint {
    public short id;
    public short[] imgId = new short[3];
}
