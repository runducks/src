/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hoiuc.cache;

/**
 *
 * @author Rewind
 */
public class PartImage {
    public short id;
    public byte dx;
    public byte dy;
}
