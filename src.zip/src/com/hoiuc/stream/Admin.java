package com.hoiuc.stream;
//Scr By SHIN
import com.hoiuc.assembly.ClanManager;
import com.hoiuc.server.Manager;
import com.hoiuc.server.ShinwaManager;
import com.hoiuc.server.ThienDiaBangManager;
import java.time.LocalTime;
//Scr By SHIN
public class Admin implements Runnable{
    private int timeCount;
    LocalTime time;
    private Server server;
    boolean pause=false;
//Scr By 
    public Admin(int minues, Server server) {
        this.timeCount = minues;
        this.server = server;
        pause=false;
    }
    public Admin(int minues, Server server,boolean pause ,LocalTime time) {
        this.timeCount = minues;
        this.server = server;
        this.time = time;
        this.pause = pause;
    }
//Scr By SHIN
    @Override
    public void run() {
        
        try {
            if(pause) {
                System.out.println("Server sẽ ngưng hoạt động từ " +time.toString() +" trong "+timeCount +" phút!");
                server.pause(time, timeCount); 
                return;
            }
            
            
            while (timeCount > 0) {
                Manager.serverChat("Thông báo bảo trì","Hệ thống sẽ bảo trì sau " + timeCount + " phút nữa. "
                        + "Vui lòng thoát game trước thời gian bảo trì, để tránh mất vật phẩm. Xin cảm ơn!");
                timeCount--;
                Thread.sleep(60000);
            }
            if(timeCount == 0) {
                ClanManager.close();
                ThienDiaBangManager.close();
                ShinwaManager.close();
                this.server.close(100L);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
