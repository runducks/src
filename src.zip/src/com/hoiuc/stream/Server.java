package com.hoiuc.stream;
//Scr By SHIN
import com.hoiuc.assembly.ClanManager;
import com.hoiuc.assembly.Map;
import com.hoiuc.io.SQLManager;
import com.hoiuc.stream.RunTimeServer.*;

import com.hoiuc.io.Util;
import com.hoiuc.server.*;
import com.hoiuc.server.NPCSoxomayman;
import com.hoiuc.template.MapTemplate;
import com.sun.tools.sjavac.server.ServerMain;
//Scr By SHIN
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
//Scr By SHIN
public class Server extends Thread {
	
    private static boolean isPaused = false;
    private static ScheduledExecutorService scheduler;
    private static Server instance = null;
    protected static ServerSocket listenSocket = null;
    public static boolean start = false;
    public static Manager manager;
    public static Menu menu;
    public NPCSoxomayman soxomayman;
    public static Controller serverMessageHandler;
    public static Map[] maps;
    public static Object LOCK_MYSQL = new Object();
    public static boolean running = true;
    public static RunTimeServer runTime = new RunTimeServer();
    public static Shinwa runShinwa = new Shinwa();
    public static ByteArrayOutputStream[] cache = new ByteArrayOutputStream[4];
    public static List<String> nguoiChoiMayMan = new ArrayList<>();
    

    public static int baseId = 0;

    public Server() {
        this.listenSocket = null;
    }

    public static Server gI() {
        if (Server.instance == null) {
            Server.instance = new Server();
            Server.instance.init();
            Rank.init();
            Server.runTime.start();
            Server.runShinwa.start();
        }
        return Server.instance;
    }
    public static void rsS() {
        if (Server.instance != null && Server.runTime  == null ) { 
            Server.runTime = new RunTimeServer();
        } 
        Server.runTime.start(); 
        if(Server.runShinwa != null) {
            
            Server.runShinwa.start();
        }
    }

    private synchronized void init() {
        manager = new Manager();
        menu = new Menu();
        serverMessageHandler = new Controller();
        cache[1] = GameSrc.loadFile("res/cache/map");
        cache[2] = GameSrc.loadFile("res/cache/skill");
        cache[3] = GameSrc.loadFile("res/cache/item");
        this.maps = new Map[MapTemplate.arrTemplate.length];
        short i;
        for (i = 0; i < this.maps.length; ++i) {
            this.maps[i] = new Map(i, null, null, null, null, null,null);
            this.maps[i].start();
        }

    }

    public static void start(boolean running) throws IOException {
        while (true) { 
            try {
                if (!isPaused) {
                    if( gI().getState()!= Thread.State.NEW ) {
                        gI().start(); 
                    }
                    if(listenSocket==null || listenSocket.isClosed()) { 
                         
                        listenSocket = new ServerSocket(Server.manager.post);
                    }
                    System.out.println("Listen port: " + Server.manager.post);
                    RunTimeServer.refreshAllBosses();
                    start = running;
                    
                    while (start && !isPaused) {
                        try {
                            Socket clientSocket = listenSocket.accept();
                            Session conn = new Session(clientSocket, serverMessageHandler);
                            Client.gI().put(conn);
                            conn.run(); 
                        } catch (IOException e) {
                            System.err.println("Từ chối kết nối client: " + e.getMessage());
                        }
                    }
                    
                    System.out.println("Close server!");
                } else { 
                    Thread.sleep(60000); 
                }
            } catch (IOException | InterruptedException e) { 
                System.err.println("Lỗi khi khởi tạo ServerSocket hoặc kết nối: " + e.getMessage());
                if (listenSocket != null && !listenSocket.isClosed()) {
                        try {
                                listenSocket.close(); 
                        } catch (IOException ex) {
                                System.err.println("Lỗi khi đóng ServerSocket: " + ex.getMessage());
                        }
                }
                try {
                        Thread.sleep(10000);
                } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();  
                }

                System.out.println("Đang thử khởi động lại server...");
            }
        }
    }
    

    public static void close(long delayKick) throws InterruptedException {
        if (Server.start) {
            Server.start = false;
            try {
                Server.listenSocket.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            synchronized (Server.LOCK_MYSQL) {
                Server.LOCK_MYSQL.wait(delayKick);
            }
            synchronized (Server.LOCK_MYSQL) {
                ClanManager.close();
                ShinwaManager.close();
                ThienDiaBangManager.close();
                Client.gI().Clear();
            }

            Client.gI().close();
            Server.manager.close();
            Server.manager = null;
            Server.maps = null;
            Server.cache = null;
            Server.serverMessageHandler = null;
            Server.runTime = null;
            Server.runShinwa = null;
            Server.LOCK_MYSQL = null;
            SQLManager.close();
            System.out.println("BaoTriHoanTat");
            System.gc();
        }
    }
    public static boolean isRefBoss1;
    public static boolean isRefBoss2;
    public static boolean isRefBoss3;
    public static boolean isRefBoss4;
    public static boolean isRefBos5s;
    public static void pause(LocalTime pauseTime, int pauseDuration) {
        if (scheduler != null) {
            scheduler.shutdownNow();
            System.out.println("Đang kiểm tra và xóa bỏ lịch cũ...");
        }
        scheduler = Executors.newScheduledThreadPool(1);
        
        LocalTime now = LocalTime.now();
        long initialDelay;
        
        if (pauseTime.isAfter(now)) {
            initialDelay = calculateDelay(now, pauseTime);
        } else {
            initialDelay = calculateDelay(now, pauseTime) + 24 * 60 * 60 * 1000;
        }
        
        scheduler.scheduleAtFixedRate(() -> {
            try {
                System.out.println("Dang du`ng.... " );
                pauseServer(pauseDuration);
                System.out.println("Đa cai dat du`ng.... " );
            } catch (Exception e) {
                System.out.println("Lỗi pause server: " + e.getMessage());
            }
        }, initialDelay, 24 * 60 * 60 * 1000, TimeUnit.MILLISECONDS);
    }

    private static long calculateDelay(LocalTime current, LocalTime target) {
        long currentMillis = current.toSecondOfDay() * 1000;
        long targetMillis = target.toSecondOfDay() * 1000;
        return targetMillis - currentMillis;
    }

    private static void pauseServer(int pauseDuration) {
    try {
        System.out.println("Server đang tạm dừng để bảo trì lúc: " + LocalTime.now());
        
        if (listenSocket != null && !listenSocket.isClosed()) {
            try {
                listenSocket.close();
                System.out.println("Socket đã đóng thành công.");
            } catch (IOException e) {
                System.err.println("Lỗi khi đóng socket: " + e.getMessage());
            }
        }
        
        Client.gI().Clear();
        System.out.println("Client đã được dọn dẹp.");

        ClanManager.close();
        ShinwaManager.close();
        ThienDiaBangManager.close();
        SQLManager.close();
        System.out.println("Tất cả dịch vụ đã được đóng.");
        
        new Thread(() -> {
            try {
                System.out.println("Server sẽ khởi động lại sau: " + pauseDuration + " phút.");
                Thread.sleep(pauseDuration * 60 * 1000); // pauseDuration (phút) -> ms
                System.out.println("Khởi động lại server...");
                restartServer();
            } catch (InterruptedException e) {
                System.err.println("Lỗi trong quá trình chờ khởi động lại: " + e.getMessage());
            }
        }).start();

        System.exit(0);
    } catch (Exception e) {
        System.err.println("Lỗi khi thực hiện bảo trì server: " + e.getMessage());
    }
}
    private static void restartServer() {
    try {
        String os = System.getProperty("os.name").toLowerCase();
        String command;

        if (os.contains("win")) {
            // Đường dẫn tập lệnh khởi động cho Windows
            command = "cmd /c start \"\" \"C:\\Users\\Admin\\Desktop\\OZAWA\\OZAWASHIN\\OZAWASHIN\\OZAWASHIN\\SHIN\\OZAWA[VIP++]\\OZAWASHIN\\run.bat\"";
        } else {
            // Đường dẫn tập lệnh khởi động cho Linux/Unix (nếu có)
            command = "./run_server.sh";
        }

        // Khởi chạy quá trình
        ProcessBuilder pb = new ProcessBuilder(command);
        pb.start();

        System.out.println("Server đã được gửi lệnh khởi động lại.");

      
        Server.pauseServer(1); // 30 phút

    } catch (IOException e) {
        System.err.println("Lỗi khi khởi động lại server: " + e.getMessage());
    }
}

    private static void resumeServer() {
        try { 
            isPaused = false; 
            System.out.println("Server đã được khôi phục lúc: " + LocalTime.now()); 
            isRefBoss1 = true;
            isRefBoss2 = true;
            isRefBoss3 = true;
            isRefBoss4 = true;
            
            start(true);
        } catch (IOException e) {
            System.err.println("Lỗi khi khôi phục server: " + e.getMessage());
        }
    }
    

    
}
