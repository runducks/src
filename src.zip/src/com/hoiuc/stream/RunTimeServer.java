package com.hoiuc.stream;

import com.hoiuc.assembly.ClanManager;
import com.hoiuc.assembly.Map;
import com.hoiuc.io.Util;
import com.hoiuc.server.Manager;
import com.hoiuc.server.Service;
import com.hoiuc.server.ThienDiaBangManager;
import com.hoiuc.io.Message;

import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.StringJoiner;

public class RunTimeServer extends Thread {

    private static int[] hoursAutoSaveData = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24};
    private static int[] hoursRefreshBoss = new int[]{8, 12, 14, 20, 22};
    private static int[] hoursRefreshBossVDMQ = new int[]{1, 3, 9, 11, 13, 17, 19, 21, 23};
    private static int[] hoursRefreshBossTG = new int[]{9, 12, 20, 21, 22};
    private static int[] hoursRefreshBossNK = new int[]{9, 12, 20, 21, 22};
    private static boolean[] isRefreshBoss = new boolean[]{false, false, false, false, false, false, false, false};
    private static boolean[] isRefreshBossTG = new boolean[]{false, false, false, false, false};
    private static boolean[] isRefreshBossNK = new boolean[]{false};
    private static boolean[] isRefreshBossVDMQ = new boolean[]{false, false, false, false, false, false, false, false, false, false, false, false};
    private static short[] mapBossVDMQ = new short[]{141, 142, 143};
    private static short[] mapBossNK = new short[]{23};
    private static short[] mapBossTG = new short[]{56};
    private static short[] mapBoss45 = new short[]{14, 15, 16, 34, 35, 52, 68};
    private static short[] mapBoss55 = new short[]{44, 67};
    private static short[] mapBoss65 = new short[]{24, 41, 45, 59};
    private static short[] mapBoss75 = new short[]{18, 36, 54};
    private static short[] mapBossVIP = new short[]{5};
    private static int[] hoursRefreshBossVIP = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22};
    private static boolean[] isRefreshBossVIP = new boolean[]{false, false, false, false, false, false, false, false, false, false, false, false};
    private static final short[] mapBossSKTet = new short[]{2, 28, 39, 23};
    private static final int[] hoursRefreshBossSKTet = new int[]{1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23};
    private static final boolean[] isRefreshBossSKTet = new boolean[]{false, false, false, false, false, false, false, false, false, false, false, false};
    public String[] CHATNPC = new String[]{"Học cho lắm tắm cũng xà bông", " Một phụ nữ toàn diện là: Sáng diện, trưa diện, chiều diện, tối diện…", "Giang hồ hiểm ác, không bằng mạng lag thất thường."};
    public String[] CHATNPCTAIXIU = new String[]{"Được ăn cả, ngã ... ở đâu ta gấp đôi ở đó", "Còn thở là còn gỡ", "Lô đề cờ bạc muôn đời thịnh"};
    public String[] CHATNPC0 = new String[]{"Chỉ tay lên trời hận đời vô đối, chỉ tay xuống gối, đi ngủ cho rồi.", " Ta về ta tắm ao ta dù trong dù đục cũng là cái ao.", "Trăm năm bia đá cũng mòn , bia chai cũng bể , chỉ còn bia…ôm.."};
    public String[] CHATNPC1 = new String[]{"Tôi chọn lạc quan..!!", "Nghệ thuật che lấp sự bất tài cũng đòi hỏi không ít tài năng.", "Thà sống hèn còn hơn chết dại."};
    public String[] CHATNPC2 = new String[]{"Bia độc hơn rượu , bằng chứng trên thế giới chỉ có ” mộ bia ” mà không có ” mộ rượu “", "Em bảo anh bỏ rượu…anh bỏ rượu. Em bảo anh bỏ thuốc…anh bỏ thuốc…Em bảo anh bỏ game…anh bỏ em.", "Thiếu nữ là chữ viết tắt của thiếu…nữ tính."};
    public String[] CHATNPC3 = new String[]{"” Quân với dân như cá với nước ” Nước thì nuôi sống cá còn cá thì ị vào nước.", "Trăm lời anh nói không bằng làn khói a còng SH", "Rõ ràng là trên đời này không có gì là rõ ràng."};
    public String[] CHATNPC4 = new String[]{"Vì tao chắc chắn là trên đời này không có gì là chắc chắn.", "Cách tốt nhất để giữ lời hứa là đừng hứa gì cả.", "Tôi đã nói “không” với ma túy, nhưng tụi nó không chịu nghe."};
    public String[] CHATNPC5 = new String[]{" Luôn luôn nhớ rằng bạn là duy nhất…giống như những người khác!", " Luôn cố gắng khiêm tốn, và hãy lấy làm…tự hào về điều đó", " Khổ quá, sướng không chịu nổi"};
    public String[] CHATNPC6 = new String[]{"Đừng tự ti vì mình nghèo mà vẫn giỏi mà hãy tự hỏi tại sao mình giỏi mà mình vẫn nghèo.!", "Có cái nắng, có cái gió nhưng thiếu…cái đó thì ta xa nhau, người ơiiiiiiiiii", "Tự hào là hai bàn tay trắng lập nên…vô số nợ.Tự hào là hai bàn tay trắng lập nên…vô số nợ."};
    public String[] CHATNPC7 = new String[]{"Khai thông kinh mạch để tăng sức mạnh?!", "kiếm đủ tiền và exp kinh mạch thì đến gặp tao", "Cấp kinh mạch càng cao lực chiến đấu càng cao"};
    public String[] CHATNPC8 = new String[]{"Trường của ta dành cho những người tính nóng như kem!", "Đưa phong bì đây ta cho vào học", "Nhớ gặp admin phải chào nghe chưa?"};
    public String[] CHATNPC9 = new String[]{"Trường của ta danh cho những người lạnh lùng kool ngầu!", "Đưa phong bì đây ta cho vào học", "Nhớ gặp admin phải chào nghe chưa?"};
    public String[] CHATNPC10 = new String[]{"Trường của ta danh cho những người thích chém gió!", "Đưa phong bì đây ta cho vào học", "Nhớ gặp admin phải chào nghe chưa?"};
    public String[] CHATNPC11 = new String[]{"Chơi chẵn lẻ coin đi con ơi!", "Cờ bạc may rủi,thua không được nóng nhé!", "Nạp coin , đổi coin thì liên hệ admin. "};
    public String[] CHATNPC12 = new String[]{"Điều tuyệt đối nhất chính là tất cả chỉ là tương đối", " Nghèo mà sài sang để sau này có giàu bớt bỡ ngỡ.", "Bản chất xấu xa nhưng do dòng đời xô đẩy trở thành người lương thiện."};
    public String[] CHATNPC13 = new String[]{"Ta là Tề Thiên đại Thánh,500 năm trước từng đại náo thiên cung!", "Đem đồ tốt đến đây ta đổi đồ cho", "ngươi có thấy sư phụ của ta ở đâu không?"};
    public String[] CHATNPCshinwa = new String[]{"Mua bán gì thế? Chất cấm là tao đấm vỡ mồm đấy!", "Mua bán sòng phẳng nhé,bug là bay acc", "nay có vẻ vắng nhỉ"};
    public String[] CHATNPCokanechane = new String[]{"Nhận quà thăng cấp ở chỗ ta nhé!", "Lại đây ta phát áo choàng yoroi cho nè", "Sự cố gắng của các ngươi ta chấp nhận"};
    public String[] CHATNPCrikudou = new String[]{"Chăm chỉ làm nhiệm vụ để nhận điểm hoạt động nhé!", "random lượng mỗi nhiệm vụ từ 100 đến 300 lượng", "Làm nhiệm vụ hàng ngày và tà thú nhé"};
    public String[] CHATNPCgosho = new String[]{"Câu nói “không” vẫn là biện pháp tránh thai hiệu quả nhất.", "Phụ nữ thích mua đồ đẹp để con trai ngắm…Con trai thích ngắm con gái không mặc đồ…Vậy con gái mua sắm làm cái gì ???", "Đi một ngày đàng…mất 10.000 tiền cơm"};
    public String[] CHATNPCminuong = new String[]{"Trái tim em chỉ 2 lần mở cửa. Đón anh vào và tống cổ anh ra.", " học dốt nói ngông , đi chơi lông bông , mồm thì khoác lác , mua sắm nát đời , mà câu nào nói ra cũng lời lời đạo lý", "Trúc xinh trúc mọc đầu đình…Em xinh em đứng một mình kệ em."};
    public String[] CHATNPCthanhgiong = new String[]{"ta chỉ cần 1 khóm tre là có thể đánh đuổi giặc ngoại xâm!", "Đem đến cho ta 1 con ngựa sắt, 1 áo giáp sắt, 1 cây gậy sắt nào", "Lấy tín vật để làm nhiệm vụ truyền tin"};
    public String[] CHATNPCtiennu = new String[]{"Đừng bao giờ đua đòi bồ bịch khi mà không ai yêu bạn cả !", "Con gái cũng như một quyển sách…Đừng mong đọc một ngày là hiểu được.", "Tuy mình không đẹp…nhưng còn lâu mới xấu."};
    public String[] CHATNPCcauca = new String[]{"Nhanh tay câu cá rinh quà liền tay nào !", "Con cá cũng là con người mà.", "Tuy mình không đẹp…nhưng còn lâu mới xấu."};
    public String[] CHATNPCsoxo = new String[]{"Sau 6h30 chưa biết ai giàu hơn ai đâu!", "Vận may chỉ đến với những người may mắn ", "Chủ nhật hàng tuần hãy liên hệ ADMIN để tiến hành event sổ xố nhé !"};
    public String[] CHATNPCcasino = new String[]{"Nhà ta 3 đời đều bịp", "Các ngươi còn non và xanh lắm.", "Đôi khi ranh giới giữa cô đơn và hanh phúc gói gọn trong 2 từ tài và xỉu."};
    public String[] CHATNPCanxin = new String[]{"Lạy ông đi qua lạy bà đi lại hãy rủ lòng thương bố thí cho con xin ít", "Người tốt luôn luôn ở xung quanh chúng ta"};

    public void close() {
        this.close();
    }

    @Override
    public void run() {
        System.out.println("---Load map---");
        try {
            ClanManager clan;
            int i;
            Calendar rightNow;
            int hour;
            int min;
            int sec;
            int j;
            byte k;
            Map map;
            System.out.println("---Load map--- Server is:" + Server.running);
            while (Server.running) {
                synchronized (ClanManager.entrys) {
                    for (i = ClanManager.entrys.size() - 1; i >= 0; --i) {
                        if (ClanManager.entrys.get(i) != null) {
                            clan = ClanManager.entrys.get(i);
                            if (!Util.isSameWeek(Date.from(Instant.now()), Util.getDate(clan.week))) {
                                clan.payfeesClan();
                            }
                        }
                    }
                }

                synchronized (ThienDiaBangManager.thienDiaBangManager) {
                    if (ThienDiaBangManager.thienDiaBangManager[0] != null) {
                        if (!Util.isSameWeek(Date.from(Instant.now()), Util.getDate2(ThienDiaBangManager.thienDiaBangManager[0].getWeek()))) {
                            ThienDiaBangManager.register = false;
                            ThienDiaBangManager.resetThienDiaBang();
                        }
                    }
                }

                rightNow = Calendar.getInstance();
                hour = rightNow.get(Calendar.HOUR_OF_DAY);
                min = rightNow.get(12);
                sec = rightNow.get(13);

                if (hour % 24 == 0 && min == 0 && sec == 0) {
                    if (ChienTruong.chienTruong != null) {
                        ChienTruong.chienTruong.finish();
                    }
                    ChienTruong.chienTruong30 = false;
                    ChienTruong.chienTruong50 = false;
                    ChienTruong.finish = false;
                    ChienTruong.start = false;
                    ChienTruong.pointHacGia = 0;
                    ChienTruong.pointBachGia = 0;
                    ChienTruong.pheWin = -1;
                    ChienTruong.bxhCT.clear();
                    ChienTruong.chienTruong = null;
                }

                if ((sec % 1 == 0 || sec == 0)) {
                    try {
                        //                       if ((Server.manager.taixiu[0]).start == true && Server.manager.taixiu[0].totaltai >= 1  ) {
                        if ((Server.manager.taixiu[0]).start == true) {
                            Server.manager.taixiu[0].Start();
                        } else {
                            Server.manager.taixiu[0].Wait();
                        }
                    } catch (Exception e) {
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(33);//thay id npc
                        String chat = CHATNPCtiennu[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(53);//thay id npc
                        String chat = CHATNPCthanhgiong[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(36);//thay id npc
                        String chat = CHATNPCminuong[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(26);//thay id npc
                        String chat = CHATNPCgosho[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(65);//thay id npc
                        String chat = CHATNPCanxin[(int) Util.nextInt(0, 1)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(25);//thay id npc
                        String chat = CHATNPCrikudou[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(24);//thay id npc
                        String chat = CHATNPCokanechane[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(28);//thay id npc
                        String chat = CHATNPCshinwa[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(12);//thay id npc
                        String chat = CHATNPC[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(0);//thay id npc
                        String chat = CHATNPC0[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(1);//thay id npc
                        String chat = CHATNPC1[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(2);//thay id npc
                        String chat = CHATNPC2[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(3);//thay id npc
                        String chat = CHATNPC3[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(5);//thay id npc

                        String chat = CHATNPC4[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(18);//thay id npc

                        String chat = CHATNPCTAIXIU[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(6);//thay id npc

                        String chat = CHATNPC5[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(7);//thay id npc

                        String chat = CHATNPC6[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(9);//thay id npc

                        String chat = CHATNPC8[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(10);//thay id npc

                        String chat = CHATNPC9[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(59);//thay id npc

                        String chat = CHATNPCcauca[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(50);//thay id npc

                        String chat = CHATNPCsoxo[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(19);//thay id npc

                        String chat = CHATNPCcasino[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(11);//thay id npc

                        String chat = CHATNPC10[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(19);//thay id npc

                        String chat = CHATNPC11[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(44);//thay id npc

                        String chat = CHATNPC7[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (sec % 5 == 0) {
                    Message m = null;
                    try {
                        m = new Message(38);
                        m.writer().writeShort(41);//thay id npc

                        String chat = CHATNPC13[(int) Util.nextInt(0, 2)];
                        m.writer().writeUTF(chat);
                        m.writer().flush();
                        Client.gI().NinjaMessage(m);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (hour % 23 == 0 && min >= 44) {
                    ThienDiaBangManager.register = false;
                }
                if (hour % 24 == 0 && min >= 5) {
                    ThienDiaBangManager.register = true;
                }

                if (ChienTruong.chienTruong != null) {
                    if (ChienTruong.bxhCT.size() > 0) {
                        ChienTruong.bxhCT = ChienTruong.sortBXH(ChienTruong.bxhCT);
                        Service.updateCT();
                    }
                }

                if (hour == 19 && min == 30 && sec == 0) {
                    if (ChienTruong.chienTruong != null) {
                        ChienTruong.chienTruong.finish();
                    }
                    if (ChienTruong.chienTruong == null) {
                        Manager.serverChat("Server", "Chiến trường dưới 2 tỷ dame đã mở báo danh, hãy nhanh chân đến báo danh chuẩn bị chiến đấu.");
                        ChienTruong.chienTruong30 = true;
                        ChienTruong.chienTruong50 = false;
                        ChienTruong.chienTruong = new ChienTruong();
                        ChienTruong.finish = false;
                        ChienTruong.start = false;
                        ChienTruong.pointHacGia = 0;
                        ChienTruong.pointBachGia = 0;
                        ChienTruong.pheWin = -1;
                        ChienTruong.bxhCT.clear();
                    }
                }

                if (ChienTruong.chienTruong != null && hour == 19 && min == 40 && sec == 0) {
                    ChienTruong.start = true;
                }

                if (ChienTruong.chienTruong != null && hour == 20 && min == 40 && sec == 0 && ChienTruong.start) {
                    ChienTruong.chienTruong.finish();
                }

                if (hour == 21 && min == 0 && sec == 0) {
                    if (ChienTruong.chienTruong != null) {
                        ChienTruong.chienTruong.finish();
                    }
                    if (ChienTruong.chienTruong == null) {
                        Manager.serverChat("Server", "Chiến trường Trên 2 tỷ dame đã mở báo danh, hãy nhanh chân đến báo danh chuẩn bị chiến đấu.");
                        ChienTruong.chienTruong50 = true;
                        ChienTruong.chienTruong30 = false;
                        ChienTruong.chienTruong = new ChienTruong();
                        ChienTruong.finish = false;
                        ChienTruong.start = false;
                        ChienTruong.pointHacGia = 0;
                        ChienTruong.pointBachGia = 0;
                        ChienTruong.pheWin = -1;
                        ChienTruong.bxhCT.clear();
                    }
                }

                if (ChienTruong.chienTruong != null && hour == 21 && min == 10 && sec == 0) {
                    ChienTruong.start = true;
                }

                if (ChienTruong.chienTruong != null && hour == 22 && min == 10 && sec == 0 && ChienTruong.start) {
                    ChienTruong.chienTruong.finish();
                }

//        Chào mừng các bạn đến với NSO OZAWA
                if ((hour == 1 || hour == 2 || hour == 3 || hour == 4 || hour == 5 || hour == 6 || hour == 7 || hour == 8 || hour == 9 || hour == 10 || hour == 11 || hour == 12 || hour == 13 || hour == 14 || hour == 15 || hour == 16 || hour == 17 || hour == 18 || hour == 19 || hour == 20 || hour == 21 || hour == 22 || hour == 23 || hour == 24) && sec == 0) {
                    Manager.serverChat("Server", "Chào mừng bạn đến với NSO LOVE, Tích Cực Quay Tay Vận May Sẽ Tới!");
                    Manager.serverChat("ADMIN", "Mua đồ liên hệ ADMIN zalo : 0879155494!");
                    SaveData saveData = new SaveData();
                    Thread t1 = new Thread(saveData);
                    t1.start();
                    if (!Manager.isSaveData) {
                        t1 = null;
                        saveData = null;
                    }
                }

                for (j = 0; j < this.hoursRefreshBossTG.length; ++j) {
                    if (this.hoursRefreshBossTG[j] == hour || Server.isRefBoss1) {
                        if (!this.isRefreshBossTG[j] || Server.isRefBoss1) {
                            String textchat = " BOSS đã xuất hiện tại:";
                            for (k = 0; k < this.mapBossTG.length; ++k) {
                                map = Manager.getMapid(this.mapBossTG[k]);
                                if (map != null) {
                                    map.refreshBoss((int) Util.nextInt(15, 28));
                                    if (k == 0) {
                                        textchat = textchat + " " + map.template.name;
                                    } else {
                                        textchat = textchat + ", " + map.template.name;
                                    }
                                    this.isRefreshBossTG[j] = true;
                                    Server.isRefBoss1 = false;
                                }
                            }
                            Manager.chatKTG(textchat);
                        }
                    } else {
                        this.isRefreshBossTG[j] = false;
                    }
                }
                
                for (j = 0; j < this.hoursRefreshBossVDMQ.length; ++j) {
                    if (this.hoursRefreshBossVDMQ[j] == hour) {
                        if (!this.isRefreshBossVDMQ[j]) {
                            String textchat = " BOSS đã xuất hiện tại:";
                            for (k = 0; k < this.mapBossVDMQ.length; ++k) {
                                map = Manager.getMapid(this.mapBossVDMQ[k]);
                                if (map != null) {
                                    map.refreshBoss((int) Util.nextInt(15, 28));
                                    if (k == 0) {
                                        textchat = textchat + " " + map.template.name;
                                    } else {
                                        textchat = textchat + ", " + map.template.name;
                                    }
                                    this.isRefreshBossVDMQ[j] = true;
                                }
                            }
                            Manager.chatKTG(textchat);
                        }
                    } else {
                        this.isRefreshBossVDMQ[j] = false;
                    }
                }
                for (j = 0; j < this.hoursRefreshBoss.length; ++j) {
                    if (this.hoursRefreshBoss[j] == hour || Server.isRefBoss3) {
                        if (!this.isRefreshBoss[j] || Server.isRefBoss3) {
                            String textchat = " Thần thú đã xuất hiện tại:";
                            for (k = 0; k < (int) Util.nextInt(1, 2); ++k) {
                                map = Manager.getMapid(this.mapBoss75[(int) Util.nextInt(this.mapBoss75.length)]);
                                if (map != null) {
                                    map.refreshBoss((int) Util.nextInt(15, 28));
                                    textchat = textchat + " " + map.template.name;
                                    this.isRefreshBoss[j] = true;
                                    Server.isRefBoss3 = false;
                                }
                            }
                            for (k = 0; k < Util.nextInt(1, 2); ++k) {
                                map = Manager.getMapid(this.mapBoss65[(int) Util.nextInt(this.mapBoss65.length)]);
                                if (map != null) {
                                    map.refreshBoss((int) Util.nextInt(15, 28));
                                    textchat = textchat + ", " + map.template.name;
                                    this.isRefreshBoss[j] = true;
                                }
                            }
                            for (k = 0; k < (int) Util.nextInt(1, 2); ++k) {
                                map = Manager.getMapid(this.mapBoss55[(int) Util.nextInt(this.mapBoss55.length)]);
                                if (map != null) {
                                    map.refreshBoss((int) Util.nextInt(15, 28));
                                    textchat = textchat + ", " + map.template.name;
                                    this.isRefreshBoss[j] = true;
                                }
                            }
                            for (k = 0; k < Util.nextInt(1, 2); ++k) {
                                map = Manager.getMapid(this.mapBoss45[(int) Util.nextInt(this.mapBoss45.length)]);
                                if (map != null) {
                                    map.refreshBoss((int) Util.nextInt(15, 28));
                                    textchat = textchat + ", " + map.template.name;
                                    this.isRefreshBoss[j] = true;
                                }
                            }

                            /* for (byte k = 0; k < Server.mapBossVDMQ.length; ++k) {
                                       Map map = Manager.getMapid(Server.mapBossVDMQ[k]);
                                       if (map != null) {
                                          map.refreshBoss(util.nextInt(15, 30));
                                           textchat = textchat + ", " + map.template.name;
                                            Server.isRefreshBoss[j] = true;
                                        }
                                    }*/
                            Manager.chatKTG(textchat);
                        }
                    } else {
                        this.isRefreshBoss[j] = false;
                    }

                    for (int i1 = 0; i1 < hoursRefreshBossSKTet.length; i1++) {
                        if (hoursRefreshBossSKTet[i1] == hour || Server.isRefBoss4) {
                            if (!isRefreshBossSKTet[i1] || Server.isRefBoss4) {
                                String textchat = " Boss Chuột Canh Tý đã xuất hiện tại";
                                for (byte j1 = 0; j1 < mapBossSKTet.length; j1++) {
                                    map = Manager.getMapid(mapBossSKTet[j1]);
                                    if (map != null) {
                                        map.refreshBossTet((int) Util.nextInt(25, 30));
                                        textchat += ", " + map.template.name;
                                        this.isRefreshBossSKTet[i1] = true;
                                        Server.isRefBoss4 = false;

                                    }
                                }
                                Manager.chatKTG(textchat);
                            }
                        } else {
                            isRefreshBossSKTet[i1] = false;
                        }

                    }
                    if ((hour == 8 && min == 50 || hour == 11 && min == 50 || hour == 19 && min == 50 || hour == 20 && min == 50 || hour == 21 && min == 50)) {
                        Manager.chatKTG("Boss Thế Giới sẽ diễn ra sau 10p nữa, hãy chuẩn bị đến NPC OZAWA để vào!");
                    }

                }

                Thread.sleep(1000L);
            }
            return;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void refreshAllBosses() {
        // Làm mới các boss thông thường
        for (int i = 0; i < isRefreshBoss.length; i++) {
            isRefreshBoss[i] = true; // Đặt trạng thái làm mới
            System.out.println("Boss " + i + " đã được làm mới!");
        }

        // Làm mới boss TG
        for (int i = 0; i < isRefreshBossTG.length; i++) {
            isRefreshBossTG[i] = true;
            System.out.println("Boss TG " + i + " đã được làm mới!");
        }

        // Làm mới boss NK
        for (int i = 0; i < isRefreshBossNK.length; i++) {
            isRefreshBossNK[i] = true;
            System.out.println("Boss NK " + i + " đã được làm mới!");
        }

        // Làm mới boss VDMQ
        for (int i = 0; i < isRefreshBossVDMQ.length; i++) {
            isRefreshBossVDMQ[i] = true;
            System.out.println("Boss VDMQ " + i + " đã được làm mới!");
        }

        // Làm mới boss VIP
        for (int i = 0; i < isRefreshBossVIP.length; i++) {
            isRefreshBossVIP[i] = true;
            System.out.println("Boss VIP " + i + " đã được làm mới!");
        }

        // Làm mới boss sự kiện Tết
        for (int i = 0; i < isRefreshBossSKTet.length; i++) {
            isRefreshBossSKTet[i] = true;
            System.out.println("Boss sự kiện Tết " + i + " đã được làm mới!");
        }

        System.out.println("Toàn bộ boss đã được làm mới!");
    }
}
