package com.hoiuc.server;
//Scr By SHIN
import static com.hoiuc.io.SQLManager.conn;
import com.hoiuc.stream.Server;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Calendar;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.swing.JFrame;
import java.util.logging.Level;
import java.util.logging.Logger;


//Scr By SHIN
public class NinjaSchool {

    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    private static void initializeGUI() {
        // Khởi tạo PanelAdmin và hiển thị nó
        JFrame panelFrame = new JFrame("Panel");
        PanelAdmin panel = new PanelAdmin();
        panel.initializeComponents(); 
        panel.setupLayout();
        ServerSocket listenSocket = null;
        PanelAdmin.start(panelFrame, panel, listenSocket, null);  
    }
 
 

    public static void main(String[] args) {
        // Đảm bảo server được khởi động ngay khi chương trình chạy
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                Server.close(10L);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }));

        // Khởi động server và GUI
        try {
            initializeGUI();
            Server.start(true); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}