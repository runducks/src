/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hoiuc.server;

import History.LichSu;
import com.hoiuc.assembly.ItemName;
import com.hoiuc.assembly.Item;
import com.hoiuc.assembly.Language;
import com.hoiuc.assembly.Map;
import com.hoiuc.assembly.Player;
import com.hoiuc.assembly.TileMap;
import com.hoiuc.server.Manager;
import com.hoiuc.server.Rank;
import com.hoiuc.server.Service;
import com.hoiuc.stream.Server;
import com.hoiuc.template.ItemTemplate;
import java.util.Calendar;

/**
 *
 * @author Administrator
 */
public class Vip {

    public static void showVipOptions(Player p, short npcid) {
        String message = "Bạn có thể mua các gói VIP sau:\n";
        message += "1. VIP3 - 300,000 ATM\n";
        message += "2. VIP4 - 500,000 ATM\n";
        message += "3. VIP5 - 1,000,000 ATM\n";
        message += "4. VIP20 - 2,000,000 ATM\n";
        message += "5. VIP100 - 10,000,000 ATM\n";
        Service.chatNPC(p, npcid, message); // Sử dụng npcid trực tiếp
    }

    public static void MenuVip(Player p, byte npcid, byte menuId, byte b3) {
        short[] nam = {712, 713, 746, 747, 748, 749, 750, 751, 752};
        short[] nu = {715, 716, 753, 754, 755, 756, 757, 758, 759};
        switch (menuId) {
            case 0: {
                if (p.c.isNhanban) {
                    Service.chatNPC(p, (short) npcid, Language.NOT_FOR_PHAN_THAN);
                    return;
                }
                if (p.c.nhanqua == 1) {
                    Service.chatNPC(p, (short) npcid, "Bạn Đã Nhận Qùa Vip Hoặc không đủ điều kiện nhận VIP mốc này");
                    return;
                }
                if (p.c.nclass == 0) {
                    Service.chatNPC(p, (short) npcid, "Bạn Chưa Nhập Học Nên Không Thể Nhận Qùa Vip");
                    return;
                }
                switch (b3) {
                    case 0: {
                        if (p.c.vip != 1) {
                            Service.chatNPC(p, (short) npcid, "Bạn không đủ điều kiện nhận VIP Mốc Này");
                            return;
                        }
                        p.c.coin += 1000; // Cộng thêm 1000 coin
                        p.c.vnd += 500; // Cộng thêm 500 vnd
                        p.conn.sendMessageLog("Bạn đã nhận 1000 coin và 500 vnd thành công");
                        p.c.nhanqua = 1;
                        break;
                    }
                    case 1: {
                        if (p.c.vip != 2) {
                            Service.chatNPC(p, (short) npcid, "Bạn không đủ điều kiện nhận VIP Mốc Này");
                            return;
                        }
                        p.c.coin += 2000; // Cộng thêm 2000 coin
                        p.c.vnd += 1000; // Cộng thêm 1000 vnd
                        p.conn.sendMessageLog("Bạn đã nhận 2000 coin và 1000 vnd thành công");
                        p.c.nhanqua = 1;
                        break;
                    }
                    case 2: {
                        if (p.c.vip != 3) {
                            Service.chatNPC(p, (short) npcid, "Bạn không đủ điều kiện nhận VIP Mốc Này");
                            return;
                        }
                        p.c.coin += 3000000;
                        p.c.vnd += 100000;
                        p.conn.sendMessageLog("Bạn đã nhận 3.000.000 coin và 100.0000 vnd thành công");
                        p.c.nhanqua = 1;
                        break;
                    }
                    case 3: {
                        if (p.c.vip != 4) {
                            Service.chatNPC(p, (short) npcid, "Bạn không đủ điều kiện nhận VIP Mốc Này");
                            return;
                        }
                        p.c.coin += 5000000;
                        p.c.vnd += 200000;
                        p.conn.sendMessageLog("Bạn đã nhận 5.000.000 coin và 200.000 vnd thành công");
                        p.c.nhanqua = 1;
                        break;
                    }
                    case 4: {
                        if (p.c.vip != 5) {
                            Service.chatNPC(p, (short) npcid, "Bạn không đủ điều kiện nhận VIP Mốc Này");
                            return;
                        }
                        p.c.coin += 8000000;
                        p.c.vnd += 500000;
                        p.conn.sendMessageLog("Bạn đã nhận 8.000.000 coin và 500.000 vnd thành công");
                        p.c.danhhieu = p.c.nclass;
                        p.c.nhanqua = 1;
                        break;
                    }
                    case 5: {
                        if (p.c.vip != 20) {
                            Service.chatNPC(p, (short) npcid, "Bạn không đủ điều kiện nhận VIP Mốc Này");
                            return;
                        }
                        p.c.coin += 20000000;
                        p.c.vnd += 1000000;
                        p.conn.sendMessageLog("Bạn đã nhận 20 Triệu coin và 1.000.000 vnd thành công");
                        p.c.danhhieu = p.c.nclass;
                        p.c.nhanqua = 1;
                        break;
                    }
                    case 6: {
                        if (p.c.vip != 100) {
                            Service.chatNPC(p, (short) npcid, "Bạn không đủ điều kiện nhận VIP Mốc Này");
                            return;
                        }
                        p.c.coin += 100000000;
                        p.c.vnd += 5000000;
                        p.conn.sendMessageLog("Bạn đã nhận 100 Triệu coin và 5.000.000 vnd thành công");
                        p.c.danhhieu = p.c.nclass;
                        p.c.nhanqua = 1;
                        break;
                    }
                }
                break;
            }
//            case 1: {
//                if (p.c.isNhanban) {
//                    Service.chatNPC(p, (short) npcid, Language.NOT_FOR_PHAN_THAN);
//                    return;
//                }
//                if (p.c.vip == -1) {
//                    Service.chatNPC(p, (short) npcid, "Bạn không đủ điều kiện để báo danh vip");
//                    return;
//                }
//                switch (p.c.vip) {
//                    case 1: {
//                        if (p.c.diemdanhvip == 0) {
//                            LichSu.LichSuLuong(p.c.name, p.luong, (p.luong + 1000), "Điểm danh vip", +1000);
//                            p.upluongMessage(1000);
//                            Service.addItemToBagNinja(p.c, ItemName.LINH_CHI_VAN_NAM, true, false, 1, false, -1);
//                            p.c.diemdanhvip = 1;
//                            Service.chatNPC(p, (short) npcid, "Báo danh VIP 1 thành công");
//                            break;
//                        } else {
//                            Service.chatNPC(p, (short) npcid, "Hôm nay trùm đã Báo danh VIP, hãy quay lại vào ngày hôm sau nha!");
//                        }
//                        break;
//                    }
//                    case 2: {
//                        if (p.c.diemdanhvip == 0) {
//                            LichSu.LichSuLuong(p.c.name, p.luong, (p.luong + 5000), "Điểm danh vip", +5000);
//                            p.upluongMessage(5000);
//                            Service.addItemToBagNinja(p.c, ItemName.LINH_CHI_VAN_NAM, true, false, 3, false, -1);
//                            p.c.diemdanhvip = 1;
//                            Service.chatNPC(p, (short) npcid, "Báo danh VIP 2 thành công.");
//                            break;
//                        } else {
//                            Service.chatNPC(p, (short) npcid, "Hôm nay trùm đã Báo danh VIP, hãy quay lại vào ngày hôm sau nha!");
//                        }
//                        break;
//                    }
//                    case 3: {
//                        if (p.c.diemdanhvip == 0) {
//                            LichSu.LichSuLuong(p.c.name, p.luong, (p.luong + 10000), "Điểm danh vip", +10000);
//                            p.upluongMessage(10000);
//                            Service.addItemToBagNinja(p.c, ItemName.LINH_CHI_VAN_NAM, true, false, 5, false, -1);
//                            p.c.diemdanhvip = 1;
//                            Service.chatNPC(p, (short) npcid, "Báo danh VIP 3 thành công.");
//                            break;
//                        } else {
//                            Service.chatNPC(p, (short) npcid, "Hôm nay trùm đã Báo danh VIP, hãy quay lại vào ngày hôm sau nha!");
//                        }
//                        break;
//                    }
//                    case 4: {
//                        if (p.c.diemdanhvip == 0) {
//                            LichSu.LichSuLuong(p.c.name, p.luong, (p.luong + 20000), "Điểm danh vip", +20000);
//                            p.upluongMessage(20000);
//                            Service.addItemToBagNinja(p.c, ItemName.LINH_CHI_VAN_NAM, true, false, 7, false, -1);
//                            p.c.diemdanhvip = 1;
//                            Service.chatNPC(p, (short) npcid, "Báo danh VIP 4 thành công.");
//                            break;
//                        } else {
//                            Service.chatNPC(p, (short) npcid, "Hôm nay trùm đã Báo danh VIP, hãy quay lại vào ngày hôm sau nha!");
//                        }
//                        break;
//                    }
//                    case 5: {
//                        if (p.c.diemdanhvip == 0) {
//                            LichSu.LichSuLuong(p.c.name, p.luong, (p.luong + 30000), "Điểm danh vip", +30000);
//                            p.upluongMessage(30000);
//                            Service.addItemToBagNinja(p.c, ItemName.LINH_CHI_VAN_NAM, true, false, 10, false, -1);
//                            p.c.diemdanhvip = 1;
//                            Service.chatNPC(p, (short) npcid, "Báo danh VIP 5 thành công.");
//                            break;
//                        } else {
//                            Service.chatNPC(p, (short) npcid, "Hôm nay trùm đã Báo danh VIP, hãy quay lại vào ngày hôm sau nha!");
//                        }
//                        break;
//                    }
//                }
//                break;
//            }
            case 2:
                String nhanqua = "";
                String diemdanh = "";
                if (p.c.nhanqua == 1) {
                    nhanqua = "Đã Nhận";
                } else {
                    nhanqua = "Chưa Nhận";
                }
                if (p.c.diemdanhvip == 1) {
                    diemdanh = "Đã Báo Danh";
                } else {
                    diemdanh = "Chưa Báo Danh";
                }
                if (p.c.vip == -1) {
                    p.conn.sendMessageLog("Bạn Không Có Vip");
                } else {
                    p.conn.sendMessageLog("Bạn Hiện Đang Ở Vip " + p.c.vip + "\n"
                            + "Đặc Quyền VIP : Nhận X" + p.c.vip + " Yên Khi Úp \n"
                            + "Trạng Thái \n"
                            + "Nhận Quà Vip : " + nhanqua + "\n"
                            + "Điểm Danh Vip : " + diemdanh + "\n"
                    );
                }
                break;
            case 3: {
                switch (b3) {
                    case 0: {
                        if (p.c.vip < 3) {
                            Service.chatNPC(p, (short) npcid, "Yêu cầu Vip 3 Mới Có Thể Vào Map Này");
                            return;
                        }
                        if (p.c.getEffId(34) == null) {
                            if (p.c.quantityItemyTotal(564) < 1) {
                                p.conn.sendMessageLog("Phải Sử Dụng Thí Luyện Thiếp Mới Có Thể Vào Map Này.");
                                return;
                            }
                        }

                        final int trialTimeLimit = 3600; 

                        if (p.c.get().timeUseItem == 0) {
                            p.c.get().timeUseItem = System.currentTimeMillis() / 1000;
                            Service.chatNPC(p, (short) npcid, "Thời gian thí luyện thiếp còn 1 tiếng.");
                            p.c.removeItemBags(564, 1); 
                        } else {
                            long currentTime = System.currentTimeMillis() / 1000;
                            long timeElapsed = currentTime - p.c.get().timeUseItem;

                            if (timeElapsed >= trialTimeLimit) {
                                p.c.tileMap.leave(p);
                                p.conn.sendMessageLog("Thời gian thí luyện của bạn đã hết. Bạn đã bị đẩy ra ngoài map VIP.");
                                p.c.get().timeUseItem = 0; 
                                return;
                            }
                        }

                        Map ma = Manager.getMapid(112);
                        for (TileMap area : ma.area) {
                            if (area.numplayers < ma.template.maxplayers) {
                                p.c.tileMap.leave(p);
                                area.EnterMap0(p.c);
                                return;
                            }
                        }
                        break;
                    }
                    case 1:
                        Service.chatNPC(p, (short) npcid, "Để tham gia Map VIP Bạn Cần Đạt VIP 3 Và Phải Sử Dụng Thí Luyện Thiếp Mới Có Thể Vào Map. \n Quái trong Map VIP sẽ rất mạnh, Khi tiêu diệt quái sẽ nhận được 1 Lượng/1 Quái và quái sẽ rơi ra nhiều vật phẩm đặc biệt \n Hồi sinh ở Map VIP Sẽ Mất 100 Lượng 1 Lần Hồi Sinh. Mỗi Ngày chỉ có thể sử dụng tối đa 1 Thí Luyện Thiếp \n Tiêu diệt thủ lĩnh sẽ nhận được 1 viên ngọc 7 sao");
                        break;
                }
                break;
            }
            case 4: {
                Vip.showVipOptions(p, (short) npcid);
                int[] vipCosts = {300000, 500000, 1000000, 2000000, 10000000};
                int currentVipLevel = p.c.vip;
                int newVipLevel = 0;
                int cost = 0;
                switch (b3) {
                    case 0:
                        newVipLevel = 3;
                        cost = vipCosts[0];
                        break;
                    case 1:
                        newVipLevel = 4;
                        cost = vipCosts[1];
                        break;
                    case 2:
                        newVipLevel = 5;
                        cost = vipCosts[2];
                        break;
                    case 3:
                        newVipLevel = 20;
                        cost = vipCosts[3];
                        break;
                    case 4:
                        newVipLevel = 100;
                        cost = vipCosts[4];
                        break;
                    default:
                        Service.chatNPC(p, (short) npcid, "Gói VIP không hợp lệ.");
                        return;
                }
                int currentCost = 0;
                if (currentVipLevel >= 3) {
                    currentCost = vipCosts[currentVipLevel - 3];
                }
                int upgradeCost = cost - currentCost;
                if (p.c.atm < upgradeCost) {
                    Service.chatNPC(p, (short) npcid, "Bạn không đủ ATM để nâng cấp VIP này. Hiện tại bạn có: " + p.c.atm + " ATM.");
                    return;
                }
                p.c.upatmMessage(-upgradeCost);
                p.c.vip = newVipLevel;
                p.c.diemdanhvip = 0;
                Service.chatNPC(p, (short) npcid, "Nâng cấp VIP " + newVipLevel + " thành công. Bạn đã được nâng cấp VIP với nhiều lợi ích mới!");
                Service.chatKTG("Người chơi " + p.c.name + " đã nâng cấp thành công lên VIP " + newVipLevel + "!");
                break;
            }
        }
    }
}
