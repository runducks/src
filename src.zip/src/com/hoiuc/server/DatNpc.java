package com.hoiuc.server;
//Scr By SHIN
import com.hoiuc.assembly.Char;
import com.hoiuc.assembly.Player;
import com.hoiuc.assembly.TileMap;
import com.hoiuc.io.Message;
import com.hoiuc.io.Util;
//Scr By SHIN
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
//Scr By SHIN
public class DatNpc implements Runnable {

    public static int idbase;
    public List<AIi> aiis;
    public static DatNpc instance;
    private boolean running;

    public DatNpc() {
        aiis = new ArrayList<>();
        running = false;
    }

    private Thread AIlive;
    private TileMap map;

    public static DatNpc gI() {
        if (instance == null) {
            instance = new DatNpc();
        }
        return instance;
    }

    public void init(Player p) {
        map = p.c.tileMap;
        Player p2 = new Player();
        p2.c = new Char();
        p2.c = Char.setup(p2, "ChuCuoi"); //ten con bot
        aiis.add(new AIi(p.c.x, p.c.y, p.c.x, p.c.y, p2, 30, map, System.currentTimeMillis(), p));
        p2.c.isBot = true;
        p2.c.hp = p2.c.getMaxHP();
        map.EnterMap0WithXY(p2.c, p.c.x, p.c.y);
        AIlive = new Thread(this);
        AIlive.start();
    }

    @Override
    public void run() {
        running = false;
        while (running) {
            for (int i = 0; i < aiis.size(); i++) {
                AIi aa = aiis.get(i);
                aa.map.move(aa.id, aa.getx(), aa.gety());
                aa.move();
                autochat(aa); // vừa đi vừa chat, k thì tắt đi

                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            try {
                Thread.sleep(2000L);  //cho nó chạy nhanh hơn thì chình time này bé lại
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void autochat(AIi aa) {
        if (System.currentTimeMillis() > aa.time) {
            aa.time = System.currentTimeMillis() + 2000L;
            try {
                Message m = new Message(-23);
                m.writer().writeInt(aa.id);
                m.writer().writeUTF("đợi iem với"); //
                m.writer().flush();
                map.sendMessage(m);
                m.cleanup();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void clear() {
        running = false;
        for (int i = 0; i < aiis.size(); i++) {
            AIi aa = aiis.get(i);
            aa.map.removeMessage(aa.id);
            aa.map.players.remove(aa.p11);
            aa.map.numplayers--;
        }
        try {
            Thread.sleep(600L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        aiis.clear();
        aiis = null;
        AIlive = null;
        map = null;
        instance = null;
        idbase = 0;
    }

    private class AIi {

        public short x;
        public short y;
        public short x0;
        public short y0;
        public int id;
        public int direct;
        TileMap map;
        private long time;
        public int[] locasX;
        public int[] locasY;
        public int indexlocas;
        public boolean turn;
        public int state;
        Player p0;
        Player p11;

        public AIi(short x, short y, short x0, short y0, Player p11, int direct, TileMap map, long time, Player p0) {
            this.x = x;
            this.y = y;
            this.x0 = x0;
            this.y0 = y0;
            this.p11 = p11;
            this.id = p11.c.id;
            this.direct = direct;
            this.map = map;
            this.time = time;
            this.locasX = new int[11];
            this.locasY = new int[11];
            this.p0 = p0;
            int midx = locasX.length / 2;
            locasX[midx] = x0;
            locasY[midx] = y0;
            midx--;
            for (int i = midx; i >= 0; i--) {
                locasX[i] = locasX[i + 1] - direct;
                locasY[i] = y0;
            }
            midx += 2;
            for (int i = midx; i < locasX.length; i++) {
                locasX[i] = locasX[i - 1] + direct;
                locasY[i] = y0;
            }
            indexlocas = midx;
            state = (int) Util.nextInt(1, 2);
        }

        public short getx() {
            return (short) x;
        }

        public short gety() {
            return (short) y;
        }

        public void move() {
            x = (short) (p0.c.x + Util.nextInt(-30, 30));
            y = p0.c.y;
        }

        public void atchar(AIi p, Player p1) {
            try {
                Message m = new Message(61);
                m.writer().writeInt(p.id);
                m.writer().writeByte(0);
                m.writer().writeInt(p1.c.id);
                m.writer().flush();
                p.map.sendMessage(m);
                m.cleanup();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
