package com.hoiuc.server;
//Scr By SHIN
import static com.hoiuc.io.SQLManager.conn;
import com.hoiuc.stream.Server;
import java.awt.Component;
import java.io.IOException;
import java.net.ServerSocket;
import javax.swing.JFrame;
//Scr By SHIN
public class panelMain {
    // Khởi tạo GUI
         
        private static void initializeGUI() {
        // Khởi tạo PanelAdmin và hiển thị nó
        JFrame panelFrame = new JFrame("Panel");
        PanelAdmin panel = new PanelAdmin();
        panel.initializeComponents(); 
        panel.setupLayout();
        ServerSocket listenSocket = null;
        PanelAdmin.start(panelFrame, panel, listenSocket, null);  // Thêm PanelAdmin vào JFrame, và hiển thị JFrame
    }
    public static void main(String[] args) throws IOException  {
        initializeGUI();        
    }
}
