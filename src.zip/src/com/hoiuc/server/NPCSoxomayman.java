package com.hoiuc.server;

import java.time.LocalTime;
import History.LichSu;
import com.hoiuc.assembly.*;
import java.util.ArrayList;
import java.util.HashMap;
import com.hoiuc.server.Manager;
import java.util.Random;
import com.hoiuc.assembly.Char;
import com.hoiuc.assembly.Player;
import com.hoiuc.io.Util;
import com.hoiuc.stream.Server;
import java.util.ArrayList;
import com.hoiuc.assembly.Language;
import com.hoiuc.io.Message;
import com.hoiuc.io.SQLManager;
import java.io.IOException;
import java.time.Instant;
import java.util.Date;
import com.hoiuc.stream.Client;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;

public class NPCSoxomayman {

    private int soMayManTruoc;
    private ArrayList<Char> nguoiChoiTrungThuong; // Danh sách người chơi trúng số lần trước
    public void setSoMayManTruoc(int i , Char u) {
        soMayManTruoc = i;
        nguoiChoiTrungThuong.add(u);
    }
    // Khởi tạo
    public NPCSoxomayman() {
        this.soMayManTruoc = -1;
        this.nguoiChoiTrungThuong = new ArrayList<>();
    }

    public void chonSo(Player p, int soDaChon, String name, byte npcid, byte menuId, byte b3) {
        
        if (soDaChon < 0 || soDaChon > 99) {
            p.conn.sendMessageLog("Vui lòng chọn số từ 00 đến 99.");
            return;
        }            
        if (LichSuSoXo(name, soDaChon)) {        
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String timeChosen = dateFormat.format(calendar.getTime());

            
            p.conn.sendMessageLog("Bạn đã chọn số: " + soDaChon + " vào lúc " + timeChosen + ".");
        } else {
            p.conn.sendMessageLog("Đã xảy ra lỗi khi ghi lại số đã chọn.");
        }
    }

    public void huongDan(Player p) {
        String huongDan = "Chào mừng bạn đến với xổ số may mắn!\n"
                + "1. Bạn có thể chọn một số từ 00 đến 99 mỗi lần.\n"
                + "2. Cần sử dụng vé sổ xố để đặt cược ( liên hệ ADMIN để mua vé ).\n"
                + "3. Mỗi lần sử dụng vé sổ xố sẽ tiêu hao 1 vé sổ xố.\n"
                + "4. Nếu bạn chọn đúng số may mắn, sẽ X70 giá trị giải thưởng.\n"
                + "5. Phần thưởng sẽ đến với người may mắn, Chúc bạn chơi game vui vẻ !";
        p.conn.sendMessageLog(huongDan);
    }

    // Hiển thị người chơi may mắn lần trước
    public void hienThiNguoiChoiMayManLanTruoc(Player p) {
        soMayManTruoc = p.c.getInputNumber();
        //nguoiChoiTrungThuong=new ArrayList(p.c);
        if (soMayManTruoc == -1) {
            p.conn.sendMessageLog("Chưa có người chơi nào trúng thưởng từ lần trước.");
            return;
        }
        StringBuilder sb = new StringBuilder("Số may mắn lần trước: " + soMayManTruoc + "\nNgười chơi trúng thưởng:\n");
        for (Char c : nguoiChoiTrungThuong) {
            sb.append("- ").append(c.name).append("\n");
        }
        p.conn.sendMessageLog(sb.toString());
    }

    // Xử lý quay số vào 6h30
    public void quaySoHangNgay() {
        LocalTime now = LocalTime.now(); // Lấy thời gian hiện tại
        String thongBao; // Khai báo biến thông báo

        // Khởi tạo danh sách người chơi trúng thưởng nếu chưa có
        if (nguoiChoiTrungThuong == null) {
            nguoiChoiTrungThuong = new ArrayList<>();
        }

        // Kiểm tra thời gian có phải 6h30 hay không
        if (now.getHour() == 6 && now.getMinute() == 30) {
            Random rand = new Random();
            int soMayMan = rand.nextInt(100);
            nguoiChoiTrungThuong.clear(); // Xóa danh sách người chơi trúng thưởng cũ

            // Tạo thông báo
            if (nguoiChoiTrungThuong.isEmpty()) {
                thongBao = "Số may mắn của ngày hôm nay là: " + soMayMan + ". Không có người chơi nào trúng thưởng.";
            } else {
                thongBao = "Số may mắn của ngày hôm nay là: " + soMayMan + ". Người chơi trúng thưởng: " + nguoiChoiTrungThuong.toString();
            }

            // Gửi thông báo xổ số
            Server.manager.chatKTG("Xổ Số");

            // Cập nhật số may mắn lần trước và xóa lịch sử
            soMayManTruoc = soMayMan;
        }
    }

    // Lưu lịch sử xổ số vào file
    public static boolean LichSuSoXo(String name1, int soDaChon) {
        try {
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String timeChosen = dateFormat.format(calendar.getTime());

            String filename = "LichSu/SoXo/LichSuSoXo_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(calendar.getTime()) + ".txt";
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true));

            // Ghi nội dung vào file
            bw.write("----------Thời Gian : " + timeChosen + "--------\n"
                    + "- Tên Người Chơi : " + name1 + "\n"
                    + "- Số Đã Chọn : " + soDaChon + "\n");
            bw.write("-----------------------------------\n");

            // Đóng các luồng
            bw.close();
            return true; // Trả về true nếu ghi thành công
        } catch (IOException e) {
            System.out.println("Lỗi khi ghi vào file: " + e.getMessage()); // In ra lỗi nếu có
            return false; // Trả về false nếu có lỗi
        } catch (Exception e) {
            System.out.println("Lỗi không xác định: " + e.getMessage());
            return false; // Trả về false nếu có lỗi không xác định
        }
    }
}
