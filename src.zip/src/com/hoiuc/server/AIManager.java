package com.hoiuc.server;
//Scr By SHIN
import com.hoiuc.assembly.Char;
import com.hoiuc.assembly.ItemLeave;
import com.hoiuc.assembly.Player;
import com.hoiuc.assembly.TileMap;
import com.hoiuc.io.Message;
import com.hoiuc.io.Util;
//Scr By SHIN
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
//Scr By SHIN
public class AIManager implements Runnable {

    public static int idbase = 0;
    public List<AIi> aiis;
    public static AIManager instance;
    private boolean running;
    public String[] CHATBOT = new String[] {"Tao đang cáu đừng vào gần tao","Mày Biết Bố Mày Là ai Không?","Mày Tuổi Gì"};
    public String[] CHATBOT1 = new String[] {"A Con Chó Này,Bố bắt đầu thấy yêu mày rồi đấy","Con ngan Con này?","Thấy tao chưa,Đấm chết cụ mày"};
    public String[] CHATBOT2 = new String[] {"Quân Tử Trả thù 10 năm chưa muộn","Nhớ lấy con chó, Bố sẽ quay lại?","Lần này coi như tao đen.."};
    public String[] CHATBOT3 = new String[] {"Cả Ngày đánh giết chúng mày có thấy mệt không?","Haizz.. Nhớ người yêu quá?","Tao yêu cái cảm giác yên bình này!"};
    public AIManager() {
        aiis = new ArrayList<>();
        running = false;
    }
//Scr By SHIN
    private Thread AIlive;
    private TileMap map;
//Scr By SHIN
    public static AIManager gI() {
        if (instance == null) {
            instance = new AIManager();
        }
        return instance;
    }

    public void init(Player p, String name) {
        map = p.c.tileMap;
        Player p2 = new Player();
        p2.c = new Char();
        idbase++;
        p2.c = Char.setup(p2, name); //ten con bot
        p2.c.hp = p2.c.getMaxHP();
        aiis.add(new AIi(p.c.x, p.c.y, p.c.x, p.c.y, p2, p2.c.id, 30, map, System.currentTimeMillis()));
        p2.c.isBot = true;
        map.EnterMap0WithXY(p2.c, p.c.x, p.c.y);
        AIlive = new Thread(this);
        AIlive.start();
    }

    @Override
    public void run() {
        running = true;
        while (running) {
            for (int i = 0; i < aiis.size(); i++) {
                AIi aa = aiis.get(i);
                if (aa.state == 1&& !aa.map.map.map0pk()) {  //đang di chuyển
                    aa.map.move(aa.id, aa.getx(), aa.gety());
                    aa.move();
                    autochat(aa,  CHATBOT);
                    
                } else if (aa.state == 2&& !aa.map.map.map0pk()) {  // đấm mục tiêu
                    autochat1(aa, CHATBOT1);
                    
                } else if (aa.state == 3&& !aa.map.map.map0pk()) {  // đen xì
                    autochat2(aa, CHATBOT2);
                    
                }else if (aa.state == 4 && aa.state != 2 && aa.state != 3  && aa.map.map.map0pk()) {  // trong làng
                    autochat3(aa, CHATBOT3);
                    
                }
                for (Player p1 : aa.map.players) {
                    if (p1.c.hp > 0 && (Math.abs(p1.c.x - aa.getx()) < 70) && (Math.abs(p1.c.y - aa.gety()) < 70) && !p1.c.isBot) {
                        aa.state = 2;
                        if (p1.c.hp > 0 && !aa.map.map.map0pk()) { //gioi han hp đây
                            aa.atchar(aa, p1);
                        }
                        
                        
                    } else if (!p1.c.isBot) {
                        aa.state = 1;
                    }
                    if (p1.c.id == aa.id) {
                        aa.hp = p1.c.hp;
                    }
                }
                if ( aa.map.map.map0pk()) { //gioi han hp đây
                            aa.state = 4;
                            aa.map.move(aa.id, aa.getx(), aa.gety());
                            aa.move();
                        }
                if (!aa.isdie && aa.hp <= 0) {
                    aa.senddie(aa);
                    aa.state = 3;
                    short[] itid = new short[]{ 311,312,313,314,315,316,375,376,377,378,379,380,552,553,554,555,556,557,558,559,560,561,562,563,547,545};  //id roi
                    ItemLeave.leaveitembot(aa.map, itid[(int) Util.nextInt(itid.length)], aa.x,aa.y, -1);
                }
                if (aa.isdie && System.currentTimeMillis() > aa.time3) {
                    aa.hoisinh(aa);
                    aa.state = 1;
                }
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            try {
                Thread.sleep(600L);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void autochat(AIi aa, String[] s) {
        if (System.currentTimeMillis() > aa.time) {
            aa.time = System.currentTimeMillis() + 3000L;
            try {
                Message m = new Message(-23);
                m.writer().writeInt(aa.id);
                String chat = CHATBOT[(int)Util.nextInt(0, 2)];
                m.writer().writeUTF(chat); //
                m.writer().flush();
                aa.map.sendMessage(m);
                m.cleanup();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
private void autochat1(AIi aa,String [] s) {
        if (System.currentTimeMillis() > aa.time) {
            aa.time = System.currentTimeMillis() + 3000L;
            try {
                Message m = new Message(-23);
                m.writer().writeInt(aa.id);
                String chat = CHATBOT1[(int)Util.nextInt(0, 2)];
                m.writer().writeUTF(chat); //
                m.writer().flush();
                aa.map.sendMessage(m);
                m.cleanup();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
private void autochat2(AIi aa, String[] s) {
        if (System.currentTimeMillis() > aa.time) {
            aa.time = System.currentTimeMillis() + 3000L;
            try {
                Message m = new Message(-23);
                m.writer().writeInt(aa.id);
                String chat = CHATBOT2[(int)Util.nextInt(0, 2)];
                m.writer().writeUTF(chat); //
                m.writer().flush();
                aa.map.sendMessage(m);
                m.cleanup();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
private void autochat3(AIi aa, String[] s) {
        if (System.currentTimeMillis() > aa.time) {
            aa.time = System.currentTimeMillis() + 3000L;
            try {
                Message m = new Message(-23);
                m.writer().writeInt(aa.id);
                String chat = CHATBOT3[(int)Util.nextInt(0, 2)];
                m.writer().writeUTF(chat); //
                m.writer().flush();
                aa.map.sendMessage(m);
                m.cleanup();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public void clear() {
        running = false;
        for (int i = 0; i < aiis.size(); i++) {
            AIi aa = aiis.get(i);
            aa.map.removeMessage(aa.id);
            aa.map.players.remove(aa.p11);
            aa.map.numplayers--;
        }
        try {
            Thread.sleep(600L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        aiis.clear();
        aiis = null;
        AIlive = null;
        map = null;
        instance = null;
        idbase = 0;
    }

    private class AIi {

        public short x;
        public short y;
        public short x0;
        public short y0;
        public int id;
        public int direct;
        public double hp;
        public long dame;
        public boolean isdie = false;
        TileMap map;
        private long time;
        public int[] locasX;
        public int[] locasY;
        public int indexlocas;
        public boolean turn;
        public int state;
        Player p11;
        private long time2;
        private long time3;

        public AIi(short x, short y, short x0, short y0, Player p11, int id, int direct, TileMap map, long time) {
            this.x = x;
            this.y = y;
            this.x0 = x0;
            this.y0 = y0;
            this.p11 = p11;
            this.id = id;
            this.hp = p11.c.hp;
            this.direct = direct;
            this.map = map;
            this.time = time;
            this.time2 = time;
            this.dame = (long) p11.c.dameMax();
            this.locasX = new int[11];
            this.locasY = new int[11];
            int midx = locasX.length / 2;
            locasX[midx] = x0;
            locasY[midx] = y0;
            midx--;
            for (int i = midx; i >= 0; i--) {
                locasX[i] = locasX[i + 1] - direct;
                locasY[i] = y0;
            }
            midx += 2;
            for (int i = midx; i < locasX.length; i++) {
                locasX[i] = locasX[i - 1] + direct;
                locasY[i] = y0;
            }
            indexlocas = midx;
            state = (int) Util.nextInt(1, 2);
        }

        public short getx() {
            return (short) locasX[indexlocas];
        }

        public short gety() {
            return (short) locasY[indexlocas];
        }

        public void move() {
            if (indexlocas >= 10) {
                turn = false;
            } else if (indexlocas <= 0) {
                turn = true;
            }
            if (turn) {
                indexlocas++;
            } else {
                indexlocas--;
            }
        }

        public void atchar(AIi p, Player p1) {
            if (!p.isdie && !p1.c.isDie && System.currentTimeMillis() > p.time2) {
                p.time2 = System.currentTimeMillis() + 350L;  // toc do danh
                p.map.attached(p.dame, p1.c.id);
                p1.c.upHP(-p.dame);
                try {
                    Message m = new Message(61);
                    m.writer().writeInt(p.id);
                    byte[] idsk = new byte[]{79, 80,81,82,83,84}; // thay id vô. id skill
                    m.writer().writeByte(idsk[(int) Util.nextInt(idsk.length)]);
                    m.writer().writeInt(p1.c.id);
                    m.writer().flush();
                    p.map.sendMessage(m);
                    m.cleanup();
                    if (p1.c.hp <= 0) {
                        p1.c.upDie();
                    }
                    
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void senddie(AIi p) {
            if (!p.isdie) {
                p.isdie = true;
                p.time3 = System.currentTimeMillis() + 15000L; // tgian hoisinh
                try {
                    Message m = new Message(0);
                    m.writer().writeInt(p.id);
                    m.writer().writeByte(0);
                    m.writer().writeShort(p.x);
                    m.writer().writeShort(p.y);
                    m.writer().flush();
                    p.map.sendMessage(m);
                    m.cleanup();
                    m = new Message(-9);
                    m.writer().writeInt(p.id);
                    m.writer().writeByte(0);
                    m.writer().writeShort(p.x);
                    m.writer().writeShort(p.y);
                    m.writer().flush();
                    p.map.sendMessage(m);
                    m.cleanup();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void hoisinh(AIi p) {
            p.hp = p.p11.c.getMaxHP();
            for (int i = 0; i < p.map.players.size(); i++) {
                if (p.map.players.get(i).c.id == p.id) {
                    p.map.players.get(i).c.hp = p.hp;
                    p.map.players.get(i).c.isDie = false;
                }
            }
            p.isdie = false;
            try {
                Message m = new Message(-10);
                m.writer().flush();
                p.map.sendMessage(m);
                m.cleanup();
                m = new Message(88);
                m.writer().writeInt(p.id);
                m.writer().writeShort(p.x);
                m.writer().writeShort(p.y);
                m.writer().flush();
                p.map.sendMessage(m);
                m.cleanup();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
