package com.hoiuc.server;
//Scr By SHIN
import java.util.ArrayList;
import com.hoiuc.assembly.Char;
import com.hoiuc.assembly.Language;
import com.hoiuc.assembly.Player;
import com.hoiuc.io.Message;
import com.hoiuc.io.SQLManager;
import com.hoiuc.io.Util;
import java.io.IOException;
import java.time.Instant;
import java.util.Date;
import com.hoiuc.stream.Client;
import com.hoiuc.stream.Server;
//Scr By SHIN
//Scr By SHIN
public class TaiXiu {
    public int totalxiu;
    public int totaltai;
    
    public short playertai;
    public short playerxiu;
    
    public long time;
    public long timewait;
    
    public boolean start;
    public boolean tai;
    public boolean xiu;
    
    public long tongrandom;
    public String taiorxiu;
    
    public ArrayList<Char> teamtai;
    public ArrayList<Char> teamxiu;
    
    // Khởi tạo
    public TaiXiu() {
        this.totaltai = 0;
        this.totalxiu = 0;
        this.playertai = 0;
        this.playerxiu = 0;
        this.teamtai = new ArrayList<Char>();
        this.teamxiu = new ArrayList<Char>();
        this.tai = false;
        this.xiu = false;
        this.time = 60;
        this.start = true;
    }
    
    //Thông tin kết quả.
    public void InfoTaiXiu(Player p) {
        
        if (p.c.tai == false && p.c.xiu == false) {
            Server.manager.sendTB(p, "Tài Xỉu", "Tổng tiền cược Tài : " + this.totaltai + "\n"
                                          + "Tổng cược Xỉu : " + this.totalxiu + "\n"
                                          + "Thời gian : " + this.time + " giây\n"
                                          + "Kết quả phiên trước : " + this.taiorxiu + " - "+ this.tongrandom + "\n"
                                          + p.c.taixiu);
        } else {
            Server.manager.sendTB(p, "Tài Xỉu", "Tổng tiền cược Tài : " + this.totaltai + "\n"
                                          + "Tổng cược Xỉu : " + this.totalxiu + "\n"
                                          + "Thời gian : " + this.time + " giây\n"
                                          + "Kết quả phiên trước : " + this.taiorxiu + " - "+ this.tongrandom + "\n"
                                          + "Bạn đặt cược " + p.c.jointx + " coin vào " + p.c.taixiu);
        }
    }
    
    //random để lấy kết quả
    private void random() {
    try {
        long a = Util.nextInt(1, 6);
        long b = Util.nextInt(1, 6);
        long c = Util.nextInt(1, 6);
        this.tongrandom = a + b + c;
        if (this.tongrandom <= 10) {
            this.taiorxiu = "Xỉu";
            this.xiu = true;
            this.tai = false;
        } else {
            this.taiorxiu = "Tài";
            this.tai = true;
            this.xiu = false;
        }
        SoiCau.soicau.add(new SoiCau("Kết quả: " + taiorxiu, "Số: " + this.tongrandom, Util.toDateString(Date.from(Instant.now()))));
    } catch (Exception e) {
        e.printStackTrace(); // Ghi lại lỗi nếu có
    }
}
    private void processTeam(ArrayList<Char> team, boolean isTai) {
    for (Char c : team) {
        if (c.jointx > 0) {
            c.p.upcoinMessage(c.jointx * 19 / 10);
            c.jointx = 0;
            c.tai = false;
            c.xiu = false;
            c.datatx();
        }
    }
    team.clear(); 
}
    
    public void Start() {
        if(this.start == true) {
            if (this.time > 0) {
                this.time -= 1;
            }
            if (this.time == 0) {
                this.start = false;
                this.timewait = 10;
                this.random();
                this.Wait();
            }
        }
    }
    
    public void Wait() {
        while(this.start == false) {
            if (this.timewait > 0) {
                this.timewait -= 1;
            }
            if (this.tai == true) {
                for (int i = 0; i< this.teamtai.size();i++) {
                    Char c = this.teamtai.get(i);
                    if (c.jointx > 0) {
                        c.p.upcoinMessage(c.p.c.jointx*19/10);
                        c.jointx = 0;
                        c.tai = false;
                        c.xiu = false;
                        
                        this.tai = false;
                        c.datatx();
                    }
                }
                for (int i = 0; i< this.teamxiu.size();i++) {
                    Char c = this.teamxiu.get(i);
                    c.jointx = 0;
                    c.xiu = false;
                    c.tai = false;
                  
                    this.xiu = false;
                    c.datatx();
                }
                this.totaltai =0;
                this.teamtai.clear();
                this.totalxiu =0;
                this.teamxiu.clear();
            }
            if (this.xiu == true) {
                for (int i = 0; i< this.teamxiu.size();i++) {
                    Char c = this.teamxiu.get(i);
                    if (c.jointx > 0) {
                        c.p.upcoinMessage(c.p.c.jointx*19/10);
                        c.jointx = 0;
                        c.xiu = false;
                        c.tai = false;
                       
                        this.xiu = false;
                        c.datatx();
                    }
                }
                for (int i = 0; i< this.teamtai.size();i++) {
                    Char c = this.teamtai.get(i);
                    c.jointx = 0;
                    c.tai = false;
                    c.xiu = false;
                    this.tai = false;
                   
                    c.datatx();
                }
                this.totalxiu = 0;
                this.teamxiu.clear();
                this.totaltai = 0;
                this.teamtai.clear();
            }
            if (this.timewait == 0) {
                this.time = 60;
                this.start = true;
                this.Start();
            }
        }
    }
    
    // đặt cược tài
    public void joinTai(Player p, int jointai) {
        if (this.time <= 10L) {
            p.conn.sendMessageLog("Đã hết thời gian đặt cược.");
            return;
        }
        if (jointai > p.coin) {
            p.conn.sendMessageLog("Bạn không đủ coin.");
            return;
        }
        if (p.c.xiu == true) {
            p.conn.sendMessageLog("Bạn đã đặt xỉu.");
            return;
        }
        this.totaltai += jointai;
        p.c.jointx += jointai;
        p.upcoinMessage(-jointai);
        p.c.tai = true;
        p.c.xiu = false;
        this.teamtai.add(p.c);
        p.c.datatx();
    }
    
    // đặt cược xỉu
    public void joinXiu(Player p, int joinxiu){
        if (this.time <= 10L) {
            p.conn.sendMessageLog("Đã hết thời gian đặt cược.");
            return;
        }
        if (joinxiu > p.coin) {
            p.conn.sendMessageLog("Bạn không đủ coin.");
            return;
        }
        if (p.c.tai == true) {
            p.conn.sendMessageLog("Bạn đã đặt tài.");
            return;
        }
        this.totalxiu += joinxiu;
        p.c.jointx += joinxiu;
        p.upcoinMessage(-joinxiu);
        p.c.xiu = true;
        p.c.tai = false;
        this.teamxiu.add(p.c);
        p.c.datatx();
    }
}