package com.hoiuc.server;
//Scr By SHIN
import com.hoiuc.assembly.*;
import com.hoiuc.io.Message;
import com.hoiuc.io.SQLManager;
import com.hoiuc.io.Util;
import com.hoiuc.stream.*;
import com.hoiuc.template.ItemTemplate;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
//Scr By SHIN
import java.io.IOException;
import java.sql.ResultSet;
import java.time.Instant;
import java.util.Date;
import java.util.Random;
//Scr By SHIN
public class Draw {

    public static void Draw(Player p, Message m) {
        try {
            short menuId = m.reader().readShort();
            String str = m.reader().readUTF();
            if (!str.equals("")) {
                Util.Debug("menuId " + menuId + " str " + str);
                byte b = -1;
                if (m.reader().available() > 0) {
                    try {
                        b = m.reader().readByte();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
                m.cleanup();
                switch (menuId) {
                 /*   case 1: {
                        if (p.c.quantityItemyTotal(279) <= 0) {
                            break;
                        }
                        Char c = Client.gI().getNinja(str);

                        if (c != null && c.tileMap != null && c.tileMap.map != null && !c.tileMap.map.LangCo() && c.tileMap.map.getXHD() == -1 && c.mapid != 111 && c.mapid != 133 && !c.tileMap.map.mapChienTruong() && !c.tileMap.map.mapLDGT() && !c.tileMap.map.mapBossTuanLoc() && !c.tileMap.map.mapGTC()) {
                            if (p.c.level < 60 && c.tileMap.map.VDMQ()) {
                                p.conn.sendMessageLog("Trình độ của bạn chưa đủ để di chuyển tới đây");
                                return;
                            }
                            if (p.c.tileMap.map.mapGTC() || p.c.tileMap.map.mapChienTruong() || p.c.tileMap.map.id == 111) {
                                p.c.typepk = 0;
                                Service.ChangTypePkId(p.c, (byte) 0);
                            }
                            p.c.luongTN -= 10000;
                            p.upluongMessage(-10000L);
                            p.c.tileMap.leave(p);
                            p.c.get().x = c.get().x;
                            p.c.get().y = c.get().y;
                            c.tileMap.Enter(p);
                            return;
                        }
                        p.sendAddchatYellow("Vị trí người này không thể đi tới");
                        break;
                    }*/
                 /*   case 2: {
                        Char temp = Client.gI().getNinja(str);
                        if (temp != null) {
                            Char friendNinja = p.c.tileMap.getNinja(temp.id);
                            if (friendNinja != null && friendNinja.id == p.c.id) {
                                Service.chatNPC(p, (short) 0, Language.NAME_LOI_DAI);
                            } else if (friendNinja != null && friendNinja.id != p.c.id) {
                                p.sendRequestBattleToAnother(friendNinja, p.c);
                                Service.chatNPC(p, (short) 0, Language.SEND_MESS_LOI_DAI);
                            } else {
                                Service.chatNPC(p, (short) 0, Language.NOT_IN_ZONE);
                            }
                        } else {
                            Service.chatNPC(p, (short) 0, "Người chơi này không ở trong cùng khu với con hoặc không tồn tại, ta không thể gửi lời mời!");
                        }
                        break;
                    } */
                    case 3: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericLong(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 37, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long tienCuoc = Long.parseLong(str);
                        if (tienCuoc > p.c.xu || p.c.xu < 1000) {
                            Service.chatNPC(p, (short) 37, "Con không đủ xu để đặt cược");
                            break;
                        }
                        if (tienCuoc < 1000 || tienCuoc % 50 != 0) {
                            Service.chatNPC(p, (short) 37, "Xu cược phải lớn hơn 1000 xu và chia hết cho 50");
                            break;
                        }
                        Dun dun = null;
                        if (p.c.dunId != -1) {
                            if (Dun.duns.containsKey(p.c.dunId)) {
                                dun = Dun.duns.get(p.c.dunId);
                            }
                        }
                        if (dun != null) {
                            if (dun.c1.id == p.c.id) {
                                if (dun.tienCuocTeam2 != 0 && dun.tienCuocTeam2 != tienCuoc) {
                                    Service.chatNPC(p, (short) 37, "Đối thủ của con đã đặt cược " + Util.getFormatNumber(dun.tienCuocTeam2) + " xu con hãy đặt lại đi!");
                                    return;
                                }
                                if (dun.tienCuocTeam1 != 0) {
                                    Service.chatNPC(p, (short) 37, "Con đã đặt cược trước đó rồi.");
                                    return;
                                }

                                dun.tienCuocTeam1 = tienCuoc;
                                p.c.upxuMessage(-tienCuoc);
                                Service.chatNPC(p, (short) 37, "Con đã đặt cược " + dun.tienCuocTeam1 + " xu");
                                dun.c2.p.sendAddchatYellow("Người chơi " + dun.c1.name + " đã được cược " + Util.getFormatNumber(dun.tienCuocTeam1) + " xu.");

                            } else if (dun.c2.id == p.c.id) {
                                if (dun.tienCuocTeam1 != 0 && dun.tienCuocTeam1 != tienCuoc) {
                                    Service.chatNPC(p, (short) 37, "Đối thủ của con đã đặt cược " + Util.getFormatNumber(dun.tienCuocTeam1) + " xu con hãy đặt lại đi!");
                                    return;
                                }
                                if (dun.tienCuocTeam2 != 0) {
                                    Service.chatNPC(p, (short) 37, "Con đã đặt cược trước đó rồi.");
                                    return;
                                }

                                dun.tienCuocTeam2 = tienCuoc;
                                p.c.upxuMessage(-tienCuoc);
                                Service.chatNPC(p, (short) 37, "Con đã đặt cược " + Util.getFormatNumber(dun.tienCuocTeam2) + " xu");
                                dun.c1.p.sendAddchatYellow("Người chơi " + dun.c2.name + " đã được cược " + Util.getFormatNumber(dun.tienCuocTeam2) + " xu.");
                            }

                            if (dun.tienCuocTeam1 != 0 && dun.tienCuocTeam2 != 0 && dun.tienCuocTeam1 == dun.tienCuocTeam2 && dun.team1.size() > 0 && dun.team2.size() > 0) {
                                if (dun.tienCuocTeam1 >= 1000000L) {
                                    Manager.serverChat("Server: ", "Người chơi " + dun.c1.name + " (" + dun.c1.level + ")"
                                            + " đang thách đấu với " + dun.c2.name + " (" + dun.c2.level + "): " + Util.getFormatNumber(dun.tienCuocTeam1) + " xu tại lôi đài, hãy mau mau đến xem và cổ vũ.");
                                }
                                dun.startDun();
                            }
                        } else {
                            return;
                        }
                        break;
                    }
                    case 222:
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        int jointai = Integer.parseInt(str);
                        if (jointai <= 0) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        if (jointai % 10 != 0) {
                            p.conn.sendMessageLog("Chia hết cho 10.");
                            return;
                        }
                        Server.manager.taixiu[0].joinTai(p, jointai);
                        break;
                    case 223: {
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        int joinxiu = Integer.parseInt(str);
                        if (joinxiu <= 0) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        if (joinxiu % 10 != 0) {
                            p.conn.sendMessageLog("Chia hết cho 10.");
                            return;
                        }
                        Server.manager.taixiu[0].joinXiu(p, joinxiu);
                        break;
                    }
                    case 36: {
                      Char temp = Client.gI().getNinja(str);
                        if(temp != null) {
                            Player tanghoa = Client.gI().getPlayer(temp.p.username);
                            if(tanghoa != null) {
                                if (p.c.quantityItemyTotal(1239) < 1) {
                                    p.sendAddchatYellow("Không có nhẫn cầu hôn con cặc.");
                                    break;
                                }
                                if( tanghoa.c.name == p.c.name ) {
                                    p.conn.sendMessageLog("DMM Mày nhập tên mày ăn lol à.");
                                    break;
                                }
                                 if (tanghoa.c.kethon == 1) {
                                   p.conn.sendMessageLog("Nó có Crush rồi , mày thích phá à ?");
                                     break;
                                }
                                  if (p.c.kethon == 1) {
                                   p.conn.sendMessageLog("Mày Định Ngoại Tình À?");
                                     break;
                                }
                                p.c.kethon += 1;
                                tanghoa.kethon();
                                p.updateExp(200000000L);
                                p.c.removeItemBags(1239, 1);
                                short[] arId = new short[]{1240};
                                short idI = arId[(int)Util.nextInt(arId.length)];
                                Item itemup = ItemTemplate.itemDefault(idI);
                                itemup.upgrade = 16;
                                itemup.isLock = true;
                                    p.c.addItemBag(true, itemup);
                                    p.conn.sendMessageLog("Kết hôn thành công. Tự động thoát sau 5 giây");
                                    Service.chatKTG(p.c.name + " vừa kết hôn thành công với "+ tanghoa.c.name +" .");
                                   int TimeSeconds = 5;
                                   while (TimeSeconds > 0) {
                                   TimeSeconds--;
                                   Thread.sleep(1000);
                    }
                    Client.gI().kickSession(p.conn);
                    break;
                            } else {
                                p.conn.sendMessageLog("Không tìm thấy người này!");
                            }
                        } else {
                            p.conn.sendMessageLog("Người chơi này không tồn tại hoặc không online!");
                        }
                        temp = null;
                        break;
                    }
                    //Làm Bản Đồ
                    case 558: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);

                        if (soluong <= 0) {
                            p.conn.sendMessageLog("Định bug à con trai");
                            return;
                        }
                        if (p.c.quantityItemyTotal(706) >= 50 * soluong) {
                            if (p.luong < 1000 * soluong) {
                                p.conn.sendMessageLog("Không đủ Lượng để đổi Bản đồ");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(706, (int) (50 * soluong));

                                p.upluongMessage(-(1000 * soluong));
                                Item it = ItemTemplate.itemDefault(707);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    //thechuyensinh
                   
                    case 125:{
                        switch (menuId) {
                case 0:{
                if (p.c.level < 200) {
                    p.conn.sendMessageLog( "yêu cầu lv200");
                }  else if (p.luong < 500000) {
                    p.conn.sendMessageLog( "Có trên 500k lượng ms có thể chuyển sinh!");
                }else if (p.c.xu < 5000000) {
                    p.conn.sendMessageLog( "Có trên 5m xu ms có thể chuyển sinh!");
                } else if (p.c.exptype == 0) {
                    p.conn.sendMessageLog( "mày tắt exp rồi đòi chuyển sinh cái lồn à?!");
                } else if (p.c.chuyensinh17 > 50) {
                    p.conn.sendMessageLog( "Bạn không thể chuyển sinh ở bậc này!");
                }
                else {
                    
                    p.c.chuyensinh17 ++;
                    p.updateExp(Level.getMaxExp(10) - p.c.exp);
                    // p.c.addItemBag(false, ItemData.itemDefault(454));
                    // p.c.addItemBag(false, ItemData.itemDefault(454));
                    //  p.c.addItemBag(false, ItemData.itemDefault(454));
                    // p.c.addItemBag(false, ItemData.itemDefault(454));
                    long luongUp = Util.nextInt(300000,500000);
                    p.upluongMessage(-luongUp);
                    p.c.upxuMessage(-5000000L);
                  //  p.conn.sendMessageLog( "Bạn đã được chuyển sinh mất "+luongUp+" Lượng . Bạn đã Chuyển sinh : "+p.c.chuyensinh17+" Lần.");
                   // Server.manager.chatKTG("Phàm nhân " + p.c.name + " Sau bao nỗ lực đã Chuyển sinh thành công! " );
                }
                
                
                break;
                }
                case 1:{
                if (p.c.level < 200) {
                    p.conn.sendMessageLog( "yêu cầu lv200");
                }  else if (p.luong < 1000000) {
                    p.conn.sendMessageLog( "Có trên 1000k lượng ms có thể chuyển sinh!");
                }else if (p.c.xu < 10000000) {
                    p.conn.sendMessageLog( "Có trên 10m xu ms có thể chuyển sinh!");
                } else if (p.c.exptype == 0) {
                    p.conn.sendMessageLog( "mày tắt exp rồi đòi chuyển sinh cái lồn à?!");
                } else if (p.c.chuyensinh17 < 50 ||p.c.chuyensinh17 >150 ) {
                    p.conn.sendMessageLog( "Bạn không còn phù hợp ở bậc này!");
                }
                else {
                    
                    p.c.chuyensinh17 ++;
                    p.updateExp(Level.getMaxExp(10) - p.c.exp);
                    Item it = ItemTemplate.itemDefault(770);
                    p.c.addItemBag(false,it);
                    it.quantity =10;
                    long luongUp = Util.nextInt(500000,1000000);
                    
                    p.upluongMessage(-luongUp);
                    p.c.upxuMessage(-10000000L);
                  //  p.conn.sendMessageLog( "Bạn đã được chuyển sinh mất "+luongUp+" Lượng . Bạn đã Chuyển sinh : "+p.c.chuyensinh17+" Lần.");
                   // Server.manager.chatKTG("Tiên Nhân " + p.c.name + " Chuyển sinh thành công.Tích công đức cũng đến ngày hái quả. " );
                }
                
                
                return;
            }
            case 2:{
                if (p.c.level < 200) {
                    p.conn.sendMessageLog( "yêu cầu lv200");
                }  else if (p.luong < 10000000) {
                    p.conn.sendMessageLog( "Có trên 10n lượng ms có thể chuyển sinh!");
                }else if (p.c.xu < 30000000) {
                    p.conn.sendMessageLog( "Có trên 30m xu ms có thể chuyển sinh!");
                } else if (p.c.exptype == 0) {
                    p.conn.sendMessageLog( "mày tắt exp rồi đòi chuyển sinh cái lồn à?!");
                } else if (p.c.chuyensinh17 < 150 ||p.c.chuyensinh17 >1000) {
                    p.conn.sendMessageLog( "Bạn đã vượt quá lần chuyển sinh phàm nhân mời lên cấp cao hơn!");
                }
                else {
                    
                    p.c.chuyensinh17 ++;
                    p.updateExp(Level.getMaxExp(10) - p.c.exp);
                    Item it = ItemTemplate.itemDefault(770);
                    p.c.addItemBag(false,it);
                    it.quantity = 20;
                    long luongUp = Util.nextInt(10000000,20000000);
                  
                    p.upluongMessage(-luongUp);
                    p.c.upxuMessage(-30000000L);
                  //  p.conn.sendMessageLog( "Bạn đã được chuyển sinh mất "+luongUp+" Lượng . Bạn đã Chuyển sinh : "+p.c.chuyensinh17+" Lần.");
                   // Server.manager.chatKTG("Thánh Nhân " + p.c.name + " Đã chuyển sinh! Cả Thiên hạ cùng nhau bái lạy. " );
                }
                
                
                return;
            }case 3:{
                if (p.c.level < 200) {
                    p.conn.sendMessageLog( "yêu cầu lv200");
                }  else if (p.luong < 20000000) {
                    p.conn.sendMessageLog( "Có trên 20m lượng ms có thể chuyển sinh!");
                }else if (p.c.xu < 50000000) {
                    p.conn.sendMessageLog( "Có trên 50m xu ms có thể chuyển sinh!");
                } else if (p.c.exptype == 0) {
                    p.conn.sendMessageLog( "mày tắt exp rồi đòi chuyển sinh cái lồn à?!");
                } else if (p.c.chuyensinh17 < 1000) {
                    p.conn.sendMessageLog( "Bạn không ở tầng này!");
                }
                else {
                    
                    p.c.chuyensinh17 ++;
                    p.updateExp(Level.getMaxExp(10) - p.c.exp);
                    Item it = ItemTemplate.itemDefault(770);
                    p.c.addItemBag(false,it);
                    it.quantity = 20;
                    long luongUp = Util.nextInt(20000000,30000000);
                  
                    p.upluongMessage(-luongUp);
                    p.c.upxuMessage(-50000000L);
                  //  p.conn.sendMessageLog( "Bạn đã được chuyển sinh mất "+luongUp+" Lượng . Bạn đã Chuyển sinh : "+p.c.chuyensinh17+" Lần.");
                    Server.manager.chatKTG("Cao Thủ " + p.c.name + " Đã chuyển sinh! Vô Cmn Địch rồi " );
                }
            }
                   } break;
                    }
                    //Làm Áo Phao
                    case 559: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);

                        if (soluong <= 0) {
                            p.conn.sendMessageLog("Định bug à con trai");
                            return;
                        }
                        if (p.c.quantityItemyTotal(1157) >= 500 * soluong) {
                            if (p.luong < 1000000 * soluong) {
                                p.conn.sendMessageLog("Không đủ Lượng để đổi Bản đồ");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(1157, (int) (500 * soluong));

                                p.upluongMessage(-(1000000 * soluong));
                                Item it = ItemTemplate.itemDefault(1158);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    //Làm Huy Hiệu
                    case 560: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);

                        if (soluong <= 0) {
                            p.conn.sendMessageLog("Định bug à con trai");
                            return;
                        }
                        if (p.c.quantityItemyTotal(1156) >= 100 * soluong) {
                            if (p.luong < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ Lượng để đổi Bản đồ");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(1156, (int) (100 * soluong));

                                p.upluongMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(1159);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
// Tre xanh trăm đốt
                    case 20: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || check.equals("0") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (p.c.quantityItemyTotal(590) >= 100 * soluong) {
                            if (soluong <= 0) {
                                p.conn.sendMessageLog("Có cái nịt");
                                return;
                            }
                            if (p.c.xu < 30000L * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(590, (int) (100 * soluong));
                                p.c.upxuMessage(-(30000L * soluong));
                                Item it = ItemTemplate.itemDefault(592);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                                Service.chatNPC(p, (short) 33, "Khắc Nhập - Khắc Xuất.");
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    case 148: {
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        String check = str.replaceAll(" ", "").trim();
                        long quantity = Long.parseLong(check);
                        if (quantity < 0) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        switch (p.menuIdAuction) {
                            case 2: {
                                if ((quantity + p.luong > 2000000000) || (p.luong2 - quantity < 0)) {
                                    p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                                    return;
                                }
                                p.luong2 -= quantity;
                                p.upluongMessage(quantity);
                                p.sendAddchatYellow("Bạn đã rút thành công " + Util.getFormatNumber(quantity) + " lượng");
                                break;
                            }
                            case 1: {
                                if ((quantity + p.c.xu > 2000000000) || (p.xu2 - quantity < 0)) {
                                    p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                                    return;
                                }
                                p.xu2 -= quantity;
                                p.c.upxuMessage(quantity);
                                p.sendAddchatYellow("Bạn đã rút thành công " + Util.getFormatNumber(quantity) + " xu");
                                break;
                            }
                            case 0: {
                                if ((quantity + p.c.yen > 2000000000) || (p.yen2 - quantity < 0)) {
                                    p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                                    return;
                                }
                                p.yen2 -= quantity;
                                p.c.upyenMessage(quantity);
                                p.sendAddchatYellow("Bạn đã rút thành công " + Util.getFormatNumber(quantity) + " yên");
                                break;
                            }
                            default: {
                                p.conn.sendMessageLog("Co loi xay ra, hay thu lai");
                                break;
                            }
                        }
                        p.menuIdAuction = 0;
                        break;
                    }
                    case 246: {
                       
                       
                        if (str == null || str.trim().isEmpty()) {
                            p.conn.sendMessageLog("Bạn chưa nhập số nào. Vui lòng nhập số trong khoảng 00-99.");
                            return;
                        }
                        String check = str.trim();
                        if (!check.matches("\\d{2}")) {
                            p.conn.sendMessageLog("Số bạn nhập không hợp lệ! Vui lòng nhập số trong khoảng 00-99.");
                            return;
                        }
                        int soDaChon = Integer.parseInt(check);
                        if (soDaChon < 0 || soDaChon > 99) {
                            p.conn.sendMessageLog("Số bạn nhập không hợp lệ! Vui lòng nhập số trong khoảng 00-99.");
                            return;
                        }
                        p.c.setInputNumber(soDaChon);
                        Thread.sleep(1 / 2 * 1000);
                        p.conn.sendMessageLog("Bạn đã chọn số " + soDaChon + ". Đợi kết quả...");
                        Thread.sleep(5 * 1000);
                        for (int i = 5; i > 0; i--) {
                            p.conn.sendMessageLog("Thời gian còn lại: " + i + " giây...");
                            Thread.sleep(1000); 
                        }
                        p.conn.sendMessageLog("Đang xử lý kết quả...");

                        Thread.sleep(2000); 
                        Random rand = new Random();
                        int ketQua = rand.nextInt(100);  

                        p.conn.sendMessageLog("Kết quả xổ số là: " + ketQua);

                        if (soDaChon == ketQua) {
                            p.c.setInputNumber(soDaChon); 
                            long soLuongThuong = 70;
                            
                            short itemThuongId = (short) 1439;

                           
                            Item itemThuong = new Item();
                            itemThuong.id = itemThuongId;
                            itemThuong.quantity = (int) soLuongThuong;
                            itemThuong.isLock = false;
                            itemThuong.isExpires = false;

                          
                            boolean added = p.c.addItemBag(true, itemThuong);
                            if (added) {
                                p.conn.sendMessageLog("Chúc mừng! Bạn đã trúng thưởng và nhận được " + soLuongThuong + " Rương Sổ Xố ");
                                Manager.chatKTG("Người chơi " + p.c.name + " tham gia đặt cược con số  " + soDaChon + " đã trúng giải độc đắc.. Xin chúc mừng ");
                            } else {
                                p.conn.sendMessageLog("Rất tiếc, không thể thêm item vào túi đồ. Túi đồ của bạn đã đầy!");
                            }
                        } else {
                          
                            p.conn.sendMessageLog("Rất tiếc, bạn đã không trúng thưởng. Hãy thử lại lần sau!");
                            Manager.chatKTG("Người chơi " + p.c.name + " đã tham gia đặt cược con số  " + soDaChon );
                        }

                        break;
                    }
                    case 149: {
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        String check = str.replaceAll(" ", "").trim();
                        long quantity = Long.parseLong(check);
                        if ((quantity < 0) || (quantity > 2)) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        p.menuIdAuction = (int) quantity;
                        Service.sendInputDialog(p, (short) 148, "Nhập số lượng");
                        break;
                    }
                    case 150: {
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        String check = str.replaceAll(" ", "").trim();
                        double quantity = Double.parseDouble(check);
                        if ((quantity <= 0) || (quantity > p.c.ppoint2)) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        p.c.get().potential0 += quantity;
                        p.c.get().ppoint2 -= quantity;
                        if (p.c.get().ppoint2 >= 32000) {
                            p.c.get().ppoint = 32000;
                        } else {
                            p.c.get().ppoint = (short) p.c.get().ppoint2;
                        }
                        p.c.get().upHP(p.c.get().getMaxHP());
                        p.c.get().upMP(p.c.get().getMaxMP());
                        p.loadPpoint();
                        p.conn.sendMessageLog("Tăng thành công " + Util.getFormatNumber(quantity) + " tiềm năng vào sức mạnh");
                        break;
                    }
                    case 151: {
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        String check = str.replaceAll(" ", "").trim();
                        double quantity = Double.parseDouble(check);
                        if ((quantity <= 0) || (quantity > p.c.ppoint2)) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        p.c.get().potential1 += quantity;
                        p.c.get().ppoint2 -= quantity;
                        if (p.c.get().ppoint2 >= 32000) {
                            p.c.get().ppoint = 32000;
                        } else {
                            p.c.get().ppoint = (short) p.c.get().ppoint2;
                        }
                        p.c.get().upHP(p.c.get().getMaxHP());
                        p.c.get().upMP(p.c.get().getMaxMP());
                        p.loadPpoint();
                        p.conn.sendMessageLog("Tăng thành công " + Util.getFormatNumber(quantity) + " tiềm năng vào thân pháp");
                        break;
                    }
                    case 152: {
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        String check = str.replaceAll(" ", "").trim();
                        double quantity = Double.parseDouble(check);
                        if ((quantity <= 0) || (quantity > p.c.ppoint2)) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        p.c.get().potential2 += quantity;
                        p.c.get().ppoint2 -= quantity;
                        if (p.c.get().ppoint2 >= 32000) {
                            p.c.get().ppoint = 32000;
                        } else {
                            p.c.get().ppoint = (short) p.c.get().ppoint2;
                        }
                        p.c.get().upHP(p.c.get().getMaxHP());
                        p.c.get().upMP(p.c.get().getMaxMP());
                        p.loadPpoint();
                        p.conn.sendMessageLog("Tăng thành công " + Util.getFormatNumber(quantity) + " tiềm năng vào thể lực");
                        break;
                    }
                    case 153: {
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        String check = str.replaceAll(" ", "").trim();
                        double quantity = Double.parseDouble(check);
                        if ((quantity <= 0) || (quantity > p.c.ppoint2)) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        p.c.get().potential3 += quantity;
                        p.c.get().ppoint2 -= quantity;
                        if (p.c.get().ppoint2 >= 32000) {
                            p.c.get().ppoint = 32000;
                        } else {
                            p.c.get().ppoint = (short) p.c.get().ppoint2;
                        }
                        p.c.get().upHP(p.c.get().getMaxHP());
                        p.c.get().upMP(p.c.get().getMaxMP());
                        p.loadPpoint();
                        p.conn.sendMessageLog("Tăng thành công " + Util.getFormatNumber(quantity) + " tiềm năng vào Chakra");
                        break;
                    }
                    // tre vàng trăm đốt
                    case 21: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || check.equals("0") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (p.c.quantityItemyTotal(591) >= 100 * soluong) {
                            if (soluong <= 0) {
                                p.conn.sendMessageLog("Có cái nịt");
                                return;
                            }
                            if (p.c.xu < 7L * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(591, (int) (100 * soluong));
                                p.upluongMessage(-(7L * soluong));
                                Item it = ItemTemplate.itemDefault(593);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                                Service.chatNPC(p, (short) 33, "Khắc Nhập - Khắc Xuất.");
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    case 10: {
                        p.passnew = "";
                        p.passold = str;
                        p.changePassword();
                        Server.menu.sendWrite(p, (short) 11, "Nhập mật khẩu mới");
                        break;
                    }
                    case 11: {
                        p.passnew = str;
                        p.changePassword();
                        break;
                    }
                    //gift code
                    case 4: {
                        String check = str.replaceAll("\\s+", "");
                        if (check.equals("")) {
                            p.conn.sendMessageLog("Mã Gift code nhập vào không hợp lệ.");
                            break;
                        }
                        check = check.toUpperCase();
                        try {
                            synchronized (Server.LOCK_MYSQL) {
                                ResultSet red = SQLManager.stat.executeQuery("SELECT * FROM `gift_code` WHERE `code` LIKE '" + check + "';");
                                if (red != null && red.first()) {
                                    int id = red.getInt("id");
                                    String code = red.getString("code");
                                    JSONArray jar = (JSONArray) JSONValue.parse(red.getString("item_id"));
                                    if (p.c.getBagNull() < jar.size()) {
                                        p.conn.sendMessageLog(Language.NOT_ENOUGH_BAG);
                                        break;
                                    }
                                    int j;
                                    int[] itemId = new int[jar.size()];
                                    for (j = 0; j < jar.size(); j++) {
                                        itemId[j] = Integer.parseInt(jar.get(j).toString());
                                    }
                                    jar = (JSONArray) JSONValue.parse(red.getString("item_quantity"));
                                    long[] itemQuantity = new long[jar.size()];
                                    for (j = 0; j < jar.size(); j++) {
                                        itemQuantity[j] = Long.parseLong(jar.get(j).toString());
                                    }
                                    jar = (JSONArray) JSONValue.parse(red.getString("item_isLock"));
                                    byte[] itemIsLock = new byte[jar.size()];
                                    for (j = 0; j < jar.size(); j++) {
                                        itemIsLock[j] = Byte.parseByte(jar.get(j).toString());
                                    }
                                    jar = (JSONArray) JSONValue.parse(red.getString("item_expires"));
                                    long[] itemExpires = new long[jar.size()];
                                    for (j = 0; j < jar.size(); j++) {
                                        itemExpires[j] = Long.parseLong(jar.get(j).toString());
                                    }

                                    int isPlayer = red.getInt("isPlayer");
                                    int isTime = red.getInt("isTime");
                                    if (isPlayer == 1) {
                                        jar = (JSONArray) JSONValue.parse(red.getString("player"));
                                        boolean checkUser = false;
                                        for (j = 0; j < jar.size(); j++) {
                                            if (jar.get(j).toString().equals(p.username)) {
                                                checkUser = true;
                                                break;
                                            }
                                        }
                                        if (!checkUser) {
                                            p.conn.sendMessageLog("Bạn không thể sử dụng mã Gift Code này.");
                                            red.close();
                                            break;
                                        }
                                    }
                                    if (isTime == 1) {
                                        if (Date.from(Instant.now()).compareTo(Util.getDate(red.getString("time"))) > 0) {
                                            p.conn.sendMessageLog("Mã Gift code này đã hết hạn sử dụng.");
                                            red.close();
                                            break;
                                        }
                                    }
                                    red.close();
                                    red = SQLManager.stat.executeQuery("SELECT * FROM `history_gift` WHERE `player_id` = " + p.id + " AND `code` = '" + code + "';");
                                    if (red != null && red.first()) {
                                        p.conn.sendMessageLog("Bạn đã sử dụng mã Gift code này rồi.");
                                    } else {
                                        if (itemId.length == itemQuantity.length) {
                                            ItemTemplate data2;
                                            int i;
                                            for (i = 0; i < itemId.length; i++) {
                                                if (itemId[i] == -4) {
                                                    p.coin+=(itemQuantity[i]);                                                    
                                                } else if (itemId[i] == -5) {
                                                    p.c.vnd+=(itemQuantity[i]);
                                                } else if (itemId[i] == -6) {
                                                    p.c.atm+=(itemQuantity[i]);        
                                                } else if (itemId[i] == -3) {
                                                    p.c.upyenMessage(itemQuantity[i]);
                                                } else if (itemId[i] == -2) {
                                                    p.c.upxuMessage(itemQuantity[i]);
                                                } else if (itemId[i] == -1) {
                                                    p.upluongMessage(itemQuantity[i]);
                                                } else {
                                                    data2 = ItemTemplate.ItemTemplateId(itemId[i]);
                                                    if (data2 != null) {
                                                        Item itemup;
                                                        if (data2.type < 10) {
                                                            if (data2.type == 1) {
                                                                itemup = ItemTemplate.itemDefault(itemId[i]);
                                                                itemup.sys = GameSrc.SysClass(data2.nclass);
                                                            } else {
                                                                byte sys = (byte) Util.nextInt(1, 3);
                                                                itemup = ItemTemplate.itemDefault(itemId[i], sys);
                                                            }
                                                        } else {
                                                            itemup = ItemTemplate.itemDefault(itemId[i]);
                                                        }
                                                        itemup.quantity = (int) itemQuantity[i];
                                                        if (itemIsLock[i] == 0) {
                                                            itemup.isLock = false;
                                                        } else {
                                                            itemup.isLock = true;
                                                        }
                                                        if (itemExpires[i] != -1) {
                                                            itemup.isExpires = true;
                                                            itemup.expires = System.currentTimeMillis() + itemExpires[i];
                                                        } else {
                                                            itemup.isExpires = false;
                                                        }
                                                        p.c.addItemBag(true, itemup);
                                                    }
                                                }
                                            }
                                            String sqlSET = "(" + p.id + ", '" + code + "', '" + Util.toDateString(Date.from(Instant.now())) + "', '" + Util.toDateString(Date.from(Instant.now())) + "', '" + Util.toDateString(Date.from(Instant.now())) + "');";
                                            SQLManager.stat.executeUpdate("INSERT INTO `history_gift` (`player_id`,`code`,`time`, `created_at`, `updated_at`) VALUES " + sqlSET);
                                        } else {
                                            p.conn.sendMessageLog("Lỗi xác nhận mã Gift code. Hãy liên hệ Admin để biết thêm chi tiết.");
                                        }
                                    }
                                    jar.clear();
                                    red.close();
                                    break;
                                } else {
                                    p.conn.sendMessageLog("Mã Gift code này đã được sử dụng hoặc không tồn tại.");
                                    red.close();
                                    break;
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }

                    //Mời gia tộc chiến
                    case 5: {
                        ClanManager temp = ClanManager.getClanName(str);
                        ClanManager temp2 = ClanManager.getClanName(p.c.clan.clanName);
                        if (temp != null) {
                            String tocTruong = temp.getmain_name();
                            Char _charTT = Client.gI().getNinja(tocTruong);
                            if (_charTT != null && _charTT.id == p.c.id) {
                                Service.chatNPC(p, (short) 32, "Ngươi muốn thách đấu gia tộc của chính mình à.");
                            } else if (_charTT != null && _charTT.id != p.c.id) {
                                if (temp.gtcID != -1 && temp.gtcClanName != null) {
                                    Service.chatNPC(p, (short) 32, "Gia tộc này đang có lời mời từ gia tộc khác");
                                    temp.gtcID = -1;
                                    return;
                                }
                                Service.startYesNoDlg(_charTT.p, (byte) 4, "Gia tộc " + p.c.clan.clanName + " muốn thách đấu với gia tộc của bạn. Bạn có đồng ý?");
                                GiaTocChien giaTocChien = new GiaTocChien();
                                temp.gtcID = giaTocChien.gtcID;
                                temp.gtcClanName = p.c.clan.clanName;
                                temp2.gtcID = giaTocChien.gtcID;
                                temp2.gtcClanName = str;
                                Service.chatNPC(p, (short) 32, "Ta đã gửi lời mời thách đấu tới gia tộc " + str);
                            } else {
                                Service.chatNPC(p, (short) 32, "Tộc trưởng gia tộc đối phương không online hoặc không tồn tại. Không thể gửi lời mời.");
                            }
                        } else {
                            Service.chatNPC(p, (short) 32, "Gia tộc này không tồn tại, ta không thể gửi lời mời!");
                        }
                        break;
                    }

                    //Làm bánh chocolate
                    case 6: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (p.c.quantityItemyTotal(666) >= 2 * soluong && p.c.quantityItemyTotal(667) >= 2 * soluong && p.c.quantityItemyTotal(668) >= 3 * soluong && p.c.quantityItemyTotal(669) >= 1 * soluong) {
                            if (p.c.yen < 5000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(666, (int) (2 * soluong));
                                p.c.removeItemBags(667, (int) (2 * soluong));
                                p.c.removeItemBags(668, (int) (3 * soluong));
                                p.c.removeItemBags(669, (int) (1 * soluong));
                                p.c.upyenMessage(-(5000 * soluong));
                                Item it = ItemTemplate.itemDefault(671);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }//Làm hop banh thuong
                    case 1995 : {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                             p.conn.sendMessageLog("Bug cái lồn mẹ mày");
                             return;
                        }
                        if (p.c.quantityItemyTotal(298) >= 1 * soluong && p.c.quantityItemyTotal(299) >= 1 * soluong && p.c.quantityItemyTotal(300) >= 1 * soluong && p.c.quantityItemyTotal(301) >= 1 * soluong && p.c.quantityItemyTotal(304) >= 1 * soluong) {
                            if (p.c.yen < 5000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(298, (int) (1 * soluong));
                                p.c.removeItemBags(299, (int) (1 * soluong));
                                p.c.removeItemBags(300, (int) (1 * soluong));
                                p.c.removeItemBags(301, (int) (1 * soluong));
                                p.c.removeItemBags(304, (int) (1 * soluong));
                                p.c.upyenMessage(-(5000 * soluong));
                                Item it = ItemTemplate.itemDefault(302);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }//Làm hop banh thuong hang
                    case 1996 : {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                             p.conn.sendMessageLog("Bug cái lồn mẹ mày");
                             return;
                        }
                        if (p.c.quantityItemyTotal(298) >= 1 * soluong && p.c.quantityItemyTotal(299) >= 1 * soluong && p.c.quantityItemyTotal(300) >= 1 * soluong && p.c.quantityItemyTotal(301) >= 1 * soluong && p.c.quantityItemyTotal(305) >= 1 * soluong) {
                            if (p.c.xu < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(298, (int) (1 * soluong));
                                p.c.removeItemBags(299, (int) (1 * soluong));
                                p.c.removeItemBags(300, (int) (1 * soluong));
                                p.c.removeItemBags(301, (int) (1 * soluong));
                                p.c.removeItemBags(305, (int) (1 * soluong));
                                p.c.upxuMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(303);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }//Làm banh thap cam
                    case 1997 : {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                             p.conn.sendMessageLog("Bug cái lồn mẹ mày");
                             return;
                        }
                        if (p.c.quantityItemyTotal(292) >= 3 * soluong && p.c.quantityItemyTotal(293) >= 2 * soluong && p.c.quantityItemyTotal(294) >= 3 * soluong) {
                            if (p.c.yen < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(292, (int) (3 * soluong));
                                p.c.removeItemBags(293, (int) (2 * soluong));
                                p.c.removeItemBags(294, (int) (3 * soluong));
                               
                                p.c.upyenMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(298);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }//Làm banh deo
                    case 1998 : {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                             p.conn.sendMessageLog("Bug cái lồn mẹ mày");
                             return;
                        }
                        if (p.c.quantityItemyTotal(292) >= 2 * soluong && p.c.quantityItemyTotal(295) >= 3 * soluong && p.c.quantityItemyTotal(294) >= 2 * soluong) {
                            if (p.c.yen < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(292, (int) (2 * soluong));
                                p.c.removeItemBags(293, (int) (3 * soluong));
                                p.c.removeItemBags(294, (int) (2 * soluong));
                               
                                p.c.upyenMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(299);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    //Làm banh dau xanh
                    case 1999 : {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                             p.conn.sendMessageLog("Bug cái lồn mẹ mày");
                             return;
                        }
                        if (p.c.quantityItemyTotal(292) >= 2 * soluong && p.c.quantityItemyTotal(295) >= 3 * soluong && p.c.quantityItemyTotal(297) >= 3 * soluong) {
                            if (p.c.yen < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(292, (int) (2 * soluong));
                                p.c.removeItemBags(295, (int) (3 * soluong));
                                p.c.removeItemBags(297, (int) (3 * soluong));
                               
                                p.c.upyenMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(300);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }//Làm banh pia
                    case 2000 : {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                             p.conn.sendMessageLog("Bug cái lồn mẹ mày");
                             return;
                        }
                        if (p.c.quantityItemyTotal(292) >= 2 * soluong && p.c.quantityItemyTotal(296) >= 2 * soluong && p.c.quantityItemyTotal(297) >= 3 * soluong) {
                            if (p.c.yen < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(292, (int) (2 * soluong));
                                p.c.removeItemBags(296, (int) (2 * soluong));
                                p.c.removeItemBags(297, (int) (3 * soluong));
                               
                                p.c.upyenMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(301);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    case 2001 : {//làm huy hiệu nsotruong
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                             p.conn.sendMessageLog("Bug cái lồn mẹ mày");
                             return;
                        }
                        if (p.c.quantityItemyTotal(648) >= 100 * soluong && p.c.quantityItemyTotal(649) >= 100 * soluong && p.c.quantityItemyTotal(650) >= 100 * soluong&& p.c.quantityItemyTotal(651) >= 100 * soluong) {
                            if (p.c.xu < 50000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm ");
                                return;
                            }
                            if (p.luong < 5000 * soluong) {
                                p.conn.sendMessageLog("Không đủ Lượng để làm");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(648, (int) (100 * soluong));
                                p.c.removeItemBags(649, (int) (100 * soluong));
                                p.c.removeItemBags(650, (int) (100 * soluong));
                                p.c.removeItemBags(651, (int) (100 * soluong));
                                p.c.upxuMessage(-(50000 * soluong));
                                p.upluongMessage(-(5000 * soluong));
                                Item it = ItemTemplate.itemDefault(663);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                                
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    //Làm bánh dâu tây
                    case 7: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (p.c.quantityItemyTotal(666) >= 3 * soluong && p.c.quantityItemyTotal(667) >= 3 * soluong && p.c.quantityItemyTotal(668) >= 4 * soluong && p.c.quantityItemyTotal(670) >= 1 * soluong) {
                            if (p.c.yen < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(666, (int) (3 * soluong));
                                p.c.removeItemBags(667, (int) (3 * soluong));
                                p.c.removeItemBags(668, (int) (4 * soluong));
                                p.c.removeItemBags(670, (int) (1 * soluong));
                                p.c.upyenMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(672);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    //Làm diều giấy
                    case 555: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);

                        if (p.c.quantityItemyTotal(434) >= 100 * soluong) {
                            if (soluong <= 0) {
                                p.conn.sendMessageLog("Định bug à con trai");
                                return;
                            }
                            if (p.c.quantityItemyTotal(432) >= 1 * soluong && p.c.quantityItemyTotal(428) >= 3 * soluong && p.c.quantityItemyTotal(429) >= 2 * soluong && p.c.quantityItemyTotal(430) >= 3 * soluong) {
                                if (p.c.yen < 5000 * soluong) {
                                    p.conn.sendMessageLog("Không đủ yên để làm bánh");
                                    return;
                                }
                                if (p.c.getBagNull() == 0) {
                                    p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                                } else {
                                    p.c.removeItemBags(432, (int) (1 * soluong));
                                    p.c.removeItemBags(428, (int) (3 * soluong));
                                    p.c.removeItemBags(429, (int) (2 * soluong));
                                    p.c.removeItemBags(430, (int) (3 * soluong));
                                    p.c.upyenMessage(-(5000 * soluong));
                                    Item it = ItemTemplate.itemDefault(434);
                                    it.quantity = (int) (1 * soluong);
                                    p.c.addItemBag(true, it);
                                }
                                return;
                            } else {
                                Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                            }
                            break;
                        }
                    }
                    //Làm diều vải
                    case 556: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                            p.conn.sendMessageLog("Định bug à con trai");
                            return;
                        }
                        if (p.c.quantityItemyTotal(433) >= 1 * soluong && p.c.quantityItemyTotal(428) >= 2 * soluong && p.c.quantityItemyTotal(429) >= 3 * soluong && p.c.quantityItemyTotal(430) >= 2 * soluong) {
                            if (p.c.yen < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(433, (int) (1 * soluong));
                                p.c.removeItemBags(428, (int) (2 * soluong));
                                p.c.removeItemBags(429, (int) (3 * soluong));
                                p.c.removeItemBags(430, (int) (2 * soluong));
                                p.c.upyenMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(435);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    //Làm Xe Tăng
                    case 557: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);

                        if (soluong <= 0) {
                            p.conn.sendMessageLog("Định bug à con trai");
                            return;
                        }
                        if (p.c.quantityItemyTotal(919) >= 200 * soluong && p.c.quantityItemyTotal(920) >= 200 * soluong && p.c.quantityItemyTotal(921) >= 200 * soluong && p.c.quantityItemyTotal(922) >= 200 * soluong && p.c.quantityItemyTotal(923) >= 200 * soluong) {
                            if (p.c.yen < 5000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để đổi Xe tăng");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(919, (int) (200 * soluong));
                                p.c.removeItemBags(920, (int) (200 * soluong));
                                p.c.removeItemBags(921, (int) (200 * soluong));
                                p.c.removeItemBags(922, (int) (200 * soluong));
                                p.c.removeItemBags(923, (int) (200 * soluong));
                                p.c.upyenMessage(-(5000 * soluong));
                                Item it = ItemTemplate.itemDefault(925);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }

                    //Làm bánh chưng
                    case 666: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (p.c.quantityItemyTotal(638) >= 2 * soluong && p.c.quantityItemyTotal(639) >= 2 * soluong && p.c.quantityItemyTotal(641) >= 3 * soluong && p.c.quantityItemyTotal(642) >= 1 * soluong) {
                            if (p.c.yen < 10000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(638, (int) (2 * soluong));
                                p.c.removeItemBags(639, (int) (2 * soluong));
                                p.c.removeItemBags(641, (int) (3 * soluong));
                                p.c.removeItemBags(642, (int) (1 * soluong));
                                p.c.upyenMessage(-(10000 * soluong));
                                Item it = ItemTemplate.itemDefault(643);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    //Làm bánh Tét
                    case 667: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (p.c.quantityItemyTotal(638) >= 3 * soluong && p.c.quantityItemyTotal(639) >= 3 * soluong && p.c.quantityItemyTotal(640) >= 1 * soluong && p.c.quantityItemyTotal(642) >= 2 * soluong) {
                            if (p.c.yen < 20000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm bánh");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(638, (int) (3 * soluong));
                                p.c.removeItemBags(639, (int) (3 * soluong));
                                p.c.removeItemBags(640, (int) (1 * soluong));
                                p.c.removeItemBags(641, (int) (2 * soluong));
                                p.c.upyenMessage(-(20000 * soluong));
                                Item it = ItemTemplate.itemDefault(644);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }
                    //pháo
                    case 112: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 33, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (p.c.quantityItemyTotal(674) >= 10 * soluong) {
                            if (p.c.yen < 30000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm Pháo");
                                return;
                            }
                            if (p.c.xu < 30000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm Pháo");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(674, (int) (10 * soluong));
                                p.c.upyenMessage(-(30000 * soluong));
                                p.c.upxuMessage(-(30000 * soluong));
                                Item it = ItemTemplate.itemDefault(675);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 33, "Hành trang của con không có đủ nguyên liệu");
                        }
                        break;
                    }

//đổi coin 
                   case 2002: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 24, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong < 0) {
                                p.conn.sendMessageLog("bug con mẹ mày");
                                return;
                            }if (p.coin <  soluong) {
                                p.conn.sendMessageLog("Không đủ Coin để đổi");
                                return;
                            }
                             else {
                                
                                p.coin -= soluong;
                                p.upluongMessage(100 * soluong);
                                p.conn.sendMessageLog("bạn nhận đc "+100 * soluong+" Lượng.");
                            }
                            return;
                        }
                   case 2003: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 24, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong < 0) {
                                p.conn.sendMessageLog("bug con mẹ mày");
                                return;
                            }if (p.coin <  soluong) {
                                p.conn.sendMessageLog("Không đủ Coin để đổi");
                                return;
                            }
                             else {
                                
                                p.coin -= soluong;
                                p.c.upxuMessage(30000 * soluong);
                                p.conn.sendMessageLog("bạn nhận đc "+30000 * soluong+" Xu.");
                            }
                            return;
                        }
                       
                    ///ttt trung
                    case 96: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 16, "Giá trị nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                            p.conn.sendMessageLog("Định bug à con trai");
                            return;
                        }
                        if (p.c.quantityItemyTotal(455) >= 10 * soluong) {
                            if (p.c.yen < 300000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm TTTT");
                                return;
                            }
                            if (p.c.xu < 30000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm TTTT");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(455, (int) (10 * soluong));
                                p.c.upyenMessage(-(30000 * soluong));
                                p.c.upxuMessage(-(30000 * soluong));
                                Item it = ItemTemplate.itemDefault(456);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 16, "Hành trang của con không có đủ TTTS");
                        }
                        break;
                    }
                    //ttt cao
                    case 97: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 16, "Giá trị nhập vào không đúng");
                            break;
                        }
                        long soluong = Integer.parseInt(str);
                        if (soluong <= 0) {
                            p.conn.sendMessageLog("Định bug à con trai");
                            return;
                        }
                        if (p.c.quantityItemyTotal(456) >= 10 * soluong) {
                            if (p.c.yen < 1000000 * soluong) {
                                p.conn.sendMessageLog("Không đủ yên để làm TTTC");
                                return;
                            }
                            if (p.c.xu < 100000 * soluong) {
                                p.conn.sendMessageLog("Không đủ xu để làm TTTC");
                                return;
                            }
                            if (p.c.getBagNull() == 0) {
                                p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            } else {
                                p.c.removeItemBags(456, (int) (10 * soluong));
                                p.c.upyenMessage(-(100000 * soluong));
                                p.c.upxuMessage(-(100000 * soluong));
                                Item it = ItemTemplate.itemDefault(457);
                                it.quantity = (int) (1 * soluong);
                                p.c.addItemBag(true, it);
                            }
                            return;
                        } else {
                            Service.chatNPC(p, (short) 16, "Hành trang của con không có đủ TTTS");
                        }
                        break;
                    }
                    case 95: {
                       p.nameUS = str;
                        Char n = Client.gI().getNinja(str);
                        if (n != null) {
                        Server.manager.sendTB(p, "Thông Tin","Tên: "+n.p.c.name+""
                                + "\n Cấp Độ : "+n.p.c.level+""
                                + "\n Hành trang : "+n.p.c.maxluggage+ " ô."
                                + "\n--------------------"
                                + "\n TN Chưa Cộng :"+Util.getFormatNumber(n.p.c.ppoint2)+""
                                + "\n Sức mạnh :"+Util.getFormatNumber(n.p.c.potential0)+""
                                + "\n Thân Pháp : "+Util.getFormatNumber(n.p.c.potential1)+""
                                + "\n Thể Lực :"+Util.getFormatNumber(n.p.c.potential2)+""
                                + "\n Chakra :"+Util.getFormatNumber(n.p.c.potential3)+""
                                + "\n--------------------"
                                + "\n Dame : " + Util.getFormatNumber((float) n.p.c.dameMin())+ "-"+Util.getFormatNumber((double)n.p.c.dameMax())+"."
                                + "\n Hp :"+ Util.getFormatNumber((double)n.p.c.hp) + "."
                                + "\n Mp : "+Util.getFormatNumber((double)n.p.c.mp)+"."
                                + "\n Né : "+Util.getFormatNumber((double)n.p.c.Miss())+""
                                + "\n Chính Xác :"+Util.getFormatNumber((double) n.p.c.Exactly())+""
                                + "\n Chí Mạng : "+Util.getFormatNumber((double)n.p.c.Fatal())+".");
                            n.p.sendAddchatYellow(p.c.name + " đang đứng nhìn bạn");
                        } else {
                            p.sendAddchatYellow("Người chơi không tồn tại hoặc không online");
                        }
                        break;
                    }
                    case 41_0:
                        p.nameUS = str;
                        Char n = Client.gI().getNinja(str);
                        
                        if (n != null) {
                            Service.sendInputDialog(p, (short) 41_0_0, "ID vật phẩm :");
                        } else {
                            p.sendAddchatYellow("Người chơi không tồn tại hoặc không online");
                        }
                        break;
                    case 41_0_0:
                        p.idItemGF = str;
                        if (p.idItemGF != null) {
                            Service.sendInputDialog(p, (short) 41_0_1, "Nhập số lượng :");
                        } else {
                            p.sendAddchatYellow("Nhập sai");
                        }
                        break;
                    case 41_0_1:
                        
                        p.itemQuantityGF = str;
                        p.sendItem();
                        
                        break;
                    case 41_1:
                        p.nameUS = str;
                        Char u = Client.gI().getNinja(str);
                        if (u != null) {
                            Service.sendInputDialog(p, (short) 41_1_0, "ID vật phẩm :");
                        } else {
                            p.sendAddchatYellow("Người chơi không tồn tại hoặc không online");
                        }
                        break;
                    case 41_1_0:
                        p.idItemGF = str;
                        if (p.idItemGF != null) {
                            Service.sendInputDialog(p, (short) 41_1_1, "Nhập số lượng :");
                        } else {
                            p.sendAddchatYellow("Nhập sai");
                        }
                        break;
                    case 41_1_1:
                        p.itemQuantityGF = str;
                        if (p.idItemGF != null) {
                            Service.sendInputDialog(p, (short) 41_1_2, "Nhập cấp độ cho trang bị :");
                        } else {
                            p.sendAddchatYellow("Nhập sai");
                        }
                        break;
                    case 41_1_2:
                        p.itemUpgradeGF = str;
                        if (p.idItemGF != null) {
                            Service.sendInputDialog(p, (short) 41_1_3, "Nhập hệ trang bị:");
                        } else {
                            p.sendAddchatYellow("Nhập sai");
                        }
                        break;
                    case 41_1_3:
                        p.itemSysGF = str;
                        p.sendTB();
                        break;
                    //Đặt cược gia tộc chiến
                    case 8: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericLong(str) || check.equals("") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 37, "Giá trị tiền cược nhập vào không đúng");
                            break;
                        }
                        long tienCuoc = Long.parseLong(str);
                        ClanManager clanManager = ClanManager.getClanName(p.c.clan.clanName);
                        if (tienCuoc > clanManager.coin || clanManager.coin < 1000) {
                            Service.chatNPC(p, (short) 40, "Gia tộc của con không đủ ngân sách để đặt cược.");
                            break;
                        }
                        if (tienCuoc < 1000 || tienCuoc % 50 != 0) {
                            Service.chatNPC(p, (short) 40, "Xu cược phải lớn hơn 1000 xu và chia hết cho 50");
                            break;
                        }
                        GiaTocChien gtc = null;
                        if (clanManager.gtcID != -1) {
                            if (GiaTocChien.gtcs.containsKey(clanManager.gtcID)) {
                                gtc = GiaTocChien.gtcs.get(clanManager.gtcID);
                            }
                        }
                        if (gtc != null) {
                            if (gtc.clan1.id == clanManager.id) {
                                if (gtc.tienCuoc2 != 0 && gtc.tienCuoc2 != tienCuoc) {
                                    Service.chatNPC(p, (short) 40, "Gia tộc đối thủ của con đã đặt cược " + Util.getFormatNumber(gtc.tienCuoc2) + " xu con hãy đặt lại đi!");
                                    return;
                                }
                                if (gtc.tienCuoc1 != 0) {
                                    Service.chatNPC(p, (short) 37, "Gia tộc của con đã đặt cược trước đó rồi.");
                                    return;
                                }

                                gtc.tienCuoc1 = tienCuoc;
                                clanManager.coin -= tienCuoc;
                                Service.chatNPC(p, (short) 40, "Con đã đặt cược " + gtc.tienCuoc1 + " xu");
                                if (gtc.gt2.size() > 0) {
                                    for (int i = 0; i < gtc.gt2.size(); i++) {
                                        gtc.gt2.get(i).p.sendAddchatYellow("Gia tộc " + clanManager.name + " đã được cược " + Util.getFormatNumber(gtc.tienCuoc1) + " xu.");
                                    }
                                }

                            } else if (gtc.clan2.id == clanManager.id) {
                                if (gtc.tienCuoc1 != 0 && gtc.tienCuoc1 != tienCuoc) {
                                    Service.chatNPC(p, (short) 40, "Gia tộc đối thủ của con đã đặt cược " + Util.getFormatNumber(gtc.tienCuoc1) + " xu con hãy đặt lại đi!");
                                    return;
                                }
                                if (gtc.tienCuoc2 != 0) {
                                    Service.chatNPC(p, (short) 40, "Con đã đặt cược trước đó rồi.");
                                    return;
                                }

                                gtc.tienCuoc2 = tienCuoc;
                                clanManager.coin -= tienCuoc;
                                Service.chatNPC(p, (short) 40, "Con đã đặt cược " + gtc.tienCuoc2 + " xu");
                                if (gtc.gt1.size() > 0) {
                                    for (int i = 0; i < gtc.gt1.size(); i++) {
                                        gtc.gt1.get(i).p.sendAddchatYellow("Gia tộc " + clanManager.name + " đã được cược " + Util.getFormatNumber(gtc.tienCuoc2) + " xu.");
                                    }
                                }
                            }

                            if (gtc.tienCuoc1 != 0 && gtc.tienCuoc2 != 0 && gtc.tienCuoc1 == gtc.tienCuoc2 && gtc.gt1.size() > 0 && gtc.gt2.size() > 0) {
                                gtc.invite();
                            }
                        } else {
                            return;
                        }
                        break;
                    }

                    case 45_0_0: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || check.equals("0") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 45, "Giá trị nhập vào không đúng");
                            break;
                        }
                        int joinluongt = Integer.parseInt(str);
                        try {
                            if (joinluongt <= 0 || joinluongt % 10 != 0) {
                                p.conn.sendMessageLog("Giá trị nhập không được nhỏ hơn 0 ");
                                return;
                            }
                            if (joinluongt > p.luong) {
                                p.conn.sendMessageLog("Lượng ko đủ để chơi");
                                return;
                            }
                            if (joinluongt > 100000000) {
                                p.conn.sendMessageLog("Không được đặt quá 100m");
                                return;
                            }
                            if (joinluongt <= p.luong) {
                                p.upluongMessage(-joinluongt);
                                int TimeSeconds = 15;
                                p.conn.sendMessageLog("Chờ 15 giây để biết kết quả.");
                                while (TimeSeconds > 0) {
                                    TimeSeconds--;
                                    Thread.sleep(1000);
                                }
                                int x = (int) Util.nextInt(1, 6);
                                int y = (int) Util.nextInt(1, 6);
                                int z = (int) Util.nextInt(1, 6);
                                if (4 <= (x + y + z) && (x + y + z) <= 10) {
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra : " + x + " " + y + " " + z
                                            + "\nTổng là : " + (x + y + z)
                                            + "\nBạn đã cược : " + joinluongt + " lượng vào Tài"
                                            + "\nKết quả : Xỉu"
                                            + "\nCòn cái nịt.leuleu");
                                    CheckTXLuong.checkTXLuongArrayList.add(new CheckTXLuong(p.c.name, "Kết quả Xỉu (" + (x + y + z) + ") thua " + joinluongt + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                } else if (x == y && x == z) {
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra : " + x + " " + y + " " + z
                                            + "\nTổng là : " + (x + y + z)
                                            + "\nBạn đã cược : " + joinluongt + " lượng vào Tài"
                                            + "\nKết quả : Tam hoa"
                                            + "\nCòn cái nịt.leuleu");
                                    CheckTXLuong.checkTXLuongArrayList.add(new CheckTXLuong(p.c.name, "Kết quả Tam Hoa (" + (x + y + z) + ") thua " + joinluongt + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                } else if ((x + y + z) > 10) {
                                    p.upluongMessage(joinluongt * 19 / 10);
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra là : " + x + " " + y + " " + z
                                            + "\nTổng là : " + (x + y + z)
                                            + "\nBạn đã cược : " + joinluongt + " lượng vào Tài"
                                            + "\nKết quả : Tài"
                                            + "\nhup nhe con");
                                    CheckTXLuong.checkTXLuongArrayList.add(new CheckTXLuong(p.c.name, "Kết quả Tài (" + (x + y + z) + ") ăn " + joinluongt * 19 / 10 + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                }
                            } else {
                                p.conn.sendMessageLog("Bạn không đủ lượng để chơi.");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            p.conn.sendMessageLog("Lỗi.");
                        }
                        break;
                    }
                    case 45_0_1: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || check.equals("0") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 45, "Giá trị nhập vào không đúng");
                            break;
                        }
                        int joinluongx = Integer.parseInt(str);
                        try {
                            if (joinluongx <= 0 || joinluongx % 10 != 0) {
                                p.conn.sendMessageLog("Giá trị nhập không được nhỏ hơn 0");
                                return;
                            }
                            if (joinluongx > p.luong) {
                                p.conn.sendMessageLog("Lượng ko đủ để chơi");
                                return;
                            }
                            if (joinluongx > 100000000) {
                                p.conn.sendMessageLog("Không được đặt quá 100m");
                                return;
                            }
                            if (joinluongx <= p.luong) {
                                p.upluongMessage(-joinluongx);
                                p.conn.sendMessageLog("Chờ 15 giây để biết kết quả.");
                                int TimeSeconds = 15;
                                while (TimeSeconds > 0) {
                                    TimeSeconds--;
                                    Thread.sleep(1000);
                                }
                                int x = (int) Util.nextInt(1, 6);
                                int y = (int) Util.nextInt(1, 6);
                                int z = (int) Util.nextInt(1, 6);
                                if (4 > (x + y + z) || (x + y + z) > 10) {
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra : " + x + " " + y + " " + z
                                            + "\nTổng là : " + (x + y + z)
                                            + "\nBạn đã cược : " + joinluongx + " lượng vào Xỉu"
                                            + "\nKết quả : Tài"
                                            + "\nCòn cái nịt.leuleu");
                                    CheckTXLuong.checkTXLuongArrayList.add(new CheckTXLuong(p.c.name, "Kết quả Tài (" + (x + y + z) + ") thua " + joinluongx + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                } else if (x == y && x == z) {
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra : " + x + " " + y + " " + z
                                            + "\nTổng là : " + (x + y + z)
                                            + "\nBạn đã cược : " + joinluongx + " lượng vào Xỉu"
                                            + "\nKết quả : Tam hoa"
                                            + "\nCòn cái nịt.leuleu");
                                    CheckTXLuong.checkTXLuongArrayList.add(new CheckTXLuong(p.c.name, "Kết quả Tam Hoa (" + (x + y + z) + ") thua " + joinluongx + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                } else if ((x + y + z) <= 10 && (x + y + z) >= 4) {
                                    p.upluongMessage(joinluongx * 19 / 10);
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra là : " + x + " " + y + " " + z
                                            + "\nTổng là : " + (x + y + z)
                                            + "\nBạn đã cược : " + joinluongx + " lượng vào Xỉu"
                                            + "\nKết quả : Xỉu"
                                            + "\nhup nhe con");
                                    CheckTXLuong.checkTXLuongArrayList.add(new CheckTXLuong(p.c.name, "Kết quả Xỉu (" + (x + y + z) + ") ăn " + joinluongx * 19 / 10 + " lượng", Util.toDateString(Date.from(Instant.now()))));

                                    return;
                                }
                            } else {
                                p.conn.sendMessageLog("Bạn không đủ lượng để chơi.");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            p.conn.sendMessageLog("Lỗi.");
                        }
                        break;
                    }
                    case 45_1_0: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || check.equals("0") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 45, "Giá trị nhập vào không đúng");
                            break;
                        }
                        int joinluongc = Integer.parseInt(str);
                        try {
                            if (joinluongc <= 0 || joinluongc % 10 != 0) {
                                p.conn.sendMessageLog("Giá trị nhập không được nhỏ hơn 0");
                                return;
                            }
                            if (joinluongc > p.luong) {
                                p.conn.sendMessageLog("Lượng ko đủ để chơi");
                                return;
                            }
                            if (joinluongc > 100000000) {
                                p.conn.sendMessageLog("Không được đặt quá 100m");
                                return;
                            }
                            if (joinluongc <= p.luong) {
                                p.upluongMessage(-joinluongc);
                                p.conn.sendMessageLog("Chờ 15 giây để biết kết quả.");
                                int TimeSeconds = 15;
                                while (TimeSeconds > 0) {
                                    TimeSeconds--;
                                    Thread.sleep(1000);
                                }
                                int x = (int) Util.nextInt(1, 9);
                                int y = (int) Util.nextInt(1, 9);
                                int z = (int) Util.nextInt(1, 9);
                                int t = (int) Util.nextInt(1, 9);
                                if ((x + y + z + t) % 2 != 0) {
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra : " + x + " " + y + " " + z + " " + t
                                            + "\nTổng là : " + (x + y + z + t)
                                            + "\nBạn đã cược : " + joinluongc + " lượng vào Chẵn"
                                            + "\nKết quả : Lẻ"
                                            + "\nCòn cái nịt.leuleu");
                                    CheckCLLuong.checkCLLuongArrayList.add(new CheckCLLuong(p.c.name, "Kết quả Lẻ (" + (x + y + z + t) + ") thua " + joinluongc + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                } else if ((x + y + z + t) % 2 == 0) {
                                    p.upluongMessage(joinluongc * 19 / 10);
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra là : " + x + " " + y + " " + z + " " + t
                                            + "\nTổng là : " + (x + y + z + t)
                                            + "\nBạn đã cược : " + joinluongc + " lượng vào Chẵn"
                                            + "\nKết quả : Chẵn"
                                            + "\nhup nhe con");
                                    CheckCLLuong.checkCLLuongArrayList.add(new CheckCLLuong(p.c.name, "Kết quả Chẵn (" + (x + y + z + t) + ") ăn " + joinluongc * 19 / 10 + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                }
                            } else {
                                p.conn.sendMessageLog("Bạn không đủ lượng để chơi.");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            p.conn.sendMessageLog("Lỗi.");
                        }
                        break;
                    }
                    case 45_1_1: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("") || check.equals("0") || !Util.isNumericInt(str)) {
                            Service.chatNPC(p, (short) 45, "Giá trị nhập vào không đúng");
                            break;
                        }
                        int joinluongl = Integer.parseInt(str);
                        try {
                            if (joinluongl <= 0 || joinluongl % 10 != 0) {
                                p.conn.sendMessageLog("Giá trị nhập không được nhỏ hơn 0");
                                return;
                            }
                            if (joinluongl > p.luong) {
                                p.conn.sendMessageLog("Lượng ko đủ để chơi");
                                return;
                            }
                            if (joinluongl > 100000000) {
                                p.conn.sendMessageLog("Không được đặt quá 100m");
                                return;
                            }
                            if (joinluongl <= p.luong) {
                                p.upluongMessage(-joinluongl);
                                p.conn.sendMessageLog("Chờ 15 giây để biết kết quả.");
                                int TimeSeconds = 15;
                                while (TimeSeconds > 0) {
                                    TimeSeconds--;
                                    Thread.sleep(1000);
                                }
                                int x = (int) Util.nextInt(1, 9);
                                int y = (int) Util.nextInt(1, 9);
                                int z = (int) Util.nextInt(1, 9);
                                int t = (int) Util.nextInt(1, 9);
                                if ((x + y + z + t) % 2 == 0) {
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra : " + x + " " + y + " " + z + " " + t
                                            + "\nTổng là : " + (x + y + z + t)
                                            + "\nBạn đã cược : " + joinluongl + " lượng vào Lẻ"
                                            + "\nKết quả : Chẵn"
                                            + "\nCòn cái nịt.leuleu");
                                    CheckCLLuong.checkCLLuongArrayList.add(new CheckCLLuong(p.c.name, "Kết quả Chẵn (" + (x + y + z + t) + ") thua " + joinluongl + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                } else if ((x + y + z + t) % 2 != 0) {
                                    p.upluongMessage(joinluongl * 19 / 10);
                                    Server.manager.sendTB(p, "Kết quả", "Số hệ thống quay ra là : " + x + " " + y + " " + z + " " + t
                                            + "\nTổng là : " + (x + y + z + t)
                                            + "\nBạn đã cược : " + joinluongl + " lượng vào Lẻ"
                                            + "\nKết quả : Lẻ"
                                            + "\nhup nhe con");
                                    CheckCLLuong.checkCLLuongArrayList.add(new CheckCLLuong(p.c.name, "Kết quả Lẻ (" + (x + y + z + t) + ") ăn " + joinluongl * 19 / 10 + " lượng", Util.toDateString(Date.from(Instant.now()))));
                                    return;
                                }
                            } else {
                                p.conn.sendMessageLog("Bạn không đủ lượng để chơi.");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            p.conn.sendMessageLog("Lỗi.");
                        }
                        break;
                    }
                    //Đổi coin => lượng
                    case 9: {
                        String check = str.replaceAll("\\s+", "");
                        if (!Util.isNumericInt(str) || check.equals("")) {
                            Service.chatNPC(p, (short) 36, "Giá trị coin nhập vào không đúng");
                            break;
                        }
                        long coin = Integer.parseInt(str);
                        try {
                            ResultSet red = SQLManager.stat.executeQuery("SELECT `coin` FROM `player` WHERE `id` = " + p.id + ";");
                            if (red != null && red.first()) {
                                int coinP = Integer.parseInt(red.getString("coin"));
                                if (coin <= coinP) {
                                    coinP -= coin;
                                    p.upluongMessage(coin);
                                    SQLManager.stat.executeUpdate("UPDATE `player` SET `coin`=" + coinP + " WHERE `id`=" + p.id + " LIMIT 1;");
                                } else {
                                    p.conn.sendMessageLog("Bạn không đủ coin để đổi ra lượng.");
                                }
                                p.flush();
                                red.close();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            p.conn.sendMessageLog("Lỗi đổi coin.");
                        }
                        break;
                    }
                    case 50: {
                        ClanManager.createClan(p, str);
                        break;
                    }
                    case 100: {
                        String num = str.replaceAll(" ", "").trim();
                        if (num.length() > 10 || !Util.checkNumInt(num) || b < 0 || b >= Server.manager.rotationluck.length) {
                            return;
                        }
                        if (!Util.isNumeric(num)) {
                            return;
                        }
                        int xujoin = Integer.parseInt(num);
                        Server.manager.rotationluck[b].joinLuck(p, xujoin);
                        break;
                    }
                    case 101: {
                        if (b < 0 || b >= Server.manager.rotationluck.length) {
                            return;
                        }
                        if (b == 0 && p.c.isTaskDanhVong == 1 && p.c.taskDanhVong[0] == 0 && p.c.taskDanhVong[1] < p.c.taskDanhVong[2]) {
                            p.c.taskDanhVong[1]++;
                        }
                        if (b == 1 && p.c.isTaskDanhVong == 1 && p.c.taskDanhVong[0] == 1 && p.c.taskDanhVong[1] < p.c.taskDanhVong[2]) {
                            p.c.taskDanhVong[1]++;
                        }
                        Server.manager.rotationluck[b].luckMessage(p);
                        break;
                    }
                    case 102: {
                        p.typemenu = 92;
                        Menu.doMenuArray(p, new String[]{"Vòng xoay vip", "Vòng xoay thường"});
                        break;
                    }
                  

                    //bảo trì
                    case 9998: {
                        if (p.role != 9999) {

                            p.conn.sendMessageLog("Chỉ admin mới sử dụng được chức năng này");
                            break;
                        }
                        if (!Util.isNumeric(str) || str.equals("")) {
                            p.conn.sendMessageLog("Giá trị nhập vào không hợp lệ");
                            return;
                        }
                        String check = str.replaceAll(" ", "").trim();
                        int minues = Integer.parseInt(check);
                        if (minues < 0 || minues > 10) {
                            p.conn.sendMessageLog("Giá trị nhập vào từ 0 -> 10 phút");
                            return;
                        }
                        p.sendAddchatYellow("Đã kích hoạt bảo trì Server sau " + minues + " phút.");
                        Thread t1 = new Thread(new Admin(minues, Server.gI()));
                        t1.start();
                        break;
                    }

                    //khoá tài khoản
                    case 9999: {
                        if (p.role != 9999) {

                            p.conn.sendMessageLog("Chỉ admin mới sử dụng được chức năng này");
                            break;
                        }
                        Char temp = Client.gI().getNinja(str);
                        if (temp != null) {
                            Player banPlayer = Client.gI().getPlayer(temp.p.username);
                            if (banPlayer != null && banPlayer.role != 9999) {
                                Client.gI().kickSession(banPlayer.conn);
                                try {
                                    SQLManager.stat.executeUpdate("UPDATE `player` SET `ban`=1 WHERE `id`=" + banPlayer.id + " LIMIT 1;");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                p.conn.sendMessageLog("Đã khoá tài khoản: " + banPlayer.username + " - nhân vật: " + temp.name);
                            } else {
                                p.conn.sendMessageLog("Tài khoản này là ADMIN hoặc không tìm thấy tài khoản này!");
                            }
                        } else {
                            p.conn.sendMessageLog("Người chơi này không tồn tại hoặc không online!");
                        }
                        temp = null;
                        break;
                    }

                    default: {
                        break;
                    }
                }
            } else {
                if (menuId == 102) {
                    p.typemenu = 92;
                    Menu.doMenuArray(p, new String[]{"Vòng xoay vip", "Vòng xoay thường"});
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (m != null) {
                m.cleanup();
            }
        }

    }
}
