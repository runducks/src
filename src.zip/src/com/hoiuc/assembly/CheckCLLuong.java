package com.hoiuc.assembly;
//Scr By SHIN
import java.util.ArrayList;
//Scr By SHIN
public class CheckCLLuong {
    public String name;
    public String item;
    public String time;

    public static ArrayList<CheckCLLuong> checkCLLuongArrayList = new ArrayList<>();

    public CheckCLLuong(String name, String item, String time) {
        this.name = name;
        this.item = item;
        this.time = time;
    }
}

