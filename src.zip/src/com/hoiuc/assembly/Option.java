package com.hoiuc.assembly;
//Scr By SHIN
public class Option {
    public int id;
    public int param;
//Scr By SHIN
    public Option(int id, int par) {
        this.id = id;
        this.param = par;
    }

    public Option(long Tn) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
