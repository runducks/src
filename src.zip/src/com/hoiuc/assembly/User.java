package com.hoiuc.assembly;
//Scr By SHIN
public class User {
    public int id;
    public String username = null;
    public int role = 0;
    public int online = 0;
    public int luong = -1;
    public int vnd = -1;
    public int atm = -1;
    public int status = -1;
    public int vip = 0;
    public String[] sortNinja = new String[3];

}
