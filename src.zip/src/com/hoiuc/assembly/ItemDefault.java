package com.hoiuc.assembly;
//Scr By SHIN
public class ItemDefault extends Item{
    public ItemDefault() {
        this.id = -1;
    }
}
