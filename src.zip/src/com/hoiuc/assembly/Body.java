package com.hoiuc.assembly;
//Scr By Shin
import com.hoiuc.server.GameSrc;
import com.hoiuc.server.Manager;
import com.hoiuc.template.ItemTemplate;
import com.hoiuc.template.SkillOptionTemplate;
import com.hoiuc.template.SkillTemplate;
//Scr By Shin
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
//Scr By Shin
public class Body {
    public Char c;
    public int id;
    public byte head;
    public byte caiTrang;
    protected byte speed;
    public byte nclass;
    public int level;
    public long exp;
    public long expdown;
    public byte pk;
    public byte typepk;
    public short ppoint;
    public double ppoint2;
    public double potential0;
    public double potential1;
    public double potential2;
    public double potential3;
    public short spoint;
    public boolean isDie;
    public ArrayList<Skill> skill;
    public byte[] KSkill;
    public byte[] OSkill;
    public short CSkill;
    public Item[] ItemBody;
    public Item[] ItemMounts;
    public boolean isHuman;
    public boolean isNhanban;
    public long CSkilldelay;
    public Mob mobMe;
    public short x;
    public short y;
    public short yDun;
    public double hp;
    public double mp;
    public byte exptype;
    public ArrayList<Effect> veff;
//Scr By Shin
    public boolean isGoiRong;
    public long timeEffGoiRong;
    public boolean isthaden;
    public long timeEffthaden;
    public long timeUseItem;
//Scr By Shin
    public int useTiemNang;
    public int useKyNang;
    public int useBanhPhongLoi;
    public int useBanhBangHoa;
    public int countTayKyNang;
    public int countTayTiemNang;

    public short ID_Body = -1;
    public short ID_PP = -1;
    public short ID_HAIR = -1;
    public short ID_LEG = -1;
    public short ID_HORSE = -1;
    public short ID_NAME = -1;
    public short ID_RANK = -1;
    public short ID_MAT_NA = -1;
    public short ID_Bien_Hinh = -1;
    public short ID_WEA_PONE = -1;

    public static int MIN_EFF0 = 30;
    public static int MIN_EFF1 = 40;
    public static int MIN_EFF2 = 50;
    public static int MIN_EFF3 = 60;
    public static int MIN_EFF4 = 70;
    public static int MIN_EFF5 = 80;
    public static int MIN_EFF6 = 90;
    public static int MIN_EFF7 = 100;
    public static int MIN_EFF8 = 110;
    public int ngocEff = -1;

    public Party party;
    public ArrayList<PartyPlease> aPartyInvite;
    public ArrayList<PartyPlease> aPartyInvate;
    public Vector<Friend> vFriend;

    public Body() {
        this.id = 0;
        this.head = -1;
        this.caiTrang = -1;
        this.speed = 4;
        this.nclass = 0;
        this.level = 1;
        this.exp = 1;
        this.expdown = 0L;
        this.pk = 0;
        this.typepk = 0;
        this.ppoint = 0;
        this.potential0 = 5;
        this.potential1 = 5;
        this.potential2 = 15;
        this.potential3 = 5;
        this.spoint = 0;
        this.isDie = false;
        this.skill = new ArrayList<Skill>();
        this.KSkill = null;
        this.OSkill = null;
        this.CSkill = -1;
        this.ItemBody = null;
        this.ItemMounts = null;
        this.CSkilldelay = 0L;
        this.mobMe = null;
        this.x = 0;
        this.y = 0;
        this.yDun = 0;
        this.hp = 0;
        this.mp = 0;
        this.exptype = 1;
        this.veff = new ArrayList<Effect>();
        this.party = null;
        this.aPartyInvite = new ArrayList<>();
        this.aPartyInvate = new ArrayList<>();
        this.isGoiRong = false;
        this.timeEffGoiRong = 6000L;
        this.isthaden = false;
        this.timeEffthaden = 6000L;
        this.timeUseItem = 0L;
        this.useTiemNang = 8;
        this.useKyNang = 8;
        this.useBanhPhongLoi = 10;
        this.useBanhBangHoa = 10;
        this.countTayKyNang = 1;
        this.countTayTiemNang = 1;
        this.vFriend = new Vector<>();
    }

    public void seNinja(Char c) {
        this.c = c;
    }

    public short partHead() {
        if (this.c.ishopthe == true) {
            return 201;
        }
        if(this.caiTrang != -1) {
            return ItemTemplate.ItemTemplateId(this.c.ItemCaiTrang[this.caiTrang].id).part;
        }
         if (this.caiTrang != -1 && this.c.ishopthe == true) {
            return 201;
        }
        if (this.ItemBody[11] == null) {
            return this.c.head;
        }
        
        if (this.ItemBody[11].id == 542){
            return 188;}
        if (this.ItemBody[11].id == 541){
            return 185;}
        if (this.ItemBody[11].id == 833){
            return 194;}
        if (this.ItemBody[11].id == 830){
            return 201;}
        if (this.ItemBody[11].id == 594){
            return 205;}
        if (this.ItemBody[11].id == 786){
            return 270;}
        if (this.ItemBody[11].id == 787){
            return 276;}
        if (this.ItemBody[11].id == 880){
            return 261;}
        if (this.ItemBody[11].id == 932){
            return 338;}
        if (this.ItemBody[11].id == 933){
            return 341;}
        if (this.ItemBody[11].id == 934){
            return 344;}
        return ItemTemplate.ItemTemplateId(this.ItemBody[11].id).part;
    }

    public short Weapon() {
        if (this.ItemBody[1] != null) {
            return ItemTemplate.ItemTemplateId(this.ItemBody[1].id).part;
        }
        if (this.partHead() ==201) {
            return 204;}
        if (this.partHead() ==205) {
            return 206;}
        return -1;
    }

    public short Body() {
        if (this.c.ishopthe == true) {
            return 202;
        }
        if (ItemTemplate.isPartHead(this.partHead())) {
            return (short)(this.partHead()+1);
        }
        if (this.ItemBody[2] != null) {
            return ItemTemplate.ItemTemplateId(this.ItemBody[2].id).part;
        }
        if (this.c.ishopthe == true && this.ItemBody[2] != null) {
            return 202;
        }
        if (this.partHead() ==188) {
            return 189;
        }
        if (partHead() == 185)
            return 186;
        if (partHead() == 194)
            return 195;
        if (this.partHead() ==201) {
            return 202;}
        if (this.partHead() ==205) {
            return 207;}
        if (this.partHead() ==270) {
            return 271;}
        if (this.partHead() ==276) {
            return 277;}
        if (this.partHead() ==261) {
            return 262;}
        if (this.partHead() ==338) {
            return 339;}
        if (this.partHead() ==341) {
            return 342;}
        if (this.partHead() ==344) {
            return 345;}
        
        return -1;
    }

    public short Leg() {
        if (ItemTemplate.isPartHead(this.partHead())) {
            return (short)(this.partHead()+2);
        }
        if (this.c.ishopthe == true) {
            return 203;
        }
        if (this.ItemBody[6] != null) {
            return ItemTemplate.ItemTemplateId(this.ItemBody[6].id).part;
        }
        if (partHead() == 188)
            return 190;
        if (partHead() == 185)
            return 187;
        if (partHead() == 194)
            return 196;
        if (this.partHead() ==201) {
            return 203;}
        if (this.partHead() ==270) {
            return 272;}
        if (this.partHead() ==276) {
            return 278;}
        if (this.partHead() ==261) {
            return 263;}
        if (this.partHead() ==338) {
            return 340;}
        if (this.partHead() ==341) {
            return 343;}
        if (this.partHead() ==344) {
            return 346;}
        if (this.c.ishopthe == true && this.ItemBody[2] != null) {
            return 203;
        }
        return -1;
    }

    public void updatePk(int num) {
        this.pk += (byte) num;
        if (this.pk < 0) {
            this.pk = 0;
        } else if (this.pk > 20) {
            this.pk = 20;
        }
    }

    public double getMaxHP() { //dang float san roi ne
        double hpmax = this.getPotential(2) * 10;
        if (this.c.isHuman && this.c.ishopthe) {
            hpmax += this.c.infocl[1];
        }
        hpmax += ((double) hpmax) * (this.getPramItem(31) + this.getPramItem(61) + this.getPramSkill(17)) / 100;
        hpmax += this.getPramItem(6);
        hpmax += this.getPramItem(32);
        hpmax += this.getPramItem(77);
        hpmax += this.getPramItem(82);
        hpmax += this.getPramItem(125);
        Effect eff = this.c.get().getEffId(27);
        if (eff != null) {
            hpmax += eff.param;
        }
        
        if (this.hp > hpmax) {
            this.hp = hpmax;
        }
        return hpmax;
    }

    public synchronized void upHP(double hpup) {
        if (this.isDie) {
            return;
        }
        
        
        this.hp += hpup;
        if (this.hp > this.getMaxHP()) {
            this.hp = this.getMaxHP();
        }
        
        if (this.hp <= 0) {
            this.isDie = true;
            this.hp = 0;
        }
    }

    public double getMaxMP() {
        double mpmax = this.getPotential(3) * 10;
        if (this.c.isHuman && this.c.ishopthe) {
            mpmax += this.c.infocl[2];
        }
        mpmax += ((double) mpmax) * (this.getPramItem(28) + this.getPramItem(60) + this.getPramSkill(18)) / 100;
        mpmax += this.getPramItem(7);
        mpmax += this.getPramItem(19);
        mpmax += this.getPramItem(29);
        mpmax += this.getPramItem(83);
        mpmax += this.getPramItem(117);
        if (this.mp > mpmax) {
            this.mp =  mpmax;
        }
        return mpmax;
    }

    public synchronized void upMP(double mpup) {
        if (this.isDie) {
            return;
        }
        this.mp += (double) mpup;
        if (this.mp > this.getMaxMP()) {
            this.mp =  this.getMaxMP();
        } else if (this.mp < 0) {
            this.mp = 0;
        }
    }

    public double eff5buffHP() {
        if (this.getMaxHP() > 2000000000) {
            return 0;
        }
        return (this.getPramItem(30) + this.getPramItem(120));
    }

    public double eff5buffMP() {
        if (this.getMaxMP() > 2000000000) {
            return 0;
        }
        return (this.getPramItem(27) + this.getPramItem(119));
    }

    public void setSpeed(byte speed) {
        this.speed = speed;
    }

    public float speed() {
        float sp = this.speed;
        sp = sp * (100 + this.getPramItem(16)) / 100;
        sp += this.getPramItem(93);
        return sp;
    }

    public double dameSide() {
        double percent = this.getPramSkill(11) + this.getPramItem(94);
        if (c.lvdihoa == 1) {
             percent += 2000; // + Tấn Công %
         }if (c.lvdihoa == 2) {
             percent += 3000; // + Tấn Công %
         }if (c.lvdihoa == 3) {
             percent += 4000; // + Tấn Công %
         }if (c.lvdihoa == 4) {
             percent += 5000; // + Tấn Công %
         }if (c.lvdihoa == 5) {
             percent += 6000; // + Tấn Công %
         }if (c.lvdihoa == 6) {
             percent += 7000; // + Tấn Công %
         }if (c.lvdihoa == 7) {
             percent += 8000; // + Tấn Công %
         }if (c.lvdihoa == 8) {
             percent += 9000; // + Tấn Công %
         }if (c.lvdihoa == 9) {
             percent += 10000; // + Tấn Công %
         }if (c.lvdihoa == 10) {
             percent += 11000; // + Tấn Công %
         }if (c.lvdihoa == 11) {
             percent += 12000; // + Tấn Công %
         }if (c.lvdihoa == 12) {
             percent += 13000; // + Tấn Công %
         }if (c.lvdihoa == 13) {
             percent += 14000; // + Tấn Công %
         }if (c.lvdihoa == 14) {
             percent += 15000; // + Tấn Công %
         }if (c.lvdihoa == 15) {
             percent += 20000; // + Tấn Công %
         }if (c.lvdihoa == 16) {
             percent += 30000; // + Tấn Công %
         }if (c.lvdihoa == 17) {
             percent += 40000; // + Tấn Công %
         }if (c.lvdihoa == 18) {
             percent += 50000; // + Tấn Công %
         }if (c.lvdihoa == 19) {
             percent += 60000; // + Tấn Công %
         }if (c.lvdihoa == 20) {
             percent += 70000; // + Tấn Công %
         }if (c.lvdihoa == 21) {
             percent += 80000; // + Tấn Công %
         }if (c.lvdihoa == 22) {
             percent += 90000; // + Tấn Công %
         }if (c.lvdihoa == 23) {
             percent += 100000; // + Tấn Công %
         }if (c.lvdihoa == 24) {
             percent += 110000; // + Tấn Công %
         }if (c.lvdihoa == 25) {
             percent += 120000; // + Tấn Công %
         }if (c.lvdihoa == 26) {
             percent += 130000; // + Tấn Công %
         }if (c.lvdihoa == 27) {
             percent += 140000; // + Tấn Công %
         }if (c.lvdihoa == 28) {
             percent += 150000; // + Tấn Công %
         }if (c.lvdihoa == 29) {
             percent += 150000; // + Tấn Công %
         }if (c.lvdihoa == 30) {
             percent += 160000; // + Tấn Công %
         }if (c.lvdihoa == 31) {
             percent += 170000; // + Tấn Công %
         }if (c.lvdihoa == 32) {
             percent += 180000; // + Tấn Công %
         }if (c.lvdihoa == 33) {
             percent += 190000; // + Tấn Công %
         }if (c.lvdihoa == 34) {
             percent += 200000; // + Tấn Công %
         }if (c.lvdihoa == 35) {
             percent += 210000; // + Tấn Công %
         }if (c.lvdihoa == 36) {
             percent += 220000; // + Tấn Công %
         }if (c.lvdihoa == 37) {
             percent += 230000; // + Tấn Công %
         }if (c.lvdihoa == 38) {
             percent += 240000; // + Tấn Công %
         }if (c.lvdihoa == 39) {
             percent += 250000; // + Tấn Công %
         }if (c.lvdihoa == 40) {
             percent += 260000; // + Tấn Công %
         }if (c.lvdihoa == 41) {
             percent += 270000; // + Tấn Công %
         }if (c.lvdihoa == 42) {
             percent += 280000; // + Tấn Công %
         }if (c.lvdihoa == 43) {
             percent += 290000; // + Tấn Công %
         }if (c.lvdihoa == 44) {
             percent += 300000; // + Tấn Công %
         }if (c.lvdihoa == 45) {
             percent += 310000; // + Tấn Công %
         }if (c.lvdihoa == 46) {
             percent += 320000; // + Tấn Công %
         }if (c.lvdihoa == 47) {
             percent += 330000; // + Tấn Công %
         }if (c.lvdihoa == 48) {
             percent += 340000; // + Tấn Công %
         }if (c.lvdihoa == 49) {
             percent += 350000; // + Tấn Công %
         }if (c.lvdihoa == 50) {
             percent += 400000; // + Tấn Công %
         }  
         
         // khaohach
         
         if (c.lvthan == 1) {
             percent += 20000; // + Tấn Công %
         }if (c.lvthan == 2) {
             percent += 30000; // + Tấn Công %
         }if (c.lvthan == 3) {
             percent += 40000; // + Tấn Công %
         }if (c.lvthan == 4) {
             percent += 50000; // + Tấn Công %
         }if (c.lvthan == 5) {
             percent += 60000; // + Tấn Công %
         }if (c.lvthan == 6) {
             percent += 70000; // + Tấn Công %
         }if (c.lvthan == 7) {
             percent += 80000; // + Tấn Công %
         }if (c.lvthan == 8) {
             percent += 90000; // + Tấn Công %
         }if (c.lvthan == 9) {
             percent += 100000; // + Tấn Công %
         }if (c.lvthan == 10) {
             percent += 110000; // + Tấn Công %
         }if (c.lvthan == 11) {
             percent += 120000; // + Tấn Công %
         }if (c.lvthan == 12) {
             percent += 130000; // + Tấn Công %
         }if (c.lvthan == 13) {
             percent += 140000; // + Tấn Công %
         }if (c.lvthan == 14) {
             percent += 150000; // + Tấn Công %
         }if (c.lvthan == 15) {
             percent += 200000; // + Tấn Công %
         }if (c.lvthan == 16) {
             percent += 300000; // + Tấn Công %
         }if (c.lvthan == 17) {
             percent += 400000; // + Tấn Công %
         }if (c.lvthan == 18) {
             percent += 500000; // + Tấn Công %
         }if (c.lvthan == 19) {
             percent += 600000; // + Tấn Công %
         }if (c.lvthan == 20) {
             percent += 700000; // + Tấn Công %
         }if (c.lvthan == 21) {
             percent += 800000; // + Tấn Công %
         }if (c.lvthan == 22) {
             percent += 900000; // + Tấn Công %
         }if (c.lvthan == 23) {
             percent += 1000000; // + Tấn Công %
         }if (c.lvthan == 24) {
             percent += 1100000; // + Tấn Công %
         }if (c.lvthan == 25) {
             percent += 1200000; // + Tấn Công %
         }if (c.lvthan == 26) {
             percent += 1300000; // + Tấn Công %
         }if (c.lvthan == 27) {
             percent += 1400000; // + Tấn Công %
         }if (c.lvthan == 28) {
             percent += 1500000; // + Tấn Công %
         }if (c.lvthan == 29) {
             percent += 1500000; // + Tấn Công %
         }if (c.lvthan == 30) {
             percent += 1600000; // + Tấn Công %
         }if (c.lvthan == 31) {
             percent += 1700000; // + Tấn Công %
         }if (c.lvthan == 32) {
             percent += 1800000; // + Tấn Công %
         }if (c.lvthan == 33) {
             percent += 1900000; // + Tấn Công %
         }if (c.lvthan == 34) {
             percent += 2000000; // + Tấn Công %
         }if (c.lvthan == 35) {
             percent += 2100000; // + Tấn Công %
         }if (c.lvthan == 36) {
             percent += 2200000; // + Tấn Công %
         }if (c.lvthan == 37) {
             percent += 2300000; // + Tấn Công %
         }if (c.lvthan == 38) {
             percent += 2400000; // + Tấn Công %
         }if (c.lvthan == 39) {
             percent += 2500000; // + Tấn Công %
         }if (c.lvthan == 40) {
             percent += 2600000; // + Tấn Công %
         }if (c.lvthan == 41) {
             percent += 2700000; // + Tấn Công %
         }if (c.lvthan == 42) {
             percent += 2800000; // + Tấn Công %
         }if (c.lvthan == 43) {
             percent += 2900000; // + Tấn Công %
         }if (c.lvthan == 44) {
             percent += 3000000; // + Tấn Công %
         }if (c.lvthan == 45) {
             percent += 3100000; // + Tấn Công %
         }if (c.lvthan == 46) {
             percent += 3200000; // + Tấn Công %
         }if (c.lvthan == 47) {
             percent += 3300000; // + Tấn Công %
         }if (c.lvthan == 48) {
             percent += 3400000; // + Tấn Công %
         }if (c.lvthan == 49) {
             percent += 3500000; // + Tấn Công %
         }if (c.lvthan == 50) {
             percent += 4000000; // + Tấn Công %
         }if (c.lvthan == 51) {
             percent += 4500000; // + Tấn Công %
         }if (c.lvthan == 52) {
             percent += 5000000; // + Tấn Công %
         }if (c.lvthan == 53) {
             percent += 5500000; // + Tấn Công %
         }if (c.lvthan == 54) {
             percent += 6000000; // + Tấn Công %
         }if (c.lvthan == 55) {
             percent += 6500000; // + Tấn Công %
         }if (c.lvthan == 56) {
             percent += 7000000; // + Tấn Công %
         }if (c.lvthan == 57) {
             percent += 7500000; // + Tấn Công %
         }if (c.lvthan == 58) {
             percent += 8000000; // + Tấn Công %
         }if (c.lvthan == 59) {
             percent += 8500000; // + Tấn Công %
         }if (c.lvthan == 60) {
             percent += 9000000; // + Tấn Công %
         }if (c.lvthan == 61) {
             percent += 9500000; // + Tấn Công %
         }if (c.lvthan == 62) {
             percent += 10000000; // + Tấn Công %
         }if (c.lvthan == 63) {
             percent += 11000000; // + Tấn Công %
         }if (c.lvthan == 64) {
             percent += 20000000; // + Tấn Công %
         }  
         // hơi thở
         if (c.hoitho == 1) {
             percent += 20000; // + Tấn Công %
         }if (c.hoitho == 2) {
             percent += 30000; // + Tấn Công %
         }if (c.hoitho == 3) {
             percent += 40000; // + Tấn Công %
         }if (c.hoitho == 4) {
             percent += 50000; // + Tấn Công %
         }if (c.hoitho == 5) {
             percent += 60000; // + Tấn Công %
         }if (c.hoitho == 6) {
             percent += 70000; // + Tấn Công %
         }if (c.hoitho == 7) {
             percent += 80000; // + Tấn Công %
         }if (c.hoitho == 8) {
             percent += 90000; // + Tấn Công %
         }if (c.hoitho == 9) {
             percent += 100000; // + Tấn Công %
         }if (c.hoitho == 10) {
             percent += 110000; // + Tấn Công %
         }if (c.hoitho == 11) {
             percent += 120000; // + Tấn Công %
         }if (c.hoitho == 12) {
             percent += 130000; // + Tấn Công %
         }if (c.hoitho == 13) {
             percent += 140000; // + Tấn Công %
         }if (c.hoitho == 14) {
             percent += 150000; // + Tấn Công %
         }if (c.hoitho == 15) {
             percent += 160000; // + Tấn Công %
         }if (c.hoitho == 16) {
             percent += 170000; // + Tấn Công %
         }if (c.hoitho == 17) {
             percent += 180000; // + Tấn Công %
         }if (c.hoitho == 18) {
             percent += 190000; // + Tấn Công %
         }if (c.hoitho == 19) {
             percent += 200000; // + Tấn Công %
         }if (c.hoitho == 20) {
             percent += 210000; // + Tấn Công %
         }if (c.hoitho == 21) {
             percent += 220000; // + Tấn Công %
         }if (c.hoitho == 22) {
             percent += 230000; // + Tấn Công %
         }if (c.hoitho == 23) {
             percent += 240000; // + Tấn Công %
         }if (c.hoitho == 24) {
             percent += 250000; // + Tấn Công %
         }if (c.hoitho == 25) {
             percent += 260000; // + Tấn Công %
         }if (c.hoitho == 26) {
             percent += 270000; // + Tấn Công %
         }if (c.hoitho == 27) {
             percent += 280000; // + Tấn Công %
         }if (c.hoitho == 28) {
             percent += 290000; // + Tấn Công %
         }if (c.hoitho == 29) {
             percent += 300000; // + Tấn Công %
         }if (c.hoitho == 30) {
             percent += 350000; // + Tấn Công % 
         }if (c.hoitho == 31) {
             percent += 400000; // + Tấn Công %
         }if (c.hoitho == 32) {
             percent += 450000; // + Tấn Công %
         }if (c.hoitho == 33) {
             percent += 500000; // + Tấn Công %
         }if (c.hoitho == 34) {
             percent += 600000; // + Tấn Công %
         }if (c.hoitho == 35) {
             percent += 700000; // + Tấn Công %
         }if (c.hoitho == 36) {
             percent += 800000; // + Tấn Công %
         }if (c.hoitho == 37) {
             percent += 900000; // + Tấn Công %
         }if (c.hoitho == 38) {
             percent += 1000000; // + Tấn Công %
         }if (c.hoitho == 39) {
             percent += 2000000; // + Tấn Công %
         }if (c.hoitho == 40) {
             percent += 3000000; // + Tấn Công %
         }if (c.hoitho == 41) {
             percent += 4000000; // + Tấn Công %
         }if (c.hoitho == 42) {
             percent += 5000000; // + Tấn Công %
         }if (c.hoitho == 43) {
             percent += 6000000; // + Tấn Công %
         }if (c.hoitho == 44) {
             percent += 6500000; // + Tấn Công %
         }if (c.hoitho == 45) {
             percent += 7000000; // + Tấn Công %
         }if (c.hoitho == 46) {
             percent += 7500000; // + Tấn Công %
         }if (c.hoitho == 47) {
             percent += 8000000; // + Tấn Công %
         }if (c.hoitho == 48) {
             percent += 8500000; // + Tấn Công %
         }if (c.hoitho == 49) {
             percent += 9000000; // + Tấn Công %
         }if (c.hoitho == 50) {
             percent += 15000000; // + Tấn Công %
         }
         
         //sinhcon
         if (c.sinhcon == 1) {
             percent += 5000; // + Tấn Công %
         }if (c.sinhcon == 2) {
             percent += 10000; // + Tấn Công %
         }if (c.sinhcon == 3) {
             percent += 20000; // + Tấn Công %
         }if (c.sinhcon == 4) {
             percent += 30000; // + Tấn Công %
         }if (c.sinhcon == 5) {
             percent += 60000; // + Tấn Công %
         }if (c.sinhcon == 6) {
             percent += 90000; // + Tấn Công %
         }if (c.sinhcon == 7) {
             percent += 100000; // + Tấn Công %
         }if (c.sinhcon == 8) {
             percent += 110000; // + Tấn Công %
         }if (c.sinhcon == 9) {
             percent += 120000; // + Tấn Công %
         }if (c.sinhcon == 10) {
             percent += 130000; // + Tấn Công %
         }if (c.sinhcon == 11) {
             percent += 140000; // + Tấn Công %
         }if (c.sinhcon == 12) {
             percent += 150000; // + Tấn Công %
         }if (c.sinhcon == 13) {
             percent += 160000; // + Tấn Công %
         }if (c.sinhcon == 14) {
             percent += 170000; // + Tấn Công %
         }if (c.sinhcon == 15) {
             percent += 180000; // + Tấn Công %
         }if (c.sinhcon == 16) {
             percent += 190000; // + Tấn Công %
         }if (c.sinhcon == 17) {
             percent += 200000; // + Tấn Công %
         }if (c.sinhcon == 18) {    
         }
        Effect eff = this.c.get().getEffId(25);
        if (eff != null) {
            percent += eff.param;
        }
        eff = this.c.get().getEffId(17);
        if (eff != null) {
            percent += eff.param;
        }
        eff = this.c.get().getEffId(19);
        if (eff != null) {
            percent += eff.param * 10 / 3;
        }
        eff = this.c.get().getEffId(45);
        if (eff != null) {
            percent += eff.param * 10 / 3;
        }
        double si = 0.0f;
        if (this.Side() == 1) {
            si = this.getPotential(3);
            si += si * (this.getPramSkill(1) + this.getPramItem(9) + percent) / 100;
            si += this.getPramItem(1);
            si += this.getPramItem(0);
        }else if (this.Side() == 2) {
            si = this.getPotential(1) * 80/100;
            si += si * (this.getPramSkill(0) + this.getPramItem(8) + percent) / 100;
            si += this.getPramItem(1);
            si += this.getPramItem(0);
        } else {
            si = this.getPotential(0);
            si += si * (this.getPramSkill(0) + this.getPramItem(8) + percent) / 100;
            si += this.getPramItem(0);
            si += this.getPramItem(1);
        }
        si += this.getPramItem(38);//tan cong co ban vu khi
        eff = this.c.get().getEffId(17);
        if (eff != null) {
            si += this.getPramItem(38) * eff.param / 100;//buff tan cong co ban phai cung
        }
        eff = this.c.get().getEffId(19);
        if (eff != null) {
            si += this.getPramItem(38) * eff.param * 10 / 300;//buff tan cong co ban phai quat
        }
        eff = this.c.get().getEffId(45);
        if (eff != null) {
            si += this.getPramItem(38) * eff.param * 10 / 300;//buff tan cong phai thien su
        }
        si += this.getPramItem(38) * this.getPramSkill(11) / 100;// buff tan cong co ban cua skill chu dong
        eff = this.c.get().getEffId(25);
        if (eff != null) {
            si += this.getPramItem(38) * eff.param / 100;//buff tan cong co ban cua long luc dan
        }
        return si;
    }

    public double dameSys() {
        float ds = 0;
        if (this.Sys() == 0) {
            ds = this.getPramSkill(72);
            ds += this.getPramItem(101);
            if (this.Side() == 2) {
                ds += this.getPramSkill(73);
                ds += this.getPramItem(63);
            }
        } else if (this.Sys() == 1) {
            ds = this.getPramSkill(2);
            ds += this.getPramItem(88);
            ds += this.getPramItem(89);
            ds += this.getPramItem(90);
            if (this.Side() == 1) {
                ds += this.getPramSkill(8);
                ds += this.getPramItem(21);
                ds += this.getPramItem(22);
                ds += this.getPramItem(23);
                ds += this.getPramItem(24);
                ds += this.getPramItem(25);
                ds += this.getPramItem(26);
            } else {
                ds += this.getPramSkill(5);
                ds += this.getPramItem(21);
                ds += this.getPramItem(22);
                ds += this.getPramItem(23);
                ds += this.getPramItem(24);
                ds += this.getPramItem(25);
                ds += this.getPramItem(26);
            }
        } else if (this.Sys() == 2) {
            ds = this.getPramSkill(3);
            ds += this.getPramItem(88);
            ds += this.getPramItem(89);
            ds += this.getPramItem(90);
            if (this.Side() == 1) {
                ds += this.getPramSkill(9);
                ds += this.getPramItem(21);
                ds += this.getPramItem(22);
                ds += this.getPramItem(23);
                ds += this.getPramItem(24);
                ds += this.getPramItem(25);
                ds += this.getPramItem(26);
            } else {
                ds += this.getPramSkill(6);
                ds += this.getPramItem(21);
                ds += this.getPramItem(22);
                ds += this.getPramItem(23);
                ds += this.getPramItem(24);
                ds += this.getPramItem(25);
                ds += this.getPramItem(26);
            }
        } else if (this.Sys() == 3) {
            ds = this.getPramSkill(4);
            ds += this.getPramItem(88);
            ds += this.getPramItem(89);
            ds += this.getPramItem(90);
            if (this.Side() == 1) {
                ds += this.getPramSkill(10);
                ds += this.getPramItem(21);
                ds += this.getPramItem(22);
                ds += this.getPramItem(23);
                ds += this.getPramItem(24);
                ds += this.getPramItem(25);
                ds += this.getPramItem(26);
            } else {
                ds += this.getPramSkill(7);
                ds += this.getPramItem(21);
                ds += this.getPramItem(22);
                ds += this.getPramItem(23);
                ds += this.getPramItem(24);
                ds += this.getPramItem(25);
                ds += this.getPramItem(26);
            }
        }
        return ds;
    }

    public double dameMax() {
        double dame = this.dameSide();
        if (this.c.isHuman && this.c.ishopthe) {
            dame += this.c.infocl[0];
        }
        dame += this.dameSys();
        dame += this.getPramItem(73);
        dame += this.getPramItem(76);
        dame += this.getPramItem(87);
        if (dame < 0) {
            dame = 0;
        }
        if (c.lvdihoa == 1) {
             dame += 20000000; // + sát thuong
         }if (c.lvdihoa == 2) {
             dame += 30000000; // + sát thuong
         }if (c.lvdihoa == 3) {
             dame += 40000000; // + sát thuong
         }if (c.lvdihoa == 4) {
             dame += 50000000; // + sát thuong
         }if (c.lvdihoa == 5) {
             dame += 60000000; // + sát thuong
         }if (c.lvdihoa == 6) {
             dame += 70000000; // + sát thuong
         }if (c.lvdihoa == 7) {
             dame += 80000000; // + sát thuong
         }if (c.lvdihoa == 8) {
             dame += 90000000; // + sát thuong
         }if (c.lvdihoa == 9) {
             dame += 100000000; // + sát thuong
         }if (c.lvdihoa == 10) {
             dame += 110000000; // + sát thuong
         }if (c.lvdihoa == 11) {
             dame += 120000000; // + sát thuong
         }if (c.lvdihoa == 12) {
             dame += 130000000; // + sát thuong
         }if (c.lvdihoa == 13) {
             dame += 140000000; // + sát thuong
         }if (c.lvdihoa == 14) {
             dame += 150000000; // + sát thuong
         }if (c.lvdihoa == 15) {
             dame += 200000000; // + sát thuong
         }if (c.lvdihoa == 16) {
             dame += 300000000; // + sát thuong
         }if (c.lvdihoa == 17) {
             dame += 400000000; // + sát thuong
         }if (c.lvdihoa == 18) {
             dame += 500000000; // + sát thuong
         }if (c.lvdihoa == 19) {
             dame += 600000000; // + sát thuong
         }if (c.lvdihoa == 20) {
             dame += 700000000; // + sát thuong
         }if (c.lvdihoa == 21) {
             dame += 800000000; // + sát thuong
         }if (c.lvdihoa == 22) {
             dame += 900000000; // + sát thuong
         }if (c.lvdihoa == 23) {
             dame += 1000000000; // + sát thuong
         }if (c.lvdihoa == 24) {
             dame += 1100000000; // + sát thuong
         }if (c.lvdihoa == 25) {
             dame += 1200000000; // + sát thuong
         }if (c.lvdihoa == 26) {
             dame += 1000000000; // + sát thuong
         }if (c.lvdihoa == 27) {
             dame += 1300000000; // + sát thuong
         }if (c.lvdihoa == 28) {
             dame += 1400000000; // + sát thuong
         }if (c.lvdihoa == 29) {
             dame += 1500000000; // + sát thuong
         }if (c.lvdihoa == 30) {
             dame += 1500000000; // + sát thuong
         }if (c.lvdihoa == 31) {
             dame += 1600000000; // + sát thuong
         }if (c.lvdihoa == 32) {
             dame += 1700000000; // + sát thuong
         }if (c.lvdihoa == 33) {
             dame += 1700000000; // + sát thuong
         }if (c.lvdihoa == 34) {
             dame += 1800000000; // + sát thuong
         }if (c.lvdihoa == 35) {
             dame += 1900000000; // + sát thuong
         }if (c.lvdihoa == 36) {
             dame += 2000000000; // + sát thuong
         }if (c.lvdihoa == 37) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 38) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 39) {
             dame += 210000000; // + sát thuong
         }if (c.lvdihoa == 40) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 41) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 42) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 43) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 44) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 45) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 46) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 47) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 48) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 49) {
             dame += 2100000000; // + sát thuong
         }if (c.lvdihoa == 50) {
             dame += 2100000000; // + sát thuong
         }
         
         //khaohach
         if (c.lvthan == 1) {
             dame += 200000000; // + sát thuong
         }if (c.lvthan == 2) {
             dame += 300000000; // + sát thuong
         }if (c.lvthan == 3) {
             dame += 400000000; // + sát thuong
         }if (c.lvthan == 4) {
             dame += 500000000; // + sát thuong
         }if (c.lvthan == 5) {
             dame += 600000000; // + sát thuong
         }if (c.lvthan == 6) {
             dame += 700000000; // + sát thuong
         }if (c.lvthan == 7) {
             dame += 800000000; // + sát thuong
         }if (c.lvthan == 8) {
             dame += 900000000; // + sát thuong
         }if (c.lvthan == 9) {
             dame += 1000000000; // + sát thuong
         }if (c.lvthan == 10) {
             dame += 1100000000; // + sát thuong
         }if (c.lvthan == 11) {
             dame += 1200000000; // + sát thuong
         }if (c.lvthan == 12) {
             dame += 1300000000; // + sát thuong
         }if (c.lvthan == 13) {
             dame += 1400000000; // + sát thuong
         }if (c.lvthan == 14) {
             dame += 1500000000; // + sát thuong
         }if (c.lvthan == 15) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 16) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 17) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 18) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 19) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 20) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 21) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 22) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 23) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 24) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 25) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 26) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 27) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 28) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 29) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 30) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 31) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 32) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 33) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 34) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 35) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 36) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 37) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 38) {
             dame += 2000000000; // + sát thuong
         }if (c.lvthan == 39) {
             dame += 210000000; // + sát thuong
         }if (c.lvthan == 40) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 41) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 42) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 43) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 44) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 45) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 46) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 47) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 48) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 49) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 50) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 51) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 52) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 53) {
             dame += 210000000; // + sát thuong
         }if (c.lvthan == 54) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 55) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 56) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 57) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 58) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 59) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 60) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 61) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 62) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 63) {
             dame += 2100000000; // + sát thuong
         }if (c.lvthan == 64) {
             dame += 2100000000; // + sát thuong
         }
         // hơi thở
          if (c.hoitho == 1) {
             dame += 20000000; // + sát thuong
         }if (c.hoitho == 2) {
             dame += 30000000; // + sát thuong
         }if (c.hoitho == 3) {
             dame += 40000000; // + sát thuong
         }if (c.hoitho == 4) {
             dame += 50000000; // + sát thuong
         }if (c.hoitho == 5) {
             dame += 60000000; // + sát thuong
         }if (c.hoitho == 6) {
             dame += 70000000; // + sát thuong
         }if (c.hoitho == 7) {
             dame += 80000000; // + sát thuong
         }if (c.hoitho == 8) {
             dame += 90000000; // + sát thuong
         }if (c.hoitho == 9) {
             dame += 100000000; // + sát thuong
         }if (c.hoitho == 10) {
             dame += 110000000; // + sát thuong
         }if (c.hoitho == 11) {
             dame += 120000000; // + sát thuong
         }if (c.hoitho == 12) {
             dame += 130000000; // + sát thuong
         }if (c.hoitho == 13) {
             dame += 140000000; // + sát thuong
         }if (c.hoitho == 14) {
             dame += 150000000; // + sát thuong
         }if (c.hoitho == 15) {
             dame += 150000000; // + sát thuong
         }if (c.hoitho == 16) {
             dame += 170000000; // + sát thuong
         }if (c.hoitho == 17) {
             dame += 180000000; // + sát thuong
         }if (c.hoitho == 18) {
             dame += 190000000; // + sát thuong
         }if (c.hoitho == 19) {
             dame += 200000000; // + sát thuong
         }if (c.hoitho == 20) {
             dame += 210000000; // + sát thuong
         }if (c.hoitho == 21) {
             dame += 220000000; // + sát thuong
         }if (c.hoitho == 22) {
             dame += 230000000; // + sát thuong
         }if (c.hoitho == 23) {
             dame += 240000000; // + sát thuong
         }if (c.hoitho == 24) {
             dame += 250000000; // + sát thuong
         }if (c.hoitho == 25) {
             dame += 260000000; // + sát thuong
         }if (c.hoitho == 26) {
             dame += 270000000; // + sát thuong
         }if (c.hoitho == 27) {
             dame += 280000000; // + sát thuong
         }if (c.hoitho == 28) {
             dame += 290000000; // + sát thuong
         }if (c.hoitho == 29) {
             dame += 300000000; // + sát thuong  
         }if (c.hoitho == 30) {
             dame += 350000000; // + sát thuong
         }if (c.hoitho == 31) {
             dame += 400000000; // + sát thuong
         }if (c.hoitho == 32) {
             dame += 450000000; // + sát thuong
         }if (c.hoitho == 33) {
             dame += 500000000; // + sát thuong
         }if (c.hoitho == 34) {
             dame += 550000000; // + sát thuong
         }if (c.hoitho == 35) {
             dame += 600000000; // + sát thuong
         }if (c.hoitho == 36) {
             dame += 650000000; // + sát thuong
         }if (c.hoitho == 37) {
             dame += 700000000; // + sát thuong
         }if (c.hoitho == 38) {
             dame += 750000000; // + sát thuong
         }if (c.hoitho == 39) {
             dame += 800000000; // + sát thuong
         }if (c.hoitho == 40) {
             dame += 850000000; // + sát thuong
         }if (c.hoitho == 41) {
             dame += 900000000; // + sát thuong
         }if (c.hoitho == 42) {
             dame += 950000000; // + sát thuong
         }if (c.hoitho == 43) {
             dame += 1000000000; // + sát thuong
         }if (c.hoitho == 44) {
             dame += 1100000000; // + sát thuong
         }if (c.hoitho == 45) {
             dame += 1200000000; // + sát thuong
         }if (c.hoitho == 46) {
             dame += 1300000000; // + sát thuong
         }if (c.hoitho == 47) {
             dame += 1400000000; // + sát thuong
         }if (c.hoitho == 48) {
             dame += 1500000000; // + sát thuong
         }if (c.hoitho == 49) {
             dame += 1600000000; // + sát thuong  
         }if (c.hoitho == 50) {
             dame += 2000000000; // + sát thuong
         }    
        // sinh con
        if (c.sinhcon == 1) {
             dame += 30000000; // + sát thuong
         }if (c.sinhcon == 2) {
             dame += 40000000; // + sát thuong
         }if (c.sinhcon == 3) {
             dame += 50000000; // + sát thuong
         }if (c.sinhcon == 4) {
             dame += 60000000; // + sát thuong
         }if (c.sinhcon == 5) {
             dame += 70000000; // + sát thuong
         }if (c.sinhcon == 6) {
             dame += 80000000; // + sát thuong
         }if (c.sinhcon == 7) {
             dame += 90000000; // + sát thuong
         }if (c.sinhcon == 8) {
             dame += 10000000; // + sát thuong
         }if (c.sinhcon == 9) {
             dame += 200000000; // + sát thuong
         }if (c.sinhcon == 10) {
             dame += 210000000; // + sát thuong
         }if (c.sinhcon == 11) {
             dame += 220000000; // + sát thuong
         }if (c.sinhcon == 12) {
             dame += 230000000; // + sát thuong
         }if (c.sinhcon == 13) {
             dame += 240000000; // + sát thuong
         }if (c.sinhcon == 15) {
             dame += 250000000; // + sát thuong
         }if (c.sinhcon == 16) {
             dame += 260000000; // + sát thuong
         }if (c.sinhcon == 17) {
             dame += 270000000; // + sát thuong
         }if (c.sinhcon == 18) {
             dame += 280000000; // + sát thuong    
         }
        return dame;
    }

    public double dameMin() {
        return this.dameMax() * 90 / 100;
    }

    public float dameDown() {
        float dwn = this.getPramItem(47);//giam sat thuong cua itembody
        if (this.c.isHuman && this.c.ishopthe) {
            dwn += this.c.infocl[10];
        }
        dwn += this.getPramItem(74);//giam sat thuong cua thu cuoi
        dwn += this.getPramItem(80);//giam sat thuong cua tinh luyen
        dwn += this.getPramItem(124);//giam sat thuong cua ngoc
        return dwn;
    }

    public float ResFire() {
        float bear = this.getPramItem(2);
        if (this.c.isHuman && this.c.ishopthe) {
            bear += this.c.infocl[3];
        }
        bear += this.getPramItem(11);
        bear += this.getPramItem(33);
        bear += this.getPramItem(70);
        bear += this.getPramItem(96);
        bear += this.getPramSkill(19);
        bear += this.getPramSkill(20);
        if (this.c.get().getEffId(19) != null) {
            bear += this.c.get().getEffId(19).param;
        }
        if (this.c.get().getEffId(45) != null) {
            bear += this.c.get().getEffId(45).param;
        }
        if (this.c.get().getEffId(26) != null) {
            bear += this.c.get().getEffId(26).param;
        }
        bear += this.getPramItem(20);
        bear += this.getPramItem(36);
        bear += this.getPramItem(81);
        bear += this.getPramItem(118);
        bear += (bear * this.getPramItem(127)/100);
        return bear;
    }

    public float ResIce() {
        float bear = this.getPramItem(3);
        if (this.c.isHuman && this.c.ishopthe) {
            bear += this.c.infocl[4];
        }
        bear += this.getPramItem(12);
        bear += this.getPramItem(34);
        bear += this.getPramItem(71);
        bear += this.getPramItem(95);
        bear += this.getPramSkill(19);
        bear += this.getPramSkill(21);
        if (this.c.get().getEffId(19) != null) {
            bear += this.c.get().getEffId(19).param;
        }
        if (this.c.get().getEffId(45) != null) {
            bear += this.c.get().getEffId(45).param;
        }
        if (this.c.get().getEffId(26) != null) {
            bear += this.c.get().getEffId(26).param;
        }
        bear += this.getPramItem(20);
        bear += this.getPramItem(36);
        bear += this.getPramItem(81);
        bear += this.getPramItem(118);
        bear += (bear * this.getPramItem(128)/100);
        return bear;
    }

    public float ResWind() {
        float bear = this.getPramItem(4);
        if (this.c.isHuman && this.c.ishopthe) {
            bear += this.c.infocl[5];
        }
        bear += this.getPramItem(13);
        bear += this.getPramItem(35);
        bear += this.getPramItem(72);
        bear += this.getPramItem(97);
        bear += this.getPramSkill(19);
        bear += this.getPramSkill(22);
        if (this.c.get().getEffId(19) != null) {
            bear += this.c.get().getEffId(19).param;
        }
        if (this.c.get().getEffId(45) != null) {
            bear += this.c.get().getEffId(45).param;
        }
        if (this.c.get().getEffId(26) != null) {
            bear += this.c.get().getEffId(26).param;
        }
        bear += this.getPramItem(20);
        bear += this.getPramItem(36);
        bear += this.getPramItem(81);
        bear += this.getPramItem(118);
        bear += (bear * this.getPramItem(129)/100);
        return bear;
    }

    public double Exactly() {
        double exa = this.getPotential(1)* 130 / 100;
        if (this.c.isHuman && this.c.ishopthe) {
            exa += this.c.infocl[9];
        }
        if (this.Side() == 2) {
            exa += this.getPotential(1);
        }
        exa += this.getPramItem(10);
        exa += this.getPramItem(18);
        exa += this.getPramItem(75);
        exa += this.getPramItem(86);
        exa += this.getPramItem(116);
        exa += this.getPramSkill(12);
        if (this.c.get().getEffId(24) != null) {
            exa += this.c.get().getEffId(24).param;
        }
        if (this.c.get().getEffId(23) != null) {
            exa += this.c.get().getEffId(23).param;
        }
        return exa;
    }

    public float Miss() {
        float miss = 0;
        if (this.c.get().getEffId(11) != null) {
            miss += this.c.get().getEffId(11).param;
        }else if (this.Side() == 2) {
            miss += this.getPotential(1);
        } else {
            miss += this.getPotential(1) * 130 / 100;
        }
         if (this.c.isHuman && this.c.ishopthe) {
            miss += this.c.infocl[6];
        }
        miss += this.getPotential(1) * 150 / 100;
        miss += this.getPramItem(5);
        miss += this.getPramItem(17);
        miss += this.getPramItem(62);
        miss += this.getPramItem(68);
        miss += this.getPramItem(78);
        miss += this.getPramItem(84);
        miss += this.getPramItem(115);
        miss += this.getPramSkill(13);
        return 0;
    }

    public float Fatal() {
        float ft = 0;
        if (this.c.isHuman && this.c.ishopthe) {
            ft += this.c.infocl[8];
        }
        ft += this.getPramItem(14);
        ft += this.getPramItem(37);
        ft += this.getPramItem(69);
        ft += this.getPramItem(92);
        ft += this.getPramItem(114);
        ft += this.getPramSkill(14);
        //
        if (c.lvdihoa == 1) {
             ft += 200; // + chi mang
         }if (c.lvdihoa == 2) {
             ft += 300; // + chi mang
         }if (c.lvdihoa == 3) {
             ft += 400; // + chi mang
         }if (c.lvdihoa == 4) {
             ft += 500; // + chi mang
         }if (c.lvdihoa == 5) {
             ft += 600; // + chi mang
         }if (c.lvdihoa == 6) {
             ft += 700; // + chi mang
         }if (c.lvdihoa == 7) {
             ft += 800; // + chi mang
         }if (c.lvdihoa == 8) {
             ft += 900; // + chi mang
         }if (c.lvdihoa == 9) {
             ft += 1000; // + chi mang
         }if (c.lvdihoa == 10) {
             ft += 1100; // + chi mang
         }if (c.lvdihoa == 11) {
             ft += 1200; // + chi mang
         }if (c.lvdihoa == 12) {
             ft += 1300; // + chi mang
         }if (c.lvdihoa == 13) {
             ft += 1400; // + chi mang
         }if (c.lvdihoa == 14) {
             ft += 1500; // + chi mang
         }if (c.lvdihoa == 15) {
             ft += 2000; // + chi mang
         }if (c.lvdihoa == 16) {
             ft += 3000; // + chi mang
         }if (c.lvdihoa == 17) {
             ft += 4000; // + chi mang
         }if (c.lvdihoa == 18) {
             ft += 5000; // + chi mang
         }if (c.lvdihoa == 19) {
             ft += 6000; // + chi mang
         }if (c.lvdihoa == 20) {
             ft += 7000; // + chi mang
         }if (c.lvdihoa == 21) {
             ft += 8000; // + chi mang
         }if (c.lvdihoa == 22) {
             ft += 9000; // + chi mang
         }if (c.lvdihoa == 23) {
             ft += 10000; // + chi mang
         }if (c.lvdihoa == 24) {
             ft += 11000; // + chi mang
         }if (c.lvdihoa == 25) {
             ft += 12000; // + chi mang
         }if (c.lvdihoa == 16) {
             ft += 13000; // + chi mang
         }if (c.lvdihoa == 27) {
             ft += 14000; // + chi mang
         }if (c.lvdihoa == 28) {
             ft += 15000; // + chi mang
         }if (c.lvdihoa == 28) {
             ft += 16000; // + chi mang
         }if (c.lvdihoa == 29) {
             ft += 17000; // + chi mang
         }if (c.lvdihoa == 30) {
             ft += 18000; // + chi mang
         }if (c.lvdihoa == 31) {
             ft += 19000; // + chi mang
         }if (c.lvdihoa == 32) {
             ft += 20000; // + chi mang
         }if (c.lvdihoa == 33) {
             ft += 21000; // + chi mang
         }if (c.lvdihoa == 34) {
             ft += 22000; // + chi mang
         }if (c.lvdihoa == 35) {
             ft += 22000; // + chi mang
         }if (c.lvdihoa == 36) {
             ft += 23000; // + chi mang
         }if (c.lvdihoa == 37) {
             ft += 24000; // + chi mang
         }if (c.lvdihoa == 38) {
             ft += 25000; // + chi mang
         }if (c.lvdihoa == 39) {
             ft += 26000; // + chi mang
         }if (c.lvdihoa == 40) {
             ft += 27000; // + chi mang
         }if (c.lvdihoa == 41) {
             ft += 28000; // + chi mang
         }if (c.lvdihoa == 42) {
             ft += 29000; // + chi mang
         }if (c.lvdihoa == 43) {
             ft += 30000; // + chi mang
         }if (c.lvdihoa == 44) {
             ft += 31000; // + chi mang
         }if (c.lvdihoa == 45) {
             ft += 32000; // + chi mang
         }if (c.lvdihoa == 46) {
             ft += 33000; // + chi mang
         }if (c.lvdihoa == 47) {
             ft += 34000; // + chi mang
         }if (c.lvdihoa == 48) {
             ft += 35000; // + chi mang
         }if (c.lvdihoa == 49) {
             ft += 36000; // + chi mang
         }if (c.lvdihoa == 50) {
             ft += 40000; // + chi mang
         }    
         
         // khaohach
         
         if (c.lvthan == 1) {
             ft += 20000; // + chi mang
         }if (c.lvthan == 2) {
             ft += 30000; // + chi mang
         }if (c.lvthan == 3) {
             ft += 40000; // + chi mang
         }if (c.lvthan == 4) {
             ft += 50000; // + chi mang
         }if (c.lvthan == 5) {
             ft += 60000; // + chi mang
         }if (c.lvthan == 6) {
             ft += 70000; // + chi mang
         }if (c.lvthan == 7) {
             ft += 80000; // + chi mang
         }if (c.lvthan == 8) {
             ft += 90000; // + chi mang
         }if (c.lvthan == 9) {
             ft += 100000; // + chi mang
         }if (c.lvthan == 10) {
             ft += 110000; // + chi mang
         }if (c.lvthan == 11) {
             ft += 120000; // + chi mang
         }if (c.lvthan == 12) {
             ft += 130000; // + chi mang
         }if (c.lvthan == 13) {
             ft += 140000; // + chi mang
         }if (c.lvthan == 14) {
             ft += 150000; // + chi mang
         }if (c.lvthan == 15) {
             ft += 200000; // + chi mang
         }if (c.lvthan == 16) {
             ft += 300000; // + chi mang
         }if (c.lvthan == 17) {
             ft += 400000; // + chi mang
         }if (c.lvthan == 18) {
             ft += 500000; // + chi mang
         }if (c.lvthan == 19) {
             ft += 600000; // + chi mang
         }if (c.lvthan == 20) {
             ft += 700000; // + chi mang
         }if (c.lvthan == 21) {
             ft += 800000; // + chi mang
         }if (c.lvthan == 22) {
             ft += 900000; // + chi mang
         }if (c.lvthan == 23) {
             ft += 1000000; // + chi mang
         }if (c.lvthan == 24) {
             ft += 1100000; // + chi mang
         }if (c.lvthan == 25) {
             ft += 1200000; // + chi mang
         }if (c.lvthan == 16) {
             ft += 1300000; // + chi mang
         }if (c.lvthan == 27) {
             ft += 1400000; // + chi mang
         }if (c.lvthan == 28) {
             ft += 1500000; // + chi mang
         }if (c.lvthan == 28) {
             ft += 1600000; // + chi mang
         }if (c.lvthan == 29) {
             ft += 1700000; // + chi mang
         }if (c.lvthan == 30) {
             ft += 1800000; // + chi mang
         }if (c.lvthan == 31) {
             ft += 1900000; // + chi mang
         }if (c.lvthan == 32) {
             ft += 2000000; // + chi mang
         }if (c.lvthan == 33) {
             ft += 2100000; // + chi mang
         }if (c.lvthan == 34) {
             ft += 2200000; // + chi mang
         }if (c.lvthan == 35) {
             ft += 2200000; // + chi mang
         }if (c.lvthan == 36) {
             ft += 2300000; // + chi mang
         }if (c.lvthan == 37) {
             ft += 2400000; // + chi mang
         }if (c.lvthan == 38) {
             ft += 2500000; // + chi mang
         }if (c.lvthan == 39) {
             ft += 2600000; // + chi mang
         }if (c.lvthan == 40) {
             ft += 2700000; // + chi mang
         }if (c.lvthan == 41) {
             ft += 2800000; // + chi mang
         }if (c.lvthan == 42) {
             ft += 2900000; // + chi mang
         }if (c.lvthan == 43) {
             ft += 3000000; // + chi mang
         }if (c.lvthan == 44) {
             ft += 3100000; // + chi mang
         }if (c.lvthan == 45) {
             ft += 3200000; // + chi mang
         }if (c.lvthan == 46) {
             ft += 3300000; // + chi mang
         }if (c.lvthan == 47) {
             ft += 3400000; // + chi mang
         }if (c.lvthan == 48) {
             ft += 3500000; // + chi mang
         }if (c.lvthan == 49) {
             ft += 3600000; // + chi mang
         }if (c.lvthan == 50) {
             ft += 4000000; // + chi mang
         }if (c.lvthan == 51) {
             ft += 5000000; // + chi mang
         }if (c.lvthan == 52) {
             ft += 6000000; // + chi mang
         }if (c.lvthan == 53) {
             ft += 7000000; // + chi mang
         }if (c.lvthan == 54) {
             ft += 8000000; // + chi mang
         }if (c.lvthan == 55) {
             ft += 9000000; // + chi mang
         }if (c.lvthan == 56) {
             ft += 10000000; // + chi mang
         }if (c.lvthan == 57) {
             ft += 11000000; // + chi mang
         }if (c.lvthan == 58) {
             ft += 12000000; // + chi mang
         }if (c.lvthan == 59) {
             ft += 13000000; // + chi mang
         }if (c.lvthan == 60) {
             ft += 14000000; // + chi mang
         }if (c.lvthan == 61) {
             ft += 15000000; // + chi mang
         }if (c.lvthan == 62) {
             ft += 16000000; // + chi mang
         }if (c.lvthan == 63) {
             ft += 17000000; // + chi mang
         }if (c.lvthan == 64) {
             ft += 20000000; // + chi mang
         }     
         // hơi thở
          if (c.hoitho == 1) {
             ft += 200; // + chi mang
         }if (c.hoitho == 2) {
             ft += 300; // + chi mang
         }if (c.hoitho == 3) {
             ft += 400; // + chi mang
         }if (c.hoitho == 4) {
             ft += 500; // + chi mang
         }if (c.hoitho == 5) {
             ft += 600; // + chi mang
         }if (c.hoitho == 6) {
             ft += 700; // + chi mang
         }if (c.hoitho == 7) {
             ft += 800; // + chi mang
         }if (c.hoitho == 8) {
             ft += 900; // + chi mang
         }if (c.hoitho == 9) {
             ft += 1000; // + chi mang
         }if (c.hoitho == 10) {
             ft += 1100; // + chi mang
         }if (c.hoitho == 11) {
             ft += 1200; // + chi mang
         }if (c.hoitho == 12) {
             ft += 1300; // + chi mang
         }if (c.hoitho == 13) {
             ft += 1400; // + chi mang
         }if (c.hoitho == 14) {
             ft += 1500; // + chi mang
         }if (c.hoitho == 15) {
             ft += 1600; // + chi mang
         }if (c.hoitho == 16) {
             ft += 1700; // + chi mang
         }if (c.hoitho == 17) {
             ft += 1800; // + chi mang
         }if (c.hoitho == 18) {
             ft += 1900; // + chi mang
         }if (c.hoitho == 19) {
             ft += 2000; // + chi mang
         }if (c.hoitho == 20) {
             ft += 2100; // + chi mang
         }if (c.hoitho == 21) {
             ft += 2200; // + chi mang
         }if (c.hoitho == 22) {
             ft += 2300; // + chi mang
         }if (c.hoitho == 23) {
             ft += 2400; // + chi mang
         }if (c.hoitho == 24) {
             ft += 2500; // + chi mang
         }if (c.hoitho == 25) {
             ft += 2600; // + chi mang
         }if (c.hoitho == 26) {
             ft += 2700; // + chi mang
         }if (c.hoitho == 27) {
             ft += 2800; // + chi mang
         }if (c.hoitho == 28) {
             ft += 2900; // + chi mang
         }if (c.hoitho == 29) {
             ft += 3000; // + chi mang
         }if (c.hoitho == 30) {
             ft += 3500; // + chi mang
         }if (c.hoitho == 31) {
             ft += 12000; // + chi mang
         }if (c.hoitho == 32) {
             ft += 13000; // + chi mang
         }if (c.hoitho == 33) {
             ft += 14000; // + chi mang
         }if (c.hoitho == 34) {
             ft += 15000; // + chi mang
         }if (c.hoitho == 35) {
             ft += 16000; // + chi mang
         }if (c.hoitho == 36) {
             ft += 17000; // + chi mang
         }if (c.hoitho == 37) {
             ft += 18000; // + chi mang
         }if (c.hoitho == 38) {
             ft += 19000; // + chi mang
         }if (c.hoitho == 39) {
             ft += 20000; // + chi mang
         }if (c.hoitho == 40) {
             ft += 21000; // + chi mang
         }if (c.hoitho == 41) {
             ft += 22000; // + chi mang
         }if (c.hoitho == 42) {
             ft += 23000; // + chi mang
         }if (c.hoitho == 43) {
             ft += 24000; // + chi mang
         }if (c.hoitho == 44) {
             ft += 25000; // + chi mang
         }if (c.hoitho == 45) {
             ft += 26000; // + chi mang
         }if (c.hoitho == 46) {
             ft += 27000; // + chi mang
         }if (c.hoitho == 47) {
             ft += 28000; // + chi mang
         }if (c.hoitho == 48) {
             ft += 29000; // + chi mang
         }if (c.hoitho == 49) {
             ft += 30000; // + chi mang
         }if (c.hoitho == 50) {
             ft += 35000; // + chi mang
         }
         //sinhcon
         if (c.sinhcon == 1) {
             ft += 2000; // + chi mang
         }if (c.sinhcon == 2) {
             ft += 3000; // + chi mang
         }if (c.sinhcon == 3) {
             ft += 4000; // + chi mang
         }if (c.sinhcon == 4) {
             ft += 5000; // + chi mang
         }if (c.sinhcon == 5) {
             ft += 6000; // + chi mang
         }if (c.sinhcon == 6) {
             ft += 7000; // + chi mang
         }if (c.sinhcon == 7) {
             ft += 8000; // + chi mang
         }if (c.sinhcon == 8) {
             ft += 9000; // + chi mang
         }if (c.sinhcon == 9) {
             ft += 10000; // + chi mang
         }if (c.sinhcon == 10) {
             ft += 11000; // + chi mang
         }if (c.sinhcon == 11) {
             ft += 12000; // + chi mang
         }if (c.sinhcon == 12) {
             ft += 13000; // + chi mang
         }if (c.sinhcon == 13) {
             ft += 14000; // + chi mang
         }if (c.sinhcon == 14) {
             ft += 15000; // + chi mang
         }if (c.sinhcon == 15) {
             ft += 20000; // + chi mang
         }if (c.sinhcon == 16) {
             ft += 30000; // + chi mang
         }if (c.sinhcon == 17) {
             ft += 40000; // + chi mang
         }if (c.sinhcon == 18) {
             ft += 50000; // + chi mang
         }    
        return ft;
    }

    public double percentFantalDameDown() {
        double pfdd = 0;
        pfdd += this.getPramItem(46);
        pfdd += this.getPramItem(79);
        pfdd += this.getPramItem(121);
        return pfdd;
    }

    public double FantalDame() {
        return this.getPramItem(105);
    }

    public long percentFantalDame() {
        long pfd = 0;
        pfd += this.getPramItem(39);
        pfd += this.getPramItem(67);
        pfd += this.getPramSkill(65);
        if (c.lvdihoa == 1) {
             pfd += 200; // + Tiem nang
         }if (c.lvdihoa == 2) {
             pfd += 300; // + Tiem nang
         }if (c.lvdihoa == 3) {
             pfd += 400; // + Tiem nang
         }if (c.lvdihoa == 4) {
             pfd += 500; // + Tiem nang
         }if (c.lvdihoa == 5) {
             pfd += 600; // + Tiem nang
         }if (c.lvdihoa == 6) {
             pfd += 700; // + Tiem nang
         }if (c.lvdihoa == 7) {
             pfd += 800; // + Tiem nang
         }if (c.lvdihoa == 8) {
             pfd += 900; // + Tiem nang
         }if (c.lvdihoa == 9) {
             pfd += 1000; // + Tiem nang
         }if (c.lvdihoa == 10) {
             pfd += 1100; // + Tiem nang
         }if (c.lvdihoa == 11) {
             pfd += 1200; // + Tiem nang
         }if (c.lvdihoa == 12) {
             pfd += 1300; // + Tiem nang
         }if (c.lvdihoa == 13) {
             pfd += 1400; // + Tiem nang
         }if (c.lvdihoa == 14) {
             pfd += 1500; // + Tiem nang
         }if (c.lvdihoa == 15) {
             pfd += 2000; // + Tiem nang
         }if (c.lvdihoa == 16) {
             pfd += 3000; // + Tiem nang
         }if (c.lvdihoa == 17) {
             pfd += 4000; // + Tiem nang
         }if (c.lvdihoa == 18) {
             pfd += 5000; // + Tiem nang
         }if (c.lvdihoa == 19) {
             pfd += 6000; // + Tiem nang
         }if (c.lvdihoa == 20) {
             pfd += 7000; // + Tiem nang
         }if (c.lvdihoa == 21) {
             pfd += 8000; // + Tiem nang
         }if (c.lvdihoa == 22) {
             pfd += 9000; // + Tiem nang
         }if (c.lvdihoa == 23) {
             pfd += 10000; // + Tiem nang
         }if (c.lvdihoa == 24) {
             pfd += 11000; // + Tiem nang
         }if (c.lvdihoa == 25) {
             pfd += 12000; // + Tiem nang
         }if (c.lvdihoa == 26) {
             pfd += 13000; // + Tiem nang
         }if (c.lvdihoa == 27) {
             pfd += 14000; // + Tiem nang
         }if (c.lvdihoa == 28) {
             pfd += 15000; // + Tiem nang
         }if (c.lvdihoa == 29) {
             pfd += 17000; // + Tiem nang
         }if (c.lvdihoa == 30) {
             pfd += 18000; // + Tiem nang
         }if (c.lvdihoa == 31) {
             pfd += 19000; // + Tiem nang
         }if (c.lvdihoa == 32) {
             pfd += 20000; // + Tiem nang
         }if (c.lvdihoa == 33) {
             pfd += 21000; // + Tiem nang
         }if (c.lvdihoa == 34) {
             pfd += 22000; // + Tiem nang
         }if (c.lvdihoa == 35) {
             pfd += 23000; // + Tiem nang
         }if (c.lvdihoa == 36) {
             pfd += 24000; // + Tiem nang
         }if (c.lvdihoa == 37) {
             pfd += 25000; // + Tiem nang
         }if (c.lvdihoa == 38) {
             pfd += 26000; // + Tiem nang
         }if (c.lvdihoa == 39) {
             pfd += 27000; // + Tiem nang
         }if (c.lvdihoa == 40) {
             pfd += 28000; // + Tiem nang
         }if (c.lvdihoa == 41) {
             pfd += 29000; // + Tiem nang
         }if (c.lvdihoa == 42) {
             pfd += 30000; // + Tiem nang
         }if (c.lvdihoa == 43) {
             pfd += 31000; // + Tiem nang
         }if (c.lvdihoa == 44) {
             pfd += 32000; // + Tiem nang
         }if (c.lvdihoa == 45) {
             pfd += 33000; // + Tiem nang
         }if (c.lvdihoa == 46) {
             pfd += 34000; // + Tiem nang
         }if (c.lvdihoa == 47) {
             pfd += 35000; // + Tiem nang
         }if (c.lvdihoa == 48) {
             pfd += 36000; // + Tiem nang
         }if (c.lvdihoa == 49) {
             pfd += 37000; // + Tiem nang
         }if (c.lvdihoa == 50) {
             pfd += 40000; // + Tiem nang
         }
         
         // khaohach
         
         if (c.lvthan == 1) {
             pfd += 20000; // + Tiem nang
         }if (c.lvthan == 2) {
             pfd += 30000; // + Tiem nang
         }if (c.lvthan == 3) {
             pfd += 40000; // + Tiem nang
         }if (c.lvthan == 4) {
             pfd += 50000; // + Tiem nang
         }if (c.lvthan == 5) {
             pfd += 60000; // + Tiem nang
         }if (c.lvthan == 6) {
             pfd += 70000; // + Tiem nang
         }if (c.lvthan == 7) {
             pfd += 80000; // + Tiem nang
         }if (c.lvthan == 8) {
             pfd += 90000; // + Tiem nang
         }if (c.lvthan == 9) {
             pfd += 100000; // + Tiem nang
         }if (c.lvthan == 10) {
             pfd += 110000; // + Tiem nang
         }if (c.lvthan == 11) {
             pfd += 120000; // + Tiem nang
         }if (c.lvthan == 12) {
             pfd += 130000; // + Tiem nang
         }if (c.lvthan == 13) {
             pfd += 140000; // + Tiem nang
         }if (c.lvthan == 14) {
             pfd += 150000; // + Tiem nang
         }if (c.lvthan == 15) {
             pfd += 200000; // + Tiem nang
         }if (c.lvthan == 16) {
             pfd += 300000; // + Tiem nang
         }if (c.lvthan == 17) {
             pfd += 400000; // + Tiem nang
         }if (c.lvthan == 18) {
             pfd += 500000; // + Tiem nang
         }if (c.lvthan == 19) {
             pfd += 600000; // + Tiem nang
         }if (c.lvthan == 20) {
             pfd += 700000; // + Tiem nang
         }if (c.lvthan == 21) {
             pfd += 800000; // + Tiem nang
         }if (c.lvthan == 22) {
             pfd += 900000; // + Tiem nang
         }if (c.lvthan == 23) {
             pfd += 1000000; // + Tiem nang
         }if (c.lvthan == 24) {
             pfd += 1100000; // + Tiem nang
         }if (c.lvthan == 25) {
             pfd += 1200000; // + Tiem nang
         }if (c.lvthan == 26) {
             pfd += 1300000; // + Tiem nang
         }if (c.lvthan == 27) {
             pfd += 1400000; // + Tiem nang
         }if (c.lvthan == 28) {
             pfd += 1500000; // + Tiem nang
         }if (c.lvthan == 29) {
             pfd += 1700000; // + Tiem nang
         }if (c.lvthan == 30) {
             pfd += 1800000; // + Tiem nang
         }if (c.lvthan == 31) {
             pfd += 1900000; // + Tiem nang
         }if (c.lvthan == 32) {
             pfd += 2000000; // + Tiem nang
         }if (c.lvthan == 33) {
             pfd += 2100000; // + Tiem nang
         }if (c.lvthan == 34) {
             pfd += 220000; // + Tiem nang
         }if (c.lvthan == 35) {
             pfd += 2300000; // + Tiem nang
         }if (c.lvthan == 36) {
             pfd += 2400000; // + Tiem nang
         }if (c.lvthan == 37) {
             pfd += 2500000; // + Tiem nang
         }if (c.lvthan == 38) {
             pfd += 2600000; // + Tiem nang
         }if (c.lvthan == 39) {
             pfd += 2700000; // + Tiem nang
         }if (c.lvthan == 40) {
             pfd += 2800000; // + Tiem nang
         }if (c.lvthan == 41) {
             pfd += 2900000; // + Tiem nang
         }if (c.lvthan == 42) {
             pfd += 3000000; // + Tiem nang
         }if (c.lvthan == 43) {
             pfd += 3100000; // + Tiem nang
         }if (c.lvthan == 44) {
             pfd += 3200000; // + Tiem nang
         }if (c.lvthan == 45) {
             pfd += 3300000; // + Tiem nang
         }if (c.lvthan == 46) {
             pfd += 3400000; // + Tiem nang
         }if (c.lvthan == 47) {
             pfd += 3500000; // + Tiem nang
         }if (c.lvthan == 48) {
             pfd += 3600000; // + Tiem nang
         }if (c.lvthan == 49) {
             pfd += 3700000; // + Tiem nang
         }if (c.lvthan == 50) {
             pfd += 4000000; // + Tiem nang
         }if (c.lvthan == 51) {
             pfd += 5000000; // + Tiem nang
         }if (c.lvthan == 52) {
             pfd += 6000000; // + Tiem nang
         }if (c.lvthan == 53) {
             pfd += 7000000; // + Tiem nang
         }if (c.lvthan == 54) {
             pfd += 8000000; // + Tiem nang
         }if (c.lvthan == 55) {
             pfd += 9000000; // + Tiem nang
         }if (c.lvthan == 56) {
             pfd += 10000000; // + Tiem nang
         }if (c.lvthan == 57) {
             pfd += 11000000; // + Tiem nang
         }if (c.lvthan == 58) {
             pfd += 12000000; // + Tiem nang
         }if (c.lvthan == 59) {
             pfd += 13000000; // + Tiem nang
         }if (c.lvthan == 60) {
             pfd += 14000000; // + Tiem nang
         }if (c.lvthan == 61) {
             pfd += 15000000; // + Tiem nang
         }if (c.lvthan == 62) {
             pfd += 15000000; // + Tiem nang
         }if (c.lvthan == 63) {
             pfd += 16000000; // + Tiem nang
         }if (c.lvthan == 64) {
             pfd += 20000000; // + Tiem nang
         }
   
         // hoi thở
          if (c.hoitho == 1) {
             pfd += 200; // + Tiem nang
         }if (c.hoitho == 2) {
             pfd += 300; // + Tiem nang
         }if (c.hoitho == 3) {
             pfd += 400; // + Tiem nang
         }if (c.hoitho == 4) {
             pfd += 500; // + Tiem nang
         }if (c.hoitho == 5) {
             pfd += 600; // + Tiem nang
         }if (c.hoitho == 6) {
             pfd += 700; // + Tiem nang
         }if (c.hoitho == 7) {
             pfd += 800; // + Tiem nang
         }if (c.hoitho == 8) {
             pfd += 900; // + Tiem nang
         }if (c.hoitho == 9) {
             pfd += 1000; // + Tiem nang
         }if (c.hoitho == 10) {
             pfd += 1100; // + Tiem nang
         }if (c.hoitho == 11) {
             pfd += 1200; // + Tiem nang
         }if (c.hoitho == 12) {
             pfd += 1300; // + Tiem nang
         }if (c.hoitho == 13) {
             pfd += 1400; // + Tiem nang
         }if (c.hoitho == 14) {
             pfd += 1500; // + Tiem nang
         }if (c.hoitho == 15) {
             pfd += 1600; // + Tiem nang
         }if (c.hoitho == 16) {
             pfd += 1700; // + Tiem nang
         }if (c.hoitho == 17) {
             pfd += 1800; // + Tiem nang
         }if (c.hoitho == 18) {
             pfd += 1900; // + Tiem nang
         }if (c.hoitho == 19) {
             pfd += 2000; // + Tiem nang
         }if (c.hoitho == 20) {
             pfd += 2100; // + Tiem nang
         }if (c.hoitho == 21) {
             pfd += 2200; // + Tiem nang
         }if (c.hoitho == 22) {
             pfd += 2300; // + Tiem nang
         }if (c.hoitho == 23) {
             pfd += 2400; // + Tiem nang
         }if (c.hoitho == 24) {
             pfd += 2500; // + Tiem nang
         }if (c.hoitho == 25) {
             pfd += 2600; // + Tiem nang
         }if (c.hoitho == 26) {
             pfd += 2700; // + Tiem nang
         }if (c.hoitho == 27) {
             pfd += 2800; // + Tiem nang
         }if (c.hoitho == 28) {
             pfd += 2900; // + Tiem nang
         }if (c.hoitho == 29) {
             pfd += 3000; // + Tiem nang
         }if (c.hoitho == 30) {
             pfd += 3500; // + Tiem nang
         }if (c.hoitho == 31) {
             pfd += 120000; // + Tiem nang
         }if (c.hoitho == 32) {
             pfd += 130000; // + Tiem nang
         }if (c.hoitho == 33) {
             pfd += 140000; // + Tiem nang
         }if (c.hoitho == 34) {
             pfd += 150000; // + Tiem nang
         }if (c.hoitho == 35) {
             pfd += 160000; // + Tiem nang
         }if (c.hoitho == 36) {
             pfd += 170000; // + Tiem nang
         }if (c.hoitho == 37) {
             pfd += 180000; // + Tiem nang
         }if (c.hoitho == 38) {
             pfd += 190000; // + Tiem nang
         }if (c.hoitho == 39) {
             pfd += 200000; // + Tiem nang
         }if (c.hoitho == 40) {
             pfd += 210000; // + Tiem nang
         }if (c.hoitho == 41) {
             pfd += 220000; // + Tiem nang
         }if (c.hoitho == 42) {
             pfd += 230000; // + Tiem nang
         }if (c.hoitho == 43) {
             pfd += 240000; // + Tiem nang
         }if (c.hoitho == 44) {
             pfd += 250000; // + Tiem nang
         }if (c.hoitho == 45) {
             pfd += 260000; // + Tiem nang
         }if (c.hoitho == 46) {
             pfd += 270000; // + Tiem nang
         }if (c.hoitho == 47) {
             pfd += 280000; // + Tiem nang
         }if (c.hoitho == 48) {
             pfd += 290000; // + Tiem nang
         }if (c.hoitho == 49) {
             pfd += 300000; // + Tiem nang
         }if (c.hoitho == 50) {
             pfd += 350000; // + Tiem nang
         }
         // sinh con
         if (c.sinhcon == 1) {
             pfd += 2000; // + Tiem nang
         }if (c.sinhcon == 2) {
             pfd += 3000; // + Tiem nang
         }if (c.sinhcon == 3) {
             pfd += 4000; // + Tiem nang
         }if (c.sinhcon == 4) {
             pfd += 5000; // + Tiem nang
         }if (c.sinhcon == 5) {
             pfd += 6000; // + Tiem nang
         }if (c.sinhcon == 6) {
             pfd += 7000; // + Tiem nang
         }if (c.sinhcon == 7) {
             pfd += 8000; // + Tiem nang
         }if (c.sinhcon == 8) {
             pfd += 9000; // + Tiem nang
         }if (c.sinhcon == 9) {
             pfd += 10000; // + Tiem nang
         }if (c.sinhcon == 10) {
             pfd += 11000; // + Tiem nang
         }if (c.sinhcon == 11) {
             pfd += 12000; // + Tiem nang
         }if (c.sinhcon == 12) {
             pfd += 13000; // + Tiem nang
         }if (c.sinhcon == 13) {
             pfd += 14000; // + Tiem nang
         }if (c.sinhcon == 14) {
             pfd += 15000; // + Tiem nang
         }if (c.sinhcon == 15) {
             pfd += 20000; // + Tiem nang
         }if (c.sinhcon == 16) {
             pfd += 30000; // + Tiem nang
         }if (c.sinhcon == 17) {
             pfd += 40000; // + Tiem nang
         }if (c.sinhcon == 18) {
             pfd += 50000; // + Tiem nang
         }    
        return pfd;
    }

    public float ReactDame() {
        float rd = 0;
        if (this.c.isHuman && this.c.ishopthe) {
            rd += this.c.infocl[7];
        }
        rd += this.getPramItem(15);
        rd += this.getPramItem(91);
        rd += this.getPramItem(126);
        rd += this.getPramSkill(15);
        return rd;
    }

    public float sysUp() {
        return 0;
    }

    public float sysDown() {
        return 0;
    }

    public float percentFire2() {
        if (this.isNhanban) {
            return this.getPramSkillClone(24);
        }
        return this.getPramSkill(24);
    }

    public float percentFire4() {
        if (this.isNhanban) {
            return this.getPramSkillClone(34);
        }
        return this.getPramSkill(34);
    }

    public float percentIce1_5() {
        if (this.isNhanban) {
            return this.getPramSkillClone(25);
        }
        return this.getPramSkill(25);

    }

    public float percentWind1() {
        if (this.isNhanban) {
            return this.getPramSkillClone(26);
        }
        return this.getPramSkill(26);
    }

    public float percentWind2() {
        if (this.isNhanban) {
            return this.getPramSkillClone(36);
        }
        return this.getPramSkill(36);
    }

    public double getPotential(int i) {
        double potential = 0f;
        switch (i) {
            case 0: {
                potential = this.potential0;
                break;
            }
            case 1: {
                potential = this.potential1;
                break;
            }
            case 2: {
                potential = this.potential2;
                break;
            }
            case 3: {
                potential = this.potential3;
                break;
            }
        }
        potential = ((double) potential) * (100 + this.getPramItem(58)) / 100;
        potential += this.getPramItem(57);
        if (c.lvdihoa == 1) {
             potential += 2000; // + % Tiềm năng
         }if (c.lvdihoa == 2) {
             potential += 3000; // + % Tiềm năng
         }if (c.lvdihoa == 3) {
             potential += 4000; // + % Tiềm năng
         }if (c.lvdihoa == 4) {
             potential += 5000; // + % Tiềm năng
         }if (c.lvdihoa == 5) {
             potential += 6000; // + % Tiềm năng
         }if (c.lvdihoa == 6) {
             potential += 7000; // + % Tiềm năng
         }if (c.lvdihoa == 7) {
             potential += 8000; // + % Tiềm năng
         }if (c.lvdihoa == 8) {
             potential += 9000; // + % Tiềm năng
         }if (c.lvdihoa == 9) {
             potential += 10000; // + % Tiềm năng
         }if (c.lvdihoa == 10) {
             potential += 11000; // + % Tiềm năng
         }if (c.lvdihoa == 11) {
             potential += 12000; // + % Tiềm năng
         }if (c.lvdihoa == 12) {
             potential += 13000; // + % Tiềm năng
         }if (c.lvdihoa == 13) {
             potential += 14000; // + % Tiềm năng
         }if (c.lvdihoa == 14) {
             potential += 15000; // + % Tiềm năng
         }if (c.lvdihoa == 15) {
             potential += 20000; // + % Tiềm năng
         }if (c.lvdihoa == 16) {
             potential += 30000; // + % Tiềm năng
         }if (c.lvdihoa == 17) {
             potential += 40000; // + % Tiềm năng
         }if (c.lvdihoa == 18) {
             potential += 50000; // + % Tiềm năng
         }if (c.lvdihoa == 19) {
             potential += 60000; // + % Tiềm năng
         }if (c.lvdihoa == 20) {
             potential += 70000; // + % Tiềm năng
         }if (c.lvdihoa == 21) {
             potential += 80000; // + % Tiềm năng
         }if (c.lvdihoa == 22) {
             potential += 90000; // + % Tiềm năng
         }if (c.lvdihoa == 23) {
             potential += 100000; // + % Tiềm năng
         }if (c.lvdihoa == 24) {
             potential += 110000; // + % Tiềm năng
         }if (c.lvdihoa == 25) {
             potential += 120000; // + % Tiềm năng
         }if (c.lvdihoa == 26) {
             potential += 130000; // + % Tiềm năng
         }if (c.lvdihoa == 27) {
             potential += 140000; // + % Tiềm năng
         }if (c.lvdihoa == 28) {
             potential += 150000; // + % Tiềm năng
         }if (c.lvdihoa == 29) {
             potential += 160000; // + % Tiềm năng
         }if (c.lvdihoa == 30) {
             potential += 170000; // + % Tiềm năng
         }if (c.lvdihoa == 31) {
             potential += 180000; // + % Tiềm năng
         }if (c.lvdihoa == 32) {
             potential += 190000; // + % Tiềm năng
         }if (c.lvdihoa == 33) {
             potential += 200000; // + % Tiềm năng
         }if (c.lvdihoa == 34) {
             potential += 210000; // + % Tiềm năng
         }if (c.lvdihoa == 35) {
             potential += 220000; // + % Tiềm năng
         }if (c.lvdihoa == 36) {
             potential += 230000; // + % Tiềm năng
         }if (c.lvdihoa == 37) {
             potential += 240000; // + % Tiềm năng
         }if (c.lvdihoa == 38) {
             potential += 250000; // + % Tiềm năng
         }if (c.lvdihoa == 39) {
             potential += 260000; // + % Tiềm năng
         }if (c.lvdihoa == 40) {
             potential += 270000; // + % Tiềm năng
         }if (c.lvdihoa == 41) {
             potential += 280000; // + % Tiềm năng
         }if (c.lvdihoa == 42) {
             potential += 290000; // + % Tiềm năng
         }if (c.lvdihoa == 43) {
             potential += 300000; // + % Tiềm năng
         }if (c.lvdihoa == 44) {
             potential += 310000; // + % Tiềm năng
         }if (c.lvdihoa == 45) {
             potential += 320000; // + % Tiềm năng
         }if (c.lvdihoa == 46) {
             potential += 330000; // + % Tiềm năng
         }if (c.lvdihoa == 47) {
             potential += 340000; // + % Tiềm năng
         }if (c.lvdihoa == 48) {
             potential += 350000; // + % Tiềm năng
         }if (c.lvdihoa == 49) {
             potential += 360000; // + % Tiềm năng
         }if (c.lvdihoa == 50) {
             potential += 400000; // + % Tiềm năng
         }    
         
         //khaohach
         
         if (c.lvthan == 1) {
             potential += 20000; // + % Tiềm năng
         }if (c.lvthan == 2) {
             potential += 30000; // + % Tiềm năng
         }if (c.lvthan == 3) {
             potential += 40000; // + % Tiềm năng
         }if (c.lvthan == 4) {
             potential += 50000; // + % Tiềm năng
         }if (c.lvthan == 5) {
             potential += 60000; // + % Tiềm năng
         }if (c.lvthan == 6) {
             potential += 70000; // + % Tiềm năng
         }if (c.lvthan == 7) {
             potential += 80000; // + % Tiềm năng
         }if (c.lvthan == 8) {
             potential += 90000; // + % Tiềm năng
         }if (c.lvthan == 9) {
             potential += 100000; // + % Tiềm năng
         }if (c.lvthan == 10) {
             potential += 110000; // + % Tiềm năng
         }if (c.lvthan == 11) {
             potential += 120000; // + % Tiềm năng
         }if (c.lvthan == 12) {
             potential += 130000; // + % Tiềm năng
         }if (c.lvthan == 13) {
             potential += 140000; // + % Tiềm năng
         }if (c.lvthan == 14) {
             potential += 150000; // + % Tiềm năng
         }if (c.lvthan == 15) {
             potential += 200000; // + % Tiềm năng
         }if (c.lvthan == 16) {
             potential += 300000; // + % Tiềm năng
         }if (c.lvthan == 17) {
             potential += 400000; // + % Tiềm năng
         }if (c.lvthan == 18) {
             potential += 500000; // + % Tiềm năng
         }if (c.lvthan == 19) {
             potential += 600000; // + % Tiềm năng
         }if (c.lvthan == 20) {
             potential += 700000; // + % Tiềm năng
         }if (c.lvthan == 21) {
             potential += 800000; // + % Tiềm năng
         }if (c.lvthan == 22) {
             potential += 900000; // + % Tiềm năng
         }if (c.lvthan == 23) {
             potential += 1000000; // + % Tiềm năng
         }if (c.lvthan == 24) {
             potential += 1100000; // + % Tiềm năng
         }if (c.lvthan == 25) {
             potential += 1200000; // + % Tiềm năng
         }if (c.lvthan == 26) {
             potential += 1300000; // + % Tiềm năng
         }if (c.lvthan == 27) {
             potential += 1400000; // + % Tiềm năng
         }if (c.lvthan == 28) {
             potential += 1500000; // + % Tiềm năng
         }if (c.lvthan == 29) {
             potential += 1600000; // + % Tiềm năng
         }if (c.lvthan == 30) {
             potential += 1700000; // + % Tiềm năng
         }if (c.lvthan == 31) {
             potential += 1800000; // + % Tiềm năng
         }if (c.lvthan == 32) {
             potential += 1900000; // + % Tiềm năng
         }if (c.lvthan == 33) {
             potential += 2000000; // + % Tiềm năng
         }if (c.lvthan == 34) {
             potential += 2100000; // + % Tiềm năng
         }if (c.lvthan == 35) {
             potential += 2200000; // + % Tiềm năng
         }if (c.lvthan == 36) {
             potential += 2300000; // + % Tiềm năng
         }if (c.lvthan == 37) {
             potential += 2400000; // + % Tiềm năng
         }if (c.lvthan == 38) {
             potential += 2500000; // + % Tiềm năng
         }if (c.lvthan == 39) {
             potential += 2600000; // + % Tiềm năng
         }if (c.lvthan == 40) {
             potential += 2700000; // + % Tiềm năng
         }if (c.lvthan == 41) {
             potential += 2800000; // + % Tiềm năng
         }if (c.lvthan == 42) {
             potential += 2900000; // + % Tiềm năng
         }if (c.lvthan == 43) {
             potential += 3000000; // + % Tiềm năng
         }if (c.lvthan == 44) {
             potential += 3100000; // + % Tiềm năng
         }if (c.lvthan == 45) {
             potential += 3200000; // + % Tiềm năng
         }if (c.lvthan == 46) {
             potential += 3300000; // + % Tiềm năng
         }if (c.lvthan == 47) {
             potential += 3400000; // + % Tiềm năng
         }if (c.lvthan == 48) {
             potential += 3500000; // + % Tiềm năng
         }if (c.lvthan == 49) {
             potential += 3600000; // + % Tiềm năng
         }if (c.lvthan == 50) {
             potential += 4000000; // + % Tiềm năng
         }if (c.lvthan == 51) {
             potential += 4500000; // + % Tiềm năng
         }if (c.lvthan == 52) {
             potential += 5000000; // + % Tiềm năng
         }if (c.lvthan == 53) {
             potential += 5500000; // + % Tiềm năng
         }if (c.lvthan == 54) {
             potential += 6000000; // + % Tiềm năng
         }if (c.lvthan == 55) {
             potential += 6500000; // + % Tiềm năng
         }if (c.lvthan == 56) {
             potential += 7000000; // + % Tiềm năng
         }if (c.lvthan == 57) {
             potential += 7500000; // + % Tiềm năng
         }if (c.lvthan == 58) {
             potential += 8000000; // + % Tiềm năng
         }if (c.lvthan == 59) {
             potential += 8500000; // + % Tiềm năng
         }if (c.lvthan == 60) {
             potential += 9000000; // + % Tiềm năng
         }if (c.lvthan == 61) {
             potential += 9500000; // + % Tiềm năng
         }if (c.lvthan == 62) {
             potential += 10000000; // + % Tiềm năng
         }if (c.lvthan == 63) {
             potential += 11000000; // + % Tiềm năng
         }if (c.lvthan == 64) {
             potential += 12000000; // + % Tiềm năng
         } 
         // hơi thở
          if (c.hoitho == 1) {
             potential += 20000; // + % Tiềm năng
         }if (c.hoitho == 2) {
             potential += 30000; // + % Tiềm năng
         }if (c.hoitho == 3) {
             potential += 40000; // + % Tiềm năng
         }if (c.hoitho == 4) {
             potential += 50000; // + % Tiềm năng
         }if (c.hoitho == 5) {
             potential += 60000; // + % Tiềm năng
         }if (c.hoitho == 6) {
             potential += 70000; // + % Tiềm năng
         }if (c.hoitho == 7) {
             potential += 80000; // + % Tiềm năng
         }if (c.hoitho == 8) {
             potential += 90000; // + % Tiềm năng
         }if (c.hoitho == 9) {
             potential += 100000; // + % Tiềm năng
         }if (c.hoitho == 10) {
             potential += 110000; // + % Tiềm năng
         }if (c.hoitho == 11) {
             potential += 120000; // + % Tiềm năng
         }if (c.hoitho == 12) {
             potential += 130000; // + % Tiềm năng
         }if (c.hoitho == 13) {
             potential += 140000; // + % Tiềm năng
         }if (c.hoitho == 14) {
             potential += 150000; // + % Tiềm năng
         }if (c.hoitho == 15) {
             potential += 160000; // + % Tiềm năng
         }if (c.hoitho == 16) {
             potential += 170000; // + % Tiềm năng
         }if (c.hoitho == 17) {
             potential += 180000; // + % Tiềm năng
         }if (c.hoitho == 18) {
             potential += 190000; // + % Tiềm năng
         }if (c.hoitho == 19) {
             potential += 200000; // + % Tiềm năng
         }if (c.hoitho == 20) {
             potential += 210000; // + % Tiềm năng
         }if (c.hoitho == 21) {
             potential += 220000; // + % Tiềm năng
         }if (c.hoitho == 22) {
             potential += 230000; // + % Tiềm năng
         }if (c.hoitho == 23) {
             potential += 240000; // + % Tiềm năng
         }if (c.hoitho == 24) {
             potential += 250000; // + % Tiềm năng
         }if (c.hoitho == 25) {
             potential += 260000; // + % Tiềm năng
         }if (c.hoitho == 26) {
             potential += 270000; // + % Tiềm năng
         }if (c.hoitho == 27) {
             potential += 280000; // + % Tiềm năng
         }if (c.hoitho == 28) {
             potential += 290000; // + % Tiềm năng
         }if (c.hoitho == 29) {
             potential += 300000; // + % Tiềm năng
         }if (c.hoitho == 30) {
             potential += 350000; // + % Tiềm năng
         }if (c.hoitho == 31) {
             potential += 1200000; // + % Tiềm năng
         }if (c.hoitho == 32) {
             potential += 1300000; // + % Tiềm năng
         }if (c.hoitho == 33) {
             potential += 1400000; // + % Tiềm năng
         }if (c.hoitho == 34) {
             potential += 1500000; // + % Tiềm năng
         }if (c.hoitho == 35) {
             potential += 1600000; // + % Tiềm năng
         }if (c.hoitho == 36) {
             potential += 1700000; // + % Tiềm năng
         }if (c.hoitho == 37) {
             potential += 1800000; // + % Tiềm năng
         }if (c.hoitho == 38) {
             potential += 1900000; // + % Tiềm năng
         }if (c.hoitho == 39) {
             potential += 2000000; // + % Tiềm năng
         }if (c.hoitho == 40) {
             potential += 2100000; // + % Tiềm năng
         }if (c.hoitho == 41) {
             potential += 2200000; // + % Tiềm năng
         }if (c.hoitho == 42) {
             potential += 2300000; // + % Tiềm năng
         }if (c.hoitho == 43) {
             potential += 2400000; // + % Tiềm năng
         }if (c.hoitho == 44) {
             potential += 2500000; // + % Tiềm năng
         }if (c.hoitho == 45) {
             potential += 2600000; // + % Tiềm năng
         }if (c.hoitho == 46) {
             potential += 2700000; // + % Tiềm năng
         }if (c.hoitho == 47) {
             potential += 2800000; // + % Tiềm năng
         }if (c.hoitho == 48) {
             potential += 2900000; // + % Tiềm năng
         }if (c.hoitho == 49) {
             potential += 3000000; // + % Tiềm năng
         }if (c.hoitho == 50) {
             potential += 15000000; // + % Tiềm năng
         }
         //sinh con
         if (c.sinhcon == 1) {
             potential += 20000; // + % Tiềm năng
         }if (c.sinhcon == 2) {
             potential += 30000; // + % Tiềm năng
         }if (c.sinhcon == 3) {
             potential += 40000; // + % Tiềm năng
         }if (c.sinhcon == 4) {
             potential += 50000; // + % Tiềm năng
         }if (c.sinhcon == 5) {
             potential += 60000; // + % Tiềm năng
         }if (c.sinhcon == 6) {
             potential += 70000; // + % Tiềm năng
         }if (c.sinhcon == 7) {
             potential += 80000; // + % Tiềm năng
         }if (c.sinhcon == 8) {
             potential += 90000; // + % Tiềm năng
         }if (c.sinhcon == 9) {
             potential += 100000; // + % Tiềm năng
         }if (c.sinhcon == 10) {
             potential += 110000; // + % Tiềm năng
         }if (c.sinhcon == 11) {
             potential += 120000; // + % Tiềm năng
         }if (c.sinhcon == 12) {
             potential += 130000; // + % Tiềm năng
         }if (c.sinhcon == 13) {
             potential += 140000; // + % Tiềm năng
         }if (c.sinhcon == 14) {
             potential += 150000; // + % Tiềm năng
         }if (c.sinhcon == 15) {
             potential += 160000; // + % Tiềm năng
         }if (c.sinhcon == 16) {
             potential += 170000; // + % Tiềm năng
         }if (c.sinhcon == 17) {
             potential += 180000; // + % Tiềm năng
         }if (c.sinhcon == 18) {
             potential += 190000; // + % Tiềm năng
         }    
        return potential;
    }

    public float getPramItem(float id) {
        try {
            if (this.c.get() == null) {
                return 0;
            }
            float param = 0;

            for (Item body : this.c.get().ItemBody) {
                if (body != null) {
                    for (Option option : body.options) {
                        if (option.id == id && !ItemTemplate.isUpgradeHide(option.id, body.upgrade)) {
                            param += option.param;
                        }
                    }
                    if (body.ngocs != null && body.ngocs.size() > 0 && ItemTemplate.isCheckId((int) id)) {
                        int idNgocOption = -1;
                        if (body.getData().type == 1) {
                            idNgocOption = ItemTemplate.VU_KHI_OPTION_ID;
                        } else if (body.getData().isTrangSuc()) {
                            idNgocOption = ItemTemplate.TRANG_SUC_OPTION_ID;
                        } else if (body.getData().isTrangPhuc()) {
                            idNgocOption = ItemTemplate.TRANG_BI_OPTION_ID;
                        }
                        if (idNgocOption != -1) {
                            for (Item ngoc : body.ngocs) {
                                if (ngoc != null) {
                                    int index = -1;
                                    for (Option opt : ngoc.options) {
                                        if (opt.id == idNgocOption) {
                                            index = ngoc.options.indexOf(opt);
                                            break;
                                        }
                                    }
                                    if (index != -1) {
                                        if (index + 1 < ngoc.options.size() && (ngoc.options.get(index + 1)).id == id) {
                                            param += (ngoc.options.get(index + 1)).param;
                                        } else if (index + 2 < ngoc.options.size() && (ngoc.options.get(index + 2)).id == id) {
                                            param += (ngoc.options.get(index + 2)).param;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (Item mounts : this.c.get().ItemMounts) {
                if (mounts != null) {
                    for (Option option : mounts.options) {
                        if (option.id == id) {
                            param += option.param;
                        }
                    }
                }
            }
            if(this.caiTrang != -1 && this.isHuman) {
                for (Option option : this.c.ItemCaiTrang[this.caiTrang].options) {
                    if (option.id == id) {
                        param += option.param;
                    }
                }
            }
            return param;
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean checkIdSkill90(float id) {
        for(int i2 = 67; i2 <= 72; ++i2) {
            if(id == i2) {
                return true;
            }
        }
        return false;
    }

    public float getIdSkill90() {
        Skill ski;
        for(int i2 = 67; i2 <= 72; ++i2) {
            ski = this.getSkill(i2);
            if(ski != null) {
                return i2;
            }
        }
        return 71;
    }

    public Skill getSkill90() {
        Skill ski;
        for(int i2 = 67; i2 <= 72; ++i2) {
            ski = this.getSkill(i2);
            if(ski != null) {
                return ski;
            }
        }
        return null;
    }

    public float getPramSkill(float id) {
        try {
            if (this.c.get() == null) {
                return 0;
            }
            float param = 0;
            SkillTemplate data;
            SkillOptionTemplate temp;
            for (Skill sk : this.c.get().skill) {
                data = SkillTemplate.Templates(sk.id);
                if (data.type == 0 || data.type == 2 || sk.id == this.CSkill || data.type == 4 || data.type == 3) {
                    temp = SkillTemplate.Templates(sk.id, sk.point);
                    for (Option op : temp.options) {
                        if (op.id == id) {
                            param += op.param;
                            break;
                        }
                    }
                }
            }
            return param;
        } catch (Exception e) {
            return 0;
        }
    }
//Scr By Truongbk
    public float getPramSkillClone(float id) {
        try {
            if (this.c.clone == null) {
                return 0;
            }
            int param = 0;
            SkillTemplate data;
            SkillOptionTemplate temp;
            for (Skill sk : this.c.clone.skill) {
                data = SkillTemplate.Templates(sk.id);
                if (data.type == 0 || data.type == 2 || sk.id == this.CSkill || data.type == 4 || data.type == 3) {
                    temp = SkillTemplate.Templates(sk.id, sk.point);
                    for (Option op : temp.options) {
                        if (op.id == id) {
                            param += op.param;
                        }
                    }
                }
            }
            return param;
        } catch (Exception e) {
            return 0;
        }
    }

    public Effect getEffId(float effid) {
        try {
            byte i;
            Effect eff;
            for (i = 0; i < this.veff.size(); ++i) {
                eff = this.veff.get(i);
                if (eff != null && eff.template != null && effid == eff.template.id) {
                    return eff;
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    public Effect getEffType(byte efftype) {
        try {
            byte i;
            Effect eff;
            for (i = 0; i < this.veff.size(); ++i) {
                eff = this.veff.get(i);
                if (eff != null && eff.template != null && efftype == eff.template.type) {
                    return eff;
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    public Skill getSkill(float id) {
        for (Skill skl : this.skill) {
            if (skl.id == id) {
                return skl;
            }
        }
        return null;
    }

    public float getCSkill() {
        if (this.nclass == 0) {
            return 0;
        }
        return this.CSkill;
    }

    public List<Skill> getSkills() {
        if (this.nclass == 0 && this.skill.size() == 0) {
            this.skill.add(new Skill(0));
        }
        return this.skill;
    }

    public void setLevel_Exp(long exp, boolean value) {
        long[] levelExp = Level.getLevelExp(exp);
        if (value && this.level < Manager.max_level_up + 1) {
            this.level = (int) levelExp[0];
        }
    }

    public void upDie() {
        synchronized (this) {
            this.hp = 0;
            this.isDie = true;
            try {
                if (!this.c.isNhanban && this.c != null && this.c.tileMap != null) {
                    this.c.tileMap.sendDie(this.c);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public float fullTL() {
        float tl = 0;
        boolean ad = false;
        byte i;
        Item item;
        int tl2;
        short j;
        Option op;
        for (i = 0; i < 10; ++i) {
            tl2 = 0;
            item = this.ItemBody[i];
            if (item == null) {
                return 0;
            }
            for (j = 0; j < item.options.size(); ++j) {
                op = item.options.get(j);
                if (op.id == 85) {
                    tl2 = op.param;
                    break;
                }
                if (j == item.options.size() - 1) {
                    return 0;
                }
            }
            if (!ad) {
                tl = tl2;
                ad = true;
            }
            if (tl > tl2) {
                tl = tl2;
            }
        }
        return tl;
    }

    public byte Sys() {
        return GameSrc.SysClass(this.nclass);
    }

    public byte Side() {
        return GameSrc.SideClass(this.nclass);
    }

    public float percentIce() {
        return this.getPramSkill(69);
    }

    public float timeIce() {
        return this.getPramSkill(70);
    }

    public float percentIce3() {
        return this.getPramSkill(35);
    }

    public float getNgocEff() {
        if (this.ngocEff != -1) {
            return this.ngocEff;
        } else {
            int countPoint = 0;
            Item item;
            int var4;
            for (var4 = 0; var4 < this.ItemBody.length; ++var4) {
                item = this.ItemBody[var4];
                if (item != null && item.ngocs != null) {
                    int i;
                    for (i = 0; i < item.ngocs.size(); ++i) {
                        countPoint += ((Item) item.ngocs.get(i)).getUpgrade();
                    }
                }
            }
            if (countPoint >= MIN_EFF0 && countPoint < MIN_EFF1) {
                this.ngocEff = 0;
                return this.ngocEff;
            } else if (countPoint >= MIN_EFF1 && countPoint < MIN_EFF2) {
                this.ngocEff = 1;
                return 1;
            } else if (countPoint >= MIN_EFF2 && countPoint < MIN_EFF3) {
                this.ngocEff = 2;
                return 2;
            } else if (countPoint >= MIN_EFF3 && countPoint < MIN_EFF4) {
                switch (GameSrc.SysClass(this.nclass)) {
                    case 1: {
                        this.ngocEff = 9;
                        return 9;
                    }
                    case 2: {
                        this.ngocEff = 3;
                        return 3;
                    }
                    case 3: {
                        this.ngocEff = 6;
                        return 6;
                    }
                }
                return -1;
            } else if (countPoint >= MIN_EFF4 && countPoint < MIN_EFF5) {
                switch (GameSrc.SysClass(this.nclass)) {
                    case 1: {
                        this.ngocEff = 4;
                        return 4;
                    }
                    case 2: {
                        this.ngocEff = 7;
                        return 7;
                    }
                    case 3: {
                        this.ngocEff = 10;
                        return 10;
                    }
                }
                return -1;
            } else if (countPoint >= MIN_EFF5 && countPoint < MIN_EFF6) {
                switch (GameSrc.SysClass(this.nclass)) {
                    case 1: {
                        this.ngocEff = 5;
                        return 5;
                    }
                    case 2: {
                        this.ngocEff = 8;
                        return 8;
                    }
                    case 3: {
                        this.ngocEff = 11;
                        return 11;
                    }
                }
                return -1;
            } else if (countPoint >= MIN_EFF6 && countPoint < MIN_EFF7) {
                this.ngocEff = 35;
                return 35;
            } else if (countPoint >= MIN_EFF7 && countPoint < MIN_EFF8) {
                this.ngocEff = 27;
                return 27;
            } else if (countPoint >= MIN_EFF8) {
                this.ngocEff = 25;
                return 25;
            } else {
                return -1;
            }
        }
    }
}
