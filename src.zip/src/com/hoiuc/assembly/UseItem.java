package com.hoiuc.assembly;
//Scr By SHIN

import com.hoiuc.io.Message;
import com.hoiuc.io.Util;
import com.hoiuc.server.GameSrc;
import com.hoiuc.server.Manager;
import com.hoiuc.server.Menu;
import com.hoiuc.server.Service;
import com.hoiuc.stream.BossTuanLoc;
import com.hoiuc.stream.Client;
import com.hoiuc.stream.Server;
import com.hoiuc.template.ItemTemplate;

import java.io.IOException;
import java.time.Instant;
import java.util.Date;

public class UseItem {

    static int[] arrOp = new int[]{6, 7, 10, 67, 68, 69, 70, 71, 72, 73, 74};
    static int[] arrParam = new int[]{50, 50, 10, 5, 10, 10, 5, 5, 5, 100, 50};
    private static byte[] arrOpenBag = new byte[]{0, 6, 6, 12, 24};
    private static Object LOCK = new Object();

    public static short[] HanSuDung = new short[]{1, 2};
    public static short[] HanSuDungNew = new short[]{7, 15};
    public static short[] idItemRuongMayMan = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 7, 7, 7, 7, 8, 8, 8, 9, 9, 242, 242, 242, 280, 284, 284, 285, 436};
    public static short[] idItemRuongTinhXao = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 8, 8, 8, 9, 9, 9, 436, 437, 242, 242, 280, 280, 280, 283, 284, 284, 285, 436, 437, 437};
    public static short[] idItemHopBanhThuong = new short[]{258, 259, 273, 274, 286, 287, 306, 307, 337, 338, 343, 345, 346, 403, 404, 405, 406, 407, 408, 523, 524, 454, 455, 211, 248, 275, 276, 277, 278, 283, 289, 290, 291, 340, 383, 384, 385, 436, 437, 438, 485, 568, 569, 570, 571, 573, 574, 575, 576, 577, 578, 652, 653, 654, 655, 685, 695, 696, 697, 698, 699, 770, 799, 800};
    public static short[] idItemhuyhieunsotruong = new short[]{258, 259, 273, 274, 286, 287, 306, 307, 337, 338, 343, 345, 346, 403, 404, 405, 406, 407, 408, 523, 524, 454, 455, 211, 248, 275, 276, 277, 278, 283, 289, 290, 291, 340, 383, 384, 385, 436, 437, 438, 485, 568, 569, 570, 571, 573, 574, 575, 576, 577, 578, 652, 653, 654, 655, 685, 695, 696, 697, 698, 699, 770, 799, 800, 1265, 1266, 1267, 1268, 1269, 1270};
    public static short[] idItemHopBanhThuongHang = new short[]{258, 259, 273, 274, 286, 287, 306, 307, 337, 338, 343, 345, 346, 403, 404, 405, 406, 407, 408, 523, 524, 454, 455, 211, 248, 275, 276, 277, 278, 283, 289, 290, 291, 340, 383, 384, 385, 436, 437, 438, 485, 568, 569, 570, 571, 573, 574, 575, 576, 577, 578, 652, 653, 654, 655, 685, 695, 696, 697, 698, 699, 770, 799, 800, 806, 807, 808, 809, 813, 814, 815, 816, 817, 823, 825, 826, 828, 524, 834, 895, 897, 926, 1174, 1021, 1022};
    public static short[] idItemrandom1 = new short[]{935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961};
    public static short[] idItemrandom2 = new short[]{397, 398, 399, 400, 401, 402, 694, 427, 583, 584, 585, 586, 587, 588, 589};
    public static short[] idItemDieuGiay = new short[]{8, 9, 289, 289, 340, 340, 383, 409, 410, 436, 436, 436, 436, 436, 437, 437, 443, 485, 524, 549, 550, 551, 569, 577, 742};
    public static short[] idItemDieuVai = new short[]{8, 9, 10, 11, 289, 340, 340, 383, 409, 410, 419, 436, 436, 436, 436, 436, 436, 437, 437, 438, 443, 485, 524, 567, 567, 549, 550, 551, 569, 577, 742, 781};
    public static short[] idItemXetang = new short[]{11, 443, 485, 524, 569, 577, 742, 781, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924, 924};
    public static short[] idItemRuongMaQuai = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 8, 8, 8, 9, 9, 9, 280, 280, 280, 436, 437, 436, 437, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 865, 866, 867, 868, 869, 870, 895};
    public static short[] idItemRuong10x = new short[]{880, 881, 882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894};
    public static short[] idItemRuong12x = new short[]{904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918};
    public static short[] idItemRuong6x = new short[]{1160, 1161, 1162, 1163, 1164, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1173};
    public static short[] idItemRuonghaitac = new short[]{975, 976, 977, 978, 979, 980, 981, 983, 984, 985, 986, 987, 988, 989, 990, 991};
    public static short[] idItemcohaitac = new short[]{965, 966, 967, 968, 969, 970, 971, 972, 973, 993};
    public static short[] idItemAoPhao = new short[]{8, 9, 10, 11, 289, 340, 340, 383, 419, 436, 436, 436, 436, 436, 436, 437, 437, 438, 443, 485, 524, 549, 550, 551, 569, 577, 742, 781, 798, 828};
    public static short[] idItemPhucNangNhanGia = new short[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, -1};
    public static short[] idItemBanhChocolate = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 9, 289, 289, 340, 340, 383, 409, 410, 436, 436, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 437, 443, 485, 524, 549, 550, 551, 549, 550, 551, 569, 574, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 577, 575, 578, 742, 673, 775};
    public static short[] idItemBanhDauTay = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 9, 10, 289, 340, 340, 383, 409, 410, 419, 436, 436, 436, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 436, 437, 437, 438, 443, 485, 524, 567, 567, 549, 550, 551, 549, 5, 5, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 550, 551, 775, 569, 575, 5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 578, 574, 577, 742, 673, 775, 781, 828};
    public static short[] idItemCayThong = new short[]{8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 549, 549, 549, 549, 550, 550, 551, 551, 436, 436, 437};
    public static short[] idItemTuiQuaGiaToc = new short[]{8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 242, 242, 242, 283, 436, 436, 437};
    public static short[] idItemHomBlackFriday = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 9, 289, 289, 340, 340, 383, 409, 410, 436, 436, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 437, 443, 485, 524, 549, 550, 551, 549, 550, 551, 569, 574, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 577, 575, 578, 742, 673, 646, 828};
    public static short[] idItemBanhChung = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 9, 289, 289, 340, 340, 383, 409, 410, 436, 436, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 437, 443, 485, 524, 549, 550, 551, 549, 550, 551, 569, 574, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 577, 575, 578, 742, 673, 646};
    public static short[] idItemBanhTet = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 9, 10, 289, 340, 340, 383, 409, 410, 419, 436, 436, 436, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 436, 437, 437, 438, 443, 485, 524, 567, 567, 549, 550, 551, 549, 5, 5, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 550, 551, 775, 569, 575, 5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 578, 574, 577, 742, 673, 775, 781};
    public static short[] idItemBaoLiXiNho = new short[]{5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 8, 8, 289, 340, 340, 383, 409, 410, 419, 436, 436, 454, 455, 436, 436, 436, 437, 437, 443, 485, 524, 549, 550, 551, 568, 569, 570, 571, 577, 742};
    public static short[] idItemBaoLiXiLon = new short[]{8, 8, 8, 9, 9, 10, 10, 11, 11, 289, 340, 340, 384, 409, 410, 419, 436, 436, 436, 436, 436, 436, 437, 437, 438, 443, 454, 455, 485, 524, 539, 567, 567, 549, 550, 551, 568, 569, 570, 571, 308, 309, 577, 742, 781};
    public static short[] idItemCayMai = new short[]{8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 549, 549, 549, 549, 550, 550, 551, 551, 436, 436, 437};
    public static short[] idItemNVTruyenTin = new short[]{8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 549, 549, 549, 549, 550, 550, 551, 551, 436, 436, 437};
    static short[] idItemTrevang = new short[]{4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 8, 8, 289, 340, 340, 383, 409, 410, 419, 436, 436, 454, 454, 457, 436, 436, 436, 437, 437, 443, 485, 524, 549, 550, 551, 568, 569, 570, 571, 577, 742};
    public static short[] idItemcauca = new short[]{8, 8, 8, 9, 9, 9, 10, 10, 806, 807, 599, 600};
    public static short[] idNgoc = new short[]{865, 866, 867, 868, 869, 870};// id mà bọn member sẽ nhận khi làm sk
    public static short[] idPet = new short[]{781};// con pet boru
    public static short[] svc15x = new short[]{1366, 1367, 1368, 1369, 1370, 1371};
    public static short[] tb12x = new short[]{1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359};
    public static short[] vk10x = new short[]{1360, 1361, 1362, 1363, 1364, 1365};
    public static short[] danhhieuozawa = new short[]{1294, 1295, 1296, 1297, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1377};
    public static short[] kethon = new short[]{1240};// con pet boru
    public static short[] idVuKhi = new short[]{913, 914, 915, 916, 917, 918};// id mà bọn member sẽ nhận khi làm sk

    public static void uesItem(Player p, Item item, byte index) {
        Message m = null;
        try {
            long num2 = Level.getLevel(p.c.level).exps;
            boolean checkExpDown = false;
            if (p.c.expdown > num2 * 30L / 100L) {
                checkExpDown = true;
            }
            if (p.c.isNhanban) {
                num2 = Level.getLevel(p.c.clone.level).exps;
                if (p.c.clone.expdown > num2 * 30L / 100L) {
                    checkExpDown = true;
                }
            }
            if (ItemTemplate.ItemTemplateId(item.id).level > p.c.get().level) {
                p.sendAddchatYellow("Trình độ không đủ để sử dụng vật phẩm này.");
                return;
            }
            ItemTemplate data = ItemTemplate.ItemTemplateId(item.id);

            if (data.gender != 2 && data.gender != p.c.gender) {
                return;
            }
            if (data.type == 26) {
                p.sendAddchatYellow("Vật phẩm liên quan đến nâng cấp, hãy gặp Kenshinto trong làng để sử dụng.");
                return;
            }

            if (data.level > p.c.get().level || (p.c.isNhanban && data.level > p.c.clone.level)) {
                p.sendAddchatYellow("Trình độ không đủ để sử dụng vật phẩm này.");
                return;
            }

            if ((p.c.get().nclass == 0 && item.id == 547) || (data.nclass > 0 && data.nclass != p.c.get().nclass)) {
                p.sendAddchatYellow("Môn phái không phù hợp.");
                return;
            }
            if ((item.id == 420 && GameSrc.SysClass(p.c.get().nclass) != 1) || (item.id == 421 && GameSrc.SysClass(p.c.get().nclass) != 2) || (item.id == 422 && GameSrc.SysClass(p.c.get().nclass) != 3)) {
                p.sendAddchatYellow("Thuộc tính của Yoroi không phù hợp để sử dụng.");
                return;
            }
            if (p.c.isNhanban && item.id == 547) {
                p.sendAddchatYellow("Chức năng này không thể sử dụng cho phân thân.");
                return;
            }
            if (ItemTemplate.isTypeBody(item.id)) {
                item.isLock = true;
                Item itemb = null;
                if (ItemTemplate.isIdNewCaiTrang(item.id) || ItemTemplate.checkIdNewWP(item.id) != -1 || ItemTemplate.checkIdNewMatNa(item.id) != -1 || ItemTemplate.checkIdNewBienHinh(item.id) != -1) {
                    itemb = p.c.get().ItemBody[data.type + 16];
                    p.c.get().ItemBody[data.type + 16] = item;
                } else {
                    itemb = p.c.get().ItemBody[data.type];
                    p.c.get().ItemBody[data.type] = item;
                }
                p.c.ItemBag[index] = itemb;

                if (data.type == 10) {
                    p.mobMeMessage(0, (byte) 0);
                }
                if (itemb != null && (itemb.id == 569 || itemb.id == 583)) {
                    p.removeEffect(36);
                }
                switch (item.id) {
                    case 246: {
                        p.mobMeMessage(70, (byte) 0);
                        break;
                    }
                    case 419: {
                        p.mobMeMessage(122, (byte) 0);
                        break;
                    }
                    case 568: {
                        p.setEffect(38, 0, (int) (item.expires - System.currentTimeMillis()), 0);
                        p.mobMeMessage(205, (byte) 0);
                        break;
                    }
                    case 569: {
                        p.setEffect(36, 0, (int) (item.expires - System.currentTimeMillis()), (int) p.c.get().getPramItem(99));
                        p.mobMeMessage(206, (byte) 0);
                        break;
                    }
                    case 570: {
                        p.setEffect(37, 0, (int) (item.expires - System.currentTimeMillis()), 0);
                        p.mobMeMessage(207, (byte) 0);
                        break;
                    }
                    case 571: {
                        p.setEffect(39, 0, (int) (item.expires - System.currentTimeMillis()), 0);
                        p.mobMeMessage(208, (byte) 0);
                        break;
                    }
                    case 583: {
                        p.setEffect(36, 0, (int) (item.expires - System.currentTimeMillis()), (int) p.c.get().getPramItem(99));
                        p.mobMeMessage(211, (byte) 1);
                        break;
                    }
                    case 584: {
                        p.mobMeMessage(212, (byte) 1);
                        break;
                    }
                    case 585: {
                        p.mobMeMessage(213, (byte) 1);
                        break;
                    }
                    case 586: {
                        p.mobMeMessage(214, (byte) 1);
                        break;
                    }
                    case 587: {
                        p.mobMeMessage(215, (byte) 1);
                        break;
                    }
                    case 588: {
                        p.mobMeMessage(216, (byte) 1);
                        break;
                    }
                    case 589: {
                        p.mobMeMessage(217, (byte) 1);
                        break;
                    }
                    case 742: {
                        p.mobMeMessage(229, (byte) 1);
                        break;
                    }
                    case 781: {
                        p.mobMeMessage(235, (byte) 1);
                        break;
                    }
                    case 896: {
                        p.mobMeMessage(210, (byte) 1);
                        break;
                    }
                    case 898: {
                        p.mobMeMessage(163, (byte) 1);
                        break;
                    }
                    case 899: {
                        p.mobMeMessage(223, (byte) 1);
                        break;
                    }
                    case 900: {
                        p.mobMeMessage(201, (byte) 1);
                        break;
                    }
                    case 998: {
                        p.mobMeMessage(233, (byte) 0);
                        break;
                    }
                    case 1220: {
                        p.mobMeMessage(239, (byte) 1);
                        break;
                    }
                    case 1221: {
                        p.mobMeMessage(240, (byte) 1);
                        break;
                    }
                    case 1222: {
                        p.mobMeMessage(241, (byte) 1);
                        break;
                    }
                    case 1223: {
                        p.mobMeMessage(242, (byte) 1);
                        break;
                    }
                    case 1224: {
                        p.mobMeMessage(243, (byte) 1);
                        break;
                    }
                    case 1225: {
                        p.mobMeMessage(244, (byte) 1);
                        break;
                    }
                    case 1226: {
                        p.mobMeMessage(245, (byte) 1);
                        break;
                    }
                    case 1227: {
                        p.mobMeMessage(246, (byte) 1);
                        break;
                    }
                    case 1228: {
                        p.mobMeMessage(247, (byte) 1);
                        break;
                    }
                    case 1229: {
                        p.mobMeMessage(248, (byte) 1);
                        break;
                    }
                    case 1230: {
                        p.mobMeMessage(249, (byte) 1);
                        break;
                    }
                    case 1231: {
                        p.mobMeMessage(250, (byte) 1);
                        break;
                    }
                    case 1232: {
                        p.mobMeMessage(251, (byte) 1);
                        break;
                    }
                    case 1233: {
                        p.mobMeMessage(252, (byte) 1);
                        break;
                    }
                    case 1234: {
                        p.mobMeMessage(253, (byte) 1);
                        break;
                    }
                    case 1235: {
                        p.mobMeMessage(254, (byte) 1);
                        break;
                    }
                    case 1026: {// ? có cái đéo item nào id 1026 đâu, thằng ngáo
                        p.mobMeMessage(161, (byte) 1);
                        break;
                    }
                }
                m = new Message(11);
                m.writer().writeByte(index);
                m.writer().writeByte((int) p.c.get().speed());
                m.writer().writeInt((int) p.c.get().getMaxHP());
                m.writer().writeInt((int) p.c.get().getMaxMP());
                m.writer().writeShort((int) p.c.get().eff5buffHP());
                m.writer().writeShort((int) p.c.get().eff5buffMP());
                m.writer().flush();
                p.conn.sendMessage(m);
                m.cleanup();
                if ((item.id >= 795 && item.id <= 805) || (item.id >= 1244 && item.id <= 1245) || (item.id >= 813 && item.id <= 817) || (item.id >= 813 && item.id <= 1317) || (item.id >= 825 && item.id <= 827) || (item.id >= 830 && item.id <= 832)) {
                    final Message m1 = new Message(57);
                    m1.writer().flush();
                    p.conn.sendMessage(m);
                    m1.cleanup();
                    if (!p.c.isTrade) {
                        Service.CharViewInfo(p, false);
                    }
                }
            } else if (ItemTemplate.isTypeMounts(item.id)) {
                byte idM = (byte) (data.type - 29);
                Item itemM = p.c.get().ItemMounts[idM];
                if (idM == 4) {
                    if (p.c.get().ItemMounts[0] != null || p.c.get().ItemMounts[1] != null || p.c.get().ItemMounts[2] != null || p.c.get().ItemMounts[3] != null) {
                        p.conn.sendMessageLog("Bạn cần phải tháo trang bị thú cưỡi đang sử dụng.");
                        return;
                    }
                    if (!item.isLock) {
                        byte i;
                        int op;
                        Option option2;
                        for (i = 0; i < 4; ++i) {
                            op = -1;
                            do {
                                op = (int) Util.nextInt(UseItem.arrOp.length);
                                for (Option option : item.options) {
                                    if (UseItem.arrOp[op] == option.id) {
                                        op = -1;
                                        break;
                                    }
                                }
                            } while (op == -1);
                            if (op == -1) {
                                return;
                            }
                            int par = UseItem.arrParam[op];
                            if (item.isExpires) {
                                par *= 10;
                            }
                            option2 = new Option(UseItem.arrOp[op], par);
                            item.options.add(option2);
                        }
                    }
                    if (p.c.clone != null && p.c.isNhanban) {
                        if (item.id == 801) {

                            p.c.clone.ID_HORSE = 47;
                        }
                        if (item.id == 802) {
                            p.c.clone.ID_HORSE = 48;
                        }
                        if (item.id == 803) {
                            p.c.clone.ID_HORSE = 49;
                        }
                        if (item.id == 798) {
                            p.c.clone.ID_HORSE = 36;
                        }
                        if (item.id == 828) {
                            p.c.clone.ID_HORSE = 63;
                        }
                        Service.CharViewInfo(p, false);
                    }
                } else if (p.c.get().ItemMounts[4] == null) {
                    p.conn.sendMessageLog("Bạn cần phải tháo trang bị thú cưỡi đang sử dụng.");
                    return;
                }
                item.isLock = true;
                p.c.ItemBag[index] = itemM;
                p.c.get().ItemMounts[idM] = item;

                m = new Message(11);
                m.writer().writeByte(index);
                m.writer().writeByte((int) p.c.get().speed());
                m.writer().writeInt((int) p.c.get().getMaxHP());
                m.writer().writeInt((int) p.c.get().getMaxMP());
                m.writer().writeShort((int) p.c.get().eff5buffHP());
                m.writer().writeShort((int) p.c.get().eff5buffMP());
                m.writer().flush();
                p.conn.sendMessage(m);
                m.cleanup();

                if (ItemTemplate.isTypeMounts(item.id)) {
                    Player player;
                    for (int i = p.c.tileMap.players.size() - 1; i >= 0; i--) {
                        player = p.c.tileMap.players.get(i);
                        if (player != null && player.c != null) {
                            p.c.tileMap.sendMounts(p.c.get(), player);
                        }
                    }
                }
            } else if (data.skill > 0) {
                byte skill = data.skill;
                if (item.id == 547) {
                    skill += p.c.get().nclass;
                }
                p.openBookSkill(index, skill);
                return;
            } else {
                byte numbagnull = p.c.getBagNull();
                switch (item.id) {
                    case 13: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffHP(25)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 14: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffHP(90)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 15: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffHP(230)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 16: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffHP(400)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 17: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffHP(650)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 565: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffHP(1500)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 18: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffMP(150)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 19: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffMP(500)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 20: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffMP(1000)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 21: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffMP(2000)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 22: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffMP(3500)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 566: {
                        if (p.c.pk > 10 || checkExpDown) {
                            p.sendAddchatYellow(Language.MAX_EXP_DOWN);
                            return;
                        }
                        if (p.buffMP(5000)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    /*case 23: {
                        if (p.dungThucan((byte) 0, 3, 1800)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 24: {
                        if (p.dungThucan((byte) 1, 20, 1800)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 25: {
                        if (p.dungThucan((byte) 2, 30, 1800)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 26: {
                        if (p.dungThucan((byte) 3, 40, 1800)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 27: {
                        if (p.dungThucan((byte) 4, 50, 1800)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 29: {
                        if (p.dungThucan((byte) 28, 60, 1800)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 30: {
                        if (p.dungThucan((byte) 28, 60, 259200)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 249: {
                        if (p.dungThucan((byte) 3, 40, 259200)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 250: {
                        if (p.dungThucan((byte) 4, 50, 259200)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 409: {
                        if (p.dungThucan((byte) 30, 75, 86400)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 410: {
                        if (p.dungThucan((byte) 31, 90, 86400)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    case 567: {
                        if (p.dungThucan((byte) 35, 120, 86400)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }*/
                    //Nhân sâm
                    case 28: {
//                        if (p.c.isNhanban) {
//                            p.conn.sendMessageLog(Language.NOT_FOR_PHAN_THAN);
//                            return;
//                        }
                        long expup = (Level.getMaxExp(p.c.get().level + 1) - Level.getMaxExp(p.c.get().level)) / 10;
                        p.updateExp(expup);
                        p.sendAddchatYellow("Bạn nhận được " + expup + " kinh nghiệm.");
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    // thỏi vàng
                    case 247: {
                        if (p.c.xu == 2000000000) {
                            p.conn.sendMessageLog("Đã đạt giới hạn xu");
                            return;
                        }
                        if (p.luong == 2000000000) {
                            p.conn.sendMessageLog("Đã đạt giới hạn lượng");
                            return;
                        }
                        p.c.upxuMessage(1000000000);
                        p.upluongMessage(500000000);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 1439: {
                        if (p.c.atm == 2000000000) {
                            p.conn.sendMessageLog("Đã đạt giới hạn atm");
                            return;
                        }
                        p.c.upatmMessage(100000);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //Tre Vang
                    case 593: {
                        if (Server.manager.event != 5) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        long perRuong = Util.nextInt(200);
                        p.updateExp(1000000L);
                        if (Util.nextInt(10) < 3) {
                            p.updateExp(1500000L);
                        } else if (perRuong == 50) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(385, false));
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(385).name);
                        } else if (perRuong <= 1) {
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(384).name);
                            p.c.addItemBag(true, ItemTemplate.itemDefault(384, false));
                        } else {
                            short idI = UseItem.idItemTrevang[(int) Util.nextInt(UseItem.idItemTrevang.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                            if (itemup.id == 685 || itemup.id == 686) {
                                ItemTemplate itemD = ItemTemplate.ItemTemplateId(itemup.id);
                                Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + itemD.name);
                            }
                        }
                        break;
                    }
                    case 34:
                    case 36: {
                        Map map = Manager.getMapid(p.c.mapLTD);
                        if (map != null) {
                            byte i;
                            for (i = 0; i < map.area.length; ++i) {
                                if (map.area[i].numplayers < map.template.maxplayers) {
                                    p.c.tileMap.leave(p);
                                    map.area[i].EnterMap0(p.c);
                                    if (item.id == 34) {
                                        p.c.removeItemBag(index, 1);
                                    }
                                    return;
                                }
                            }
                            break;
                        }
                        break;
                    }
                    //Kẹo Ngọt
                    case 458: {
                        if (p.c.isHuman) {
                            p.conn.sendMessageLog(Language.NOT_FOR_CHU_THAN);
                            return;
                        }
                        p.updateExp(Level.getMaxExp(200));
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //Tràng pháo
                    case 592: {

                        if (Server.manager.event != 5) {
                            p.sendAddchatYellow("Sự kiện này đã kết thúc không còn sử dụng được vật phẩm này nữa");
                            return;
                        }
                        if (p.c.getBagNull() == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            return;
                        } else {

                            p.updateExp(20000000);
                            short[] arId = new short[]{12, 12, 12, 8, 9, 8, 9, 275, 276, 277, 278, 289, 290, 291, 289, 290, 291, 289, 290, 291, 535, 535, 536, 536, 535, 536, 275, 276, 277, 278, 548, 12, 548, 381, 382, 381, 382, 381, 682, 682, 682, 283, 436, 438, 437, 436, 437, 419, 403, 419, 403, 407, 407, 12, 254, 255, 256, 12, 254, 255, 256, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 733, 734, 735, 736, 737, 738, 739, 674, 740, 741, 760, 761, 762, 674, 763, 764, 765, 766, 767, 768, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 733, 734, 735, 736, 737, 738, 739, 740, 741, 760, 761, 762, 763, 764, 765, 766, 767, 768, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 733, 734, 735, 736, 737, 738, 739, 740, 741, 760, 761, 762, 763, 764, 765, 766, 767, 768, 7, 8, 9, 436, 437, 438, 682, 384, 385, 383, 381, 258, 259, 273, 274,
                                286,
                                287,
                                306,
                                307,
                                337,
                                338,
                                343,
                                344,
                                345,
                                346,
                                403,
                                404,
                                405,
                                406, 251, 308, 309, 548, 275, 276, 277, 278, 539, 540};
                            short idI = arId[(int) Util.nextInt(arId.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = false;
                            p.c.removeItemBag(index, 1);
                            p.c.addItemBag(true, itemup);
                            Service.sendEffectAuto(p, (byte) 9, (int) p.c.x, (int) p.c.y, (byte) 1, (short) 1);

                        }
                        break;
                    }
                    //phúc nang nhẫn giả
                    case 38: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        int per = (int) Util.nextInt(UseItem.idItemPhucNangNhanGia.length);
                        p.c.removeItemBag(index, 1);
                        if (UseItem.idItemPhucNangNhanGia[per] == -1) {
                            long yenran = Util.nextInt(100000, 150000);
                            p.c.upyenMessage(yenran);
                            p.sendAddchatYellow("Bạn nhận được " + yenran + " yên.");
                        } else {
                            p.c.addItemBag(UseItem.idItemPhucNangNhanGia[per] == 28 ? true : false, ItemTemplate.itemDefault(UseItem.idItemPhucNangNhanGia[per]));
                        }
                        break;
                    }
                    //ai phôn
                    case 339: {
                        Server.manager.sendTB(p, "Thông Tin", "Tên: " + p.username + ""
                                + "\n Cấp Độ : " + p.c.level + ""
                                + "\n Hành trang : " + p.c.maxluggage + " ô."
                                + "\n Xp KM : " + p.c.expkm + "."
                                + "\n VNĐ : " + p.c.vnd + "."
                                + "\n ATM : " + p.c.atm + "."
                                + "\n--------------------"
                                + "\n TN Chưa Cộng :" + Util.getFormatNumber(p.c.ppoint2) + ""
                                + "\n Sức mạnh :" + Util.getFormatNumber(p.c.potential0) + ""
                                + "\n Thân Pháp : " + Util.getFormatNumber(p.c.potential1) + ""
                                + "\n Thể Lực :" + Util.getFormatNumber(p.c.potential2) + ""
                                + "\n Chakra :" + Util.getFormatNumber(p.c.potential3) + ""
                                + "\n--------------------"
                                + "\n Dame : " + Util.getFormatNumber((double) (float) p.c.dameMin()) + "-" + Util.getFormatNumber((double) (float) p.c.dameMax()) + "."
                                + "\n Hp :" + Util.getFormatNumber((double) (float) p.c.hp) + "."
                                + "\n Mp : " + Util.getFormatNumber((double) (float) p.c.mp) + "."
                                + "\n Né : " + Util.getFormatNumber((double) (float) p.c.Miss()) + ""
                                + "\n Chính Xác :" + Util.getFormatNumber((double) p.c.Exactly()) + ""
                                + "\n Chí Mạng : " + Util.getFormatNumber((double) p.c.Fatal()) + ".");

                        break;
                    }
                    case 1374: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 100) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        short idI = UseItem.vk10x[Util.nextInt(UseItem.vk10x.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup = ItemTemplate.itemDefault(idI);
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);
                                itemup.sys = GameSrc.SysClass(data2.nclass);
                            } else {
                                itemup.sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault((int) idI, itemup.sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        p.c.addItemBag(false, itemup);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 1375: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 100) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        short idI = UseItem.danhhieuozawa[Util.nextInt(UseItem.danhhieuozawa.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup = ItemTemplate.itemDefault(idI);
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);
                                itemup.sys = GameSrc.SysClass(data2.nclass);
                            } else {
                                itemup.sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault((int) idI, itemup.sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        p.c.addItemBag(false, itemup);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 1373: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 120) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        short idI = UseItem.tb12x[Util.nextInt(UseItem.tb12x.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup = ItemTemplate.itemDefault(idI);
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);
                                itemup.sys = GameSrc.SysClass(data2.nclass);
                            } else {
                                itemup.sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault((int) idI, itemup.sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        p.c.addItemBag(false, itemup);
                        p.c.removeItemBag(index, 1);
                        break;
                    }

                    case 1372: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 120) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        short idI = UseItem.svc15x[Util.nextInt(UseItem.svc15x.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup = ItemTemplate.itemDefault(idI);
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);
                                itemup.sys = GameSrc.SysClass(data2.nclass);
                            } else {
                                itemup.sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault((int) idI, itemup.sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        p.c.addItemBag(false, itemup);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 1237: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            return;
                        }
                        long sk1 = Util.nextInt(10);
                        if (sk1 == 1) {
                            short[] arId = new short[]{618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637}; // iditem
                            short idI = arId[(int) Util.nextInt(arId.length)];
                            item = ItemTemplate.itemDefault(idI);
                            byte cs2 = (byte) Util.nextInt(1, 16);
                            item.upgrade = 16;
                            item.options.clear();
                            short cs = (short) Util.nextInt(10000000, 50000000);
                            short cs1 = (short) Util.nextInt(50000, 900000);
                            short cs3 = (short) Util.nextInt(1000, 20000);

                            item.options.add(new Option(82, 150000000));
                            item.options.add(new Option(83, 150000000));
                            item.options.add(new Option(87, 150000000));
                            item.options.add(new Option(92, 150000000));
                            item.options.add(new Option(58, 3500000));
                            item.options.add(new Option(94, 3500000));
                            item.options.add(new Option(80, 2000000));
                            item.options.add(new Option(81, 2000000));

                            item.isLock = true;
                            p.c.addItemBag(true, item);
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(5);
                        } else {
                            p.conn.sendMessageLog("Xịt rồi. Tỉ lệ 30% ra đồ VIP. Tặng mày 2 lượng");
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(2);
                        }
                    }
                    break;

                    case 1263: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            return;
                        }
                        long sk1 = Util.nextInt(10);
                        if (sk1 == 1) {
                            short[] arId = new short[]{618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637}; // iditem
                            short idI = arId[(int) Util.nextInt(arId.length)];
                            item = ItemTemplate.itemDefault(idI);
                            byte cs2 = (byte) Util.nextInt(1, 16);
                            item.upgrade = 17;
                            item.options.clear();
                            short cs = (short) Util.nextInt(10000000, 50000000);
                            short cs1 = (short) Util.nextInt(50000, 900000);
                            short cs3 = (short) Util.nextInt(1000, 20000);

                            item.options.add(new Option(82, 150000000));
                            item.options.add(new Option(83, 150000000));
                            item.options.add(new Option(87, 150000000));
                            item.options.add(new Option(92, 150000000));
                            item.options.add(new Option(58, 5000000));
                            item.options.add(new Option(94, 5000000));
                            item.options.add(new Option(80, 2000000));
                            item.options.add(new Option(81, 2000000));

                            item.isLock = true;
                            p.c.addItemBag(true, item);
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(5);
                        } else {
                            p.conn.sendMessageLog("Xịt rồi. Tỉ lệ 30% ra đồ VIP. Tặng mày 2 lượng");
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(2);
                        }
                    }
                    break;
                    case 1264: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            return;
                        }
                        long sk1 = Util.nextInt(10);
                        if (sk1 == 1) {
                            short[] arId = new short[]{618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637}; // iditem
                            short idI = arId[(int) Util.nextInt(arId.length)];
                            item = ItemTemplate.itemDefault(idI);
                            byte cs2 = (byte) Util.nextInt(1, 16);
                            item.upgrade = 17;
                            item.options.clear();
                            short cs = (short) Util.nextInt(10000000, 50000000);
                            short cs1 = (short) Util.nextInt(50000, 900000);
                            short cs3 = (short) Util.nextInt(1000, 20000);

                            item.options.add(new Option(82, 250000000));
                            item.options.add(new Option(83, 250000000));
                            item.options.add(new Option(87, 250000000));
                            item.options.add(new Option(92, 250000000));
                            item.options.add(new Option(58, 7000000));
                            item.options.add(new Option(94, 7000000));
                            item.options.add(new Option(80, 2000000));
                            item.options.add(new Option(81, 2000000));

                            item.isLock = true;
                            p.c.addItemBag(true, item);
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(5);
                        } else {
                            p.conn.sendMessageLog("Xịt rồi. Tỉ lệ 30% ra đồ VIP. Tặng mày 2 lượng");
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(2);
                        }
                    }
                    break;
                    case 1282: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            return;
                        }
                        long sk1 = Util.nextInt(10);
                        if (sk1 == 1) {
                            short[] arId = new short[]{618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 1207, 1208, 1209, 1210, 1211, 1175, 1176, 1177, 1178, 1179, 1139, 1140, 1141, 1142, 1128, 1129, 1130, 1131, 1285, 1286, 1287}; // iditem
                            short idI = arId[(int) Util.nextInt(arId.length)];
                            item = ItemTemplate.itemDefault(idI);
                            byte cs2 = (byte) Util.nextInt(1, 16);
                            item.upgrade = 17;
                            item.options.clear();
                            short cs = (short) Util.nextInt(10000000, 50000000);
                            short cs1 = (short) Util.nextInt(50000, 900000);
                            short cs3 = (short) Util.nextInt(1000, 20000);

                            item.options.add(new Option(82, 550000000));
                            item.options.add(new Option(83, 550000000));
                            item.options.add(new Option(87, 550000000));
                            item.options.add(new Option(92, 550000000));
                            item.options.add(new Option(58, 10000000));
                            item.options.add(new Option(94, 10000000));
                            item.options.add(new Option(80, 50000000));
                            item.options.add(new Option(81, 50000000));
                            item.options.add(new Option(0, 999999999));
                            item.options.add(new Option(1, 999999999));
                            item.options.add(new Option(5, 999999999));
                            item.options.add(new Option(14, 999999999));
                            item.options.add(new Option(15, 999999999));
                            item.options.add(new Option(30, 999999999));
                            item.options.add(new Option(37, 999999999));
                            item.options.add(new Option(38, 999999999));
                            item.options.add(new Option(39, 9999999));
                            item.options.add(new Option(46, 999999999));
                            item.options.add(new Option(79, 999999999));
                            item.options.add(new Option(91, 999999999));

                            item.isLock = true;
                            p.c.addItemBag(true, item);
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(5);
                        } else {
                            p.conn.sendMessageLog("Xịt rồi. Tỉ lệ 30% ra đồ VIP. Tặng mày 2 lượng");
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(2);
                        }
                    }
                    break;
                    case 1288: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            return;
                        }
                        long sk1 = Util.nextInt(10);
                        if (sk1 == 1) {
                            short[] arId = new short[]{568, 569, 570, 571, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 835, 1207, 1208, 1209, 1210, 1211, 1175, 1176, 1177, 1178, 1179, 1139, 1140, 1141, 1142, 1128, 1129, 1130, 1131, 1285, 1286, 1287, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1240, 1202, 1203, 1204, 1205, 1206, 1188, 1187, 1177, 1175, 904, 905, 906, 907, 908, 909, 910, 912, 913, 914, 915, 916, 917, 918, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 798, 799, 800, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408}; // iditem
                            short idI = arId[(int) Util.nextInt(arId.length)];
                            item = ItemTemplate.itemDefault(idI);
                            byte cs2 = (byte) Util.nextInt(1, 16);
                            item.upgrade = 17;
                            item.options.clear();
                            short cs = (short) Util.nextInt(10000000, 50000000);
                            short cs1 = (short) Util.nextInt(50000, 900000);
                            short cs3 = (short) Util.nextInt(1000, 20000);

                            item.options.add(new Option(82, 2000000000));
                            item.options.add(new Option(83, 2000000000));
                            item.options.add(new Option(87, 2000000000));
                            item.options.add(new Option(92, 200000000));
                            item.options.add(new Option(58, 30000000));
                            item.options.add(new Option(94, 30000000));
                            item.options.add(new Option(80, 2000000000));
                            item.options.add(new Option(81, 2000000000));
                            item.options.add(new Option(0, 2000000000));
                            item.options.add(new Option(1, 2000000000));
                            item.options.add(new Option(5, 2000000000));
                            item.options.add(new Option(14, 2000000000));
                            item.options.add(new Option(15, 2000000000));
                            item.options.add(new Option(30, 2000000000));
                            item.options.add(new Option(37, 2000000000));
                            item.options.add(new Option(38, 2000000000));
                            item.options.add(new Option(39, 2000000000));
                            item.options.add(new Option(46, 2000000000));
                            item.options.add(new Option(79, 2000000000));
                            item.options.add(new Option(91, 2000000000));

                            item.isLock = true;
                            p.c.addItemBag(true, item);
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(5);
                        } else {
                            p.conn.sendMessageLog("Xịt rồi. Tỉ lệ 30% ra đồ VIP. Tặng mày 2 lượng");
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(2);
                        }
                    }
                    break;
                    case 1256: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            return;
                        }
                        long sk1 = Util.nextInt(10);
                        if (sk1 == 3) {
                            short[] arId = new short[]{618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637}; // iditem
                            short idI = arId[(int) Util.nextInt(arId.length)];
                            item = ItemTemplate.itemDefault(idI);
                            byte cs2 = (byte) Util.nextInt(1, 16);
                            item.upgrade = 14;
                            item.options.clear();
                            short cs = (short) Util.nextInt(100000, 1000000);
                            short cs1 = (short) Util.nextInt(10000, 20000);
                            short cs3 = (short) Util.nextInt(1000, 20000);

                            item.options.add(new Option(82, cs));
                            item.options.add(new Option(83, cs));
                            item.options.add(new Option(87, cs));
                            item.options.add(new Option(92, 150000));
                            item.options.add(new Option(58, 2000000));
                            item.options.add(new Option(94, 2000000));
                            item.options.add(new Option(80, 30000000));
                            item.options.add(new Option(81, 30000000));

                            item.isLock = item.isLock;
                            p.c.addItemBag(true, item);
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(5);
                        } else {
                            p.conn.sendMessageLog("Xịt rồi. Tỉ lệ 30% ra đồ thường. Tặng mày 2 lượng");
                            p.c.removeItemBag(index, 1);
                            p.upluongMessage(2);
                        }
                    }
                    break;
                    //thuốc kim cương
                    case 770: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        int Tn = (int) Util.nextInt(100, 200);
                        p.c.removeItemBag(index, 1);
                        p.c.ppoint2 += Tn;       
                        break;
                    }
                    case 1435: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        int Tn = 100000000;
                        p.c.removeItemBag(index, 1);
                        p.c.ppoint2 += Tn;   
                         p.sendAddchatYellow("Bạn nhận được " + Tn + " điểm tiềm năng vào tiềm năng chưa cộng,Mua ai phôn trong gosho để xem điểm!!");
                        break;
                    }
                    //cá
                    case 1021: {

                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        int Tn = (int) Util.nextInt(1000000, 5000000);
                        p.c.removeItemBag(index, 1);
                        p.c.ppoint2 += Tn;
                        p.coin += 1000000;
                        p.c.vnd += 300000;
                        p.c.atm += 10000;

                        p.sendAddchatYellow("Bạn nhận được " + Tn + " điểm tiềm năng 1 TRIỆU COIN + 300K VND + 10.000 ATM !!!!");
                        break;
                    }
                    case 1022: {

                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        int Tn = (int) Util.nextInt(1000000, 5000000);
                        p.c.removeItemBag(index, 1);
                        p.c.ppoint2 += Tn;
                        p.coin += 1000000;
                        p.c.vnd += 300000;
                        p.c.atm += 10000;

                        p.sendAddchatYellow("Bạn nhận được " + Tn + " điểm tiềm năng 1 TRIỆU COIN + 300K VND + 10.000 ATM !!!!");
                        break;
                    }
                    //bông thảo dược
                    case 211: {

                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        int Tn = (int) Util.nextInt(1, 3);
                        p.c.removeItemBag(index, 1);
                        p.c.ppoint2 += Tn;

                        p.sendAddchatYellow("Bạn nhận được " + Tn + " điểm tiềm Năng.");
                        break;
                    }
                    //Hiếu chiến
                    case 257: {
                        if (p.c.get().pk > 0) {
                            p.c.get().pk -= 5;
                            if (p.c.get().pk < 0) {
                                p.c.get().pk = 0;
                            }
                            p.sendAddchatYellow("Điểm hiếu chiến của bạn còn lại là " + p.c.get().pk);
                            p.c.removeItemBag(index, 1);
                            break;
                        }
                        p.sendAddchatYellow("Bạn không có điểm hiếu chiến.");
                        break;
                    }
                    //Ngọc rồng
                    case 222:
                    case 223:
                    case 224:
                    case 225:
                    case 226:
                    case 227:
                    case 228: {
                        if (p.c.nclass == 0) {
                            p.conn.sendMessageLog("Bạn cần nhập học để sử dụng vật phẩm này.");
                            return;
                        }
                        if (p.c.quantityItemyTotal(222) < 1 || p.c.quantityItemyTotal(223) < 1 || p.c.quantityItemyTotal(224) < 1 || p.c.quantityItemyTotal(225) < 1 || p.c.quantityItemyTotal(226) < 1 || p.c.quantityItemyTotal(227) < 1 || p.c.quantityItemyTotal(228) < 1) {
                            p.conn.sendMessageLog("Bạn không có đủ 7 viên ngọc rồng 1-7 sao để gọi rồng.");
                            return;
                        }
                        if (p.c.getBagNull() < 1) {
                            p.sendAddchatYellow(Language.NOT_ENOUGH_BAG);
                            return;
                        }
                        synchronized (LOCK) {
                            try {
                                m = new Message(-30);
                                m.writer().writeByte(-58);
                                m.writer().writeInt(p.c.get().id);
                                m.writer().flush();
                                p.conn.sendMessage(m);
                                m.cleanup();

                                m = new Message(-30);
                                m.writer().writeByte(-57);
                                m.writer().flush();
                                p.c.tileMap.sendMessage(m);
                                m.cleanup();

                                LOCK.wait(400L);
                                p.c.get().isGoiRong = true;
                                LOCK.wait(400L);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        int i;
                        byte count = 0;
                        for (i = 222; i <= 228; i++) {
                            if (p.c.getIndexBagid(i, false) != -1) {
                                p.c.removeItemBag(p.c.getIndexBagid(i, false), 1);
                                count++;
                            } else {
                                p.c.removeItemBag(p.c.getIndexBagid(i, true), 1);
                            }
                        }
                        byte nClassC = p.c.get().nclass;
                        if (p.c.isNhanban) {
                            nClassC = p.c.clone.nclass;
                        }
                        p.c.addItemBag(false, ItemTemplate.itemDefault(419 + GameSrc.SysClass(nClassC), count == 7 ? false : true));
                        break;
                    }
                    //ngocrongxanh
                    case 1149:
                    case 1150:
                    case 1151:
                    case 1152:
                    case 1153:
                    case 1154:
                    case 1155: {
                        if (p.c.nclass == 0) {
                            p.conn.sendMessageLog("Bạn cần nhập học để sử dụng vật phẩm này.");
                            return;
                        }
                        if (p.c.quantityItemyTotal(1149) < 1 || p.c.quantityItemyTotal(1150) < 1 || p.c.quantityItemyTotal(1151) < 1 || p.c.quantityItemyTotal(1152) < 1 || p.c.quantityItemyTotal(1153) < 1 || p.c.quantityItemyTotal(1154) < 1 || p.c.quantityItemyTotal(1155) < 1) {
                            p.conn.sendMessageLog("Bạn không có đủ 7 viên ngọc rồng Xanh 1-7 sao để gọi rồng.");
                            return;
                        }
                        if (p.c.getBagNull() < 1) {
                            p.sendAddchatYellow(Language.NOT_ENOUGH_BAG);
                            return;
                        }
                        synchronized (LOCK) {
                            try {
                                m = new Message(-30);
                                m.writer().writeByte(-58);
                                m.writer().writeInt(p.c.get().id);
                                m.writer().flush();
                                p.conn.sendMessage(m);
                                m.cleanup();

                                m = new Message(-30);
                                m.writer().writeByte(-57);
                                m.writer().flush();
                                p.c.tileMap.sendMessage(m);
                                m.cleanup();

                                LOCK.wait(400L);
                                p.c.get().isGoiRong = true;
                                LOCK.wait(400L);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        int i;
                        byte count = 0;
                        for (i = 1149; i <= 1155; i++) {
                            if (p.c.getIndexBagid(i, false) != -1) {
                                p.c.removeItemBag(p.c.getIndexBagid(i, false), 1);
                                count++;
                            } else {
                                p.c.removeItemBag(p.c.getIndexBagid(i, true), 1);
                            }
                        }
                        byte nClassC = p.c.get().nclass;
                        if (p.c.isNhanban) {
                            nClassC = p.c.clone.nclass;
                        }
                        p.c.addItemBag(false, ItemTemplate.itemDefault(419 + 689 + GameSrc.SysClass(nClassC), count == 7 ? false : true));
                        break;
                    }
                    //ngocrongden
                    case 1073:
                    case 1074:
                    case 1075:
                    case 1076:
                    case 1077:
                    case 1078:
                    case 1079: {
                        if (p.c.nclass == 0) {
                            p.conn.sendMessageLog("Bạn cần nhập học để sử dụng vật phẩm này.");
                            return;
                        }
                        if (p.c.quantityItemyTotal(1073) < 10 || p.c.quantityItemyTotal(1074) < 10 || p.c.quantityItemyTotal(1075) < 10 || p.c.quantityItemyTotal(1076) < 10 || p.c.quantityItemyTotal(1077) < 10 || p.c.quantityItemyTotal(1078) < 10 || p.c.quantityItemyTotal(1079) < 10) {
                            p.conn.sendMessageLog("Bạn không có đủ 7 viên ngọc rồng Đen 1-7 sao để gọi rồng.");
                            return;
                        }
                        if (p.c.getBagNull() < 1) {
                            p.sendAddchatYellow(Language.NOT_ENOUGH_BAG);
                            return;
                        }
                        synchronized (LOCK) {
                            try {
                                m = new Message(-30);
                                m.writer().writeByte(-58);
                                m.writer().writeInt(p.c.get().id);
                                m.writer().flush();
                                p.conn.sendMessage(m);
                                m.cleanup();

                                m = new Message(-30);
                                m.writer().writeByte(-57);
                                m.writer().flush();
                                p.c.tileMap.sendMessage(m);
                                m.cleanup();

                                LOCK.wait(400L);
                                p.c.get().isGoiRong = true;
                                LOCK.wait(400L);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        int i;
                        byte count = 0;
                        for (i = 1073; i <= 1079; i++) {
                            if (p.c.getIndexBagid(i, false) != -1) {
                                p.c.removeItemBag(p.c.getIndexBagid(i, false), 1);
                                count++;
                            } else {
                                p.c.removeItemBag(p.c.getIndexBagid(i, true), 1);
                            }
                        }
                        byte nClassC = p.c.get().nclass;
                        if (p.c.isNhanban) {
                            nClassC = p.c.clone.nclass;
                        }
                        p.c.addItemBag(false, ItemTemplate.itemDefault(419 + 689 + GameSrc.SysClass(nClassC), count == 7 ? false : true));
                        break;
                    }
                    //longden
                    case 664: {

                        if (p.c.getBagNull() < 1) {
                            p.sendAddchatYellow(Language.NOT_ENOUGH_BAG);
                            return;
                        }
                        synchronized (LOCK) {
                            try {
                                m = new Message(-30);
                                m.writer().writeByte(-58);
                                m.writer().writeInt(p.c.get().id);
                                m.writer().flush();
                                p.conn.sendMessage(m);
                                m.cleanup();

                                m = new Message(-30);
                                m.writer().writeByte(-57);
                                m.writer().flush();
                                p.c.tileMap.sendMessage(m);
                                m.cleanup();

                                LOCK.wait(400L);
                                p.c.get().isthaden = true;
                                LOCK.wait(400L);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        break;
                    }

                    //Túi vải
                    case 215:
                    case 229:
                    case 283:
                    case 829: {
                        byte level = (byte) ((item.id != 215) ? ((item.id != 229) ? ((item.id != 283) ? 4 : 3) : 2) : 1);
                        if (level > p.c.levelBag + 1) {
                            p.sendAddchatYellow("Cần mở Túi vải cấp " + (p.c.levelBag + 1) + " mới có thể mở được túi vải này.");
                            return;
                        }
                        if (p.c.levelBag >= level) {
                            p.sendAddchatYellow("Bạn đã mở túi vải này rồi.");
                            return;
                        }
                        p.c.levelBag = level;
                        p.c.maxluggage += UseItem.arrOpenBag[level];
                        Item[] bag = new Item[p.c.maxluggage];
                        short j;
                        for (j = 0; j < p.c.ItemBag.length; ++j) {
                            bag[j] = p.c.ItemBag[j];
                        }
                        (p.c.ItemBag = bag)[index] = null;
                        p.openBagLevel(index);
                        break;
                    }
                    case 597: {
                        item.setLock(true);

                        if (numbagnull == 0) {
                            p.sendAddchatYellow("Hành trang không đủ ô trống để câu cá");
                            p.endLoad(true);
                            return;
                        }
                        if (p.c.y == 456 && (p.c.x >= 107 && p.c.x <= 2701)) {
                            boolean coMoi = false;
                            for (Item item1 : p.c.ItemBag) {
                                if (item1 != null && (item1.id == 602 || item1.id == 603)) {
                                    p.c.removeItemBags(item1.id, 1);
                                    coMoi = true;
                                    break;
                                }
                            }
                            if (coMoi) {
                                p.sendAddchatYellow("Bạn đang câu cá...");
                                new Thread(() -> {
                                    try {
                                        Thread.sleep(5000);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    int tl = (int) Util.nextInt(1000);
                                    if (tl >= 395) {
                                        p.sendAddchatYellow("Bạn câu được cái nịt.");
                                    } else if (tl >= 345 && tl <= 395) {
                                        Item itemup = ItemTemplate.itemDefault(1106);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá heo");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1108);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Đuối");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1397);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Cờ");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1398);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Chép");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1399);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá chim");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1400);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá bơn");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1104);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá voi Sát thủ");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1402);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá rô phi");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1100);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Thiên Đường");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1404);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Ngừ");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1405);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Trê Ăn Tạp");
                                    } else if (tl >= 295 && tl <= 345) {
                                        Item itemup = ItemTemplate.itemDefault(1406);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Lóc 7 Màu");
                                    } else if (tl >= 10 && tl <= 15) {
                                        Item itemup = ItemTemplate.itemDefault(1407);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cua Đỏ Thuỵ Sĩ");
                                    } else if (tl >= 10 && tl <= 15) {
                                        Item itemup = ItemTemplate.itemDefault(1408);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Mập Trắng");
                                    } else if (tl >= 10 && tl <= 15) {
                                        Item itemup = ItemTemplate.itemDefault(1409);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Gà Tam Thể");
                                    } else if (tl >= 10 && tl <= 15) {
                                        Item itemup = ItemTemplate.itemDefault(1410);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Ngựa Trắng 1 Sừng");
                                    } else if (tl >= 10 && tl <= 15) {
                                        Item itemup = ItemTemplate.itemDefault(1411);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Pikachu");
                                    } else if (tl >= 10 && tl <= 15) {
                                        Item itemup = ItemTemplate.itemDefault(1412);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Phượng hoàng đỏ");
                                    } else if (tl >= 10 && tl <= 15) {
                                        Item itemup = ItemTemplate.itemDefault(1413);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Nai Xừ");
                                    } else if (tl >= 10 && tl <= 15) {
                                        Item itemup = ItemTemplate.itemDefault(1414);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Khủng long ciute");
                                    } else if (tl >= 1 && tl <= 5) {
                                        Item itemup = ItemTemplate.itemDefault(1415);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Gà Vàng 9999");
                                        Manager.chatKTG("Người chơi " + p.c.name + " tham gia câu cá nhận được Gà Vàng 9999");
                                    } else if (tl >= 1 && tl <= 5) {
                                        Item itemup = ItemTemplate.itemDefault(1416);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Kỳ Lân Lửa");
                                        Manager.chatKTG("Người chơi " + p.c.name + " tham gia câu cá nhận được Kỳ Lân Lửa");
                                    }

                                    p.endLoad(true);
                                }).start();

                            } else {
                                p.sendAddchatYellow("Không có mồi câu để câu cá");
                                p.endLoad(true);
                            }
                        } else {
                            p.sendAddchatYellow("Hãy đi đến vùng nước ở hồ câu dịch vụ để câu cá");
                            p.endLoad(true);
                        }

                        break;
                    }
                    case 1394: {
                        item.setLock(true);

                        if (numbagnull == 0) {
                            p.sendAddchatYellow("Hành trang không đủ ô trống để câu cá");
                            p.endLoad(true);
                            return;
                        }
                        if (p.c.y == 456 && (p.c.x >= 107 && p.c.x <= 2701)) {
                            boolean coMoi = false;
                            for (Item item1 : p.c.ItemBag) {
                                if (item1 != null && (item1.id == 602 || item1.id == 603)) {
                                    p.c.removeItemBags(item1.id, 1);
                                    coMoi = true;
                                    break;
                                }
                            }
                            if (coMoi) {
                                p.sendAddchatYellow("Bạn đang câu cá...");
                                new Thread(() -> {
                                    try {
                                        Thread.sleep(5000);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                    int tl = (int) Util.nextInt(1000);
                                    if (tl >= 700) {
                                        p.sendAddchatYellow("Bạn câu được cái nịt.");
                                    } else  if (tl >= 1 && tl <= 2) {
                                        Item itemup = ItemTemplate.itemDefault(1416);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Kỳ Lân Lửa");
                                        Manager.chatKTG("Người chơi " + p.c.name + " tham gia câu cá nhận được Kỳ Lân Lửa");
                                    } else if (tl >= 2 && tl <= 3) {
                                        Item itemup = ItemTemplate.itemDefault(1415);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Gà Vàng 9999");
                                        Manager.chatKTG("Người chơi " + p.c.name + " tham gia câu cá nhận được Gà Vàng 9999");
                                    } else if (tl >= 3 && tl <= 20) {
                                        Item itemup = ItemTemplate.itemDefault(1414);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Khủng long ciute");
                                    } else if (tl >= 20&& tl <= 30) {
                                        Item itemup = ItemTemplate.itemDefault(1413);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Nai Xừ");
                                    } else if (tl >= 30 && tl <= 50) {
                                        Item itemup = ItemTemplate.itemDefault(1412);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Phượng hoàng đỏ");
                                    } else if (tl >= 50 && tl <= 60) {
                                        Item itemup = ItemTemplate.itemDefault(1411);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Pikachu");
                                    } else if (tl >= 60 && tl <= 70) {
                                        Item itemup = ItemTemplate.itemDefault(1410);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Ngựa Trắng 1 Sừng");
                                    } else if (tl >= 70 && tl <= 100) {
                                        Item itemup = ItemTemplate.itemDefault(1409);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Gà Tam Thể");
                                    } else if (tl >= 100 && tl <= 120) {
                                        Item itemup = ItemTemplate.itemDefault(1408);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Mập Trắng");
                                    } else if (tl >= 120 && tl <= 150) {
                                        Item itemup = ItemTemplate.itemDefault(1407);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cua Đỏ Thuỵ Sĩ");
                                    } else if (tl >= 150 && tl <= 190) {
                                        Item itemup = ItemTemplate.itemDefault(1406);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Lóc 7 Màu");
                                    } else if (tl >= 190 && tl <= 240) {
                                        Item itemup = ItemTemplate.itemDefault(1405);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Trê Ăn Tạp");
                                    } else if (tl >= 240 && tl <= 290) {
                                        Item itemup = ItemTemplate.itemDefault(1404);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Ngừ");
                                    } else if (tl >= 290 && tl <= 340) {
                                        Item itemup = ItemTemplate.itemDefault(1100);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Thiên Đường");
                                    } else if (tl >= 340 && tl <= 390) {
                                        Item itemup = ItemTemplate.itemDefault(1402);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá rô phi");
                                    } else if (tl >= 390 && tl <= 440) {
                                        Item itemup = ItemTemplate.itemDefault(1104);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá voi Sát thủ");
                                    } else if (tl >= 440 && tl <= 490) {
                                        Item itemup = ItemTemplate.itemDefault(1400);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá bơn");
                                    } else if (tl >= 490 && tl <= 540) {
                                        Item itemup = ItemTemplate.itemDefault(1399);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá chim");
                                    } else if (tl >= 540 && tl <= 590) {
                                        Item itemup = ItemTemplate.itemDefault(1398);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Chép");
                                    } else if (tl >= 590 && tl <= 630) {
                                        Item itemup = ItemTemplate.itemDefault(1397);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Cờ");
                                    } else if (tl >= 630 && tl <= 660) {
                                        Item itemup = ItemTemplate.itemDefault(1108);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá Đuối");
                                    } else if (tl >= 660 && tl <= 700) {
                                        Item itemup = ItemTemplate.itemDefault(1106);
                                        p.c.addItemBag(true, itemup);
                                        p.c.diemcauca++;
                                        p.sendAddchatYellow("Bạn nhận được Cá heo");
                                    }
                                    p.endLoad(true);
                                }).start();

                            } else {
                                p.sendAddchatYellow("Không có mồi câu để câu cá");
                                p.endLoad(true);
                            }
                        } else {
                            p.sendAddchatYellow("Hãy đi đến vùng nước ở hồ câu dịch vụ để câu cá");
                            p.endLoad(true);
                        }

                        break;
                    }
                    case 1112: {
                        p.conn.sendMessageLog("Sự kiện đã kết thúc");
                        break;
                    }
                    //Giấy tẩy tiềm năng
                    case 240: {
                        p.c.removeItemBag(index, 1);
                        p.c.get().countTayTiemNang++;
                        p.sendAddchatYellow("Số lần tẩy điểm tiềm năng tăng thêm 1");
                        break;
                    }
                    //giấy tẩy kỹ năng
                    case 241: {
                        p.c.removeItemBag(index, 1);
                        p.c.get().countTayKyNang++;
                        p.sendAddchatYellow("Số lần tẩy điểm kỹ năng tăng thêm 1");
                        break;
                    }
                    case 248: {
                        Effect eff = p.c.get().getEffId(22);
                        if (eff != null) {
                            long time = eff.timeRemove + 18000000L;
                            p.setEffect(22, 0, (int) (time - System.currentTimeMillis()), 2);
                        } else {
                            p.setEffect(22, 0, 18000000, 2);
                        }
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //giấy vụn
                    case 251: {
                        if (item.quantity < 300) {
                            p.sendAddchatYellow("Bạn cần ít nhất 300 mảnh giấy vụn mới có thể sử dụng.");
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        p.typemenu = -125;
                        Menu.doMenuArray(p, new String[]{"Sách kỹ năng sơ", "Sách tiềm năng sơ"});
                        break;
                    }
                    //chuyensinh
                    case 1185: {
                        p.typemenu = -126;
                        Menu.doMenuArray(p, new String[]{"Phàm Nhân", "Tiên Nhân", "Thánh Nhân", "Thần Nhân", "Hướng dẫn"});
                        break;
                    }
                    //sách kỹ năng sơ
                    case 252: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow("Phân thân không thể sử dụng vật phẩm này.");
                            return;
                        }
                        if (p.c.get().useKyNang < 1) {
                            p.sendAddchatYellow("Bạn đã hết số lần sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.get().useKyNang--;
                        p.c.get().spoint += 1;
                        p.c.removeItemBag(index, 1);
                        p.loadSkill();
                        p.sendAddchatYellow("Bạn nhận được 1 điểm kỹ năng.");
                        break;
                    }
                    //sách tiềm năng sơ
                    case 253: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow("Phân thân không thể sử dụng vật phẩm này.");
                            return;
                        }
                        if (p.c.get().useTiemNang < 1) {
                            p.sendAddchatYellow("Bạn đã hết số lần sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.get().useTiemNang--;
                        p.c.get().ppoint += 10;
                        p.loadPpoint();
                        p.c.removeItemBag(index, 1);
                        p.sendAddchatYellow("Bạn nhận được 10 điểm tiềm năng.");
                        break;
                    }
                    case 254:
                    case 255:
                    case 256: {
                        if (p.c.expdown == 0) {
                            p.conn.sendMessageLog("Bạn không có kinh nhiệm âm để sử dụng vật phẩm này!");
                            return;
                        }
                        if (item.id == 254 && p.c.level >= 30) {
                            p.conn.sendMessageLog("Trình độ của bạn không phù hợp để sử dụng vật phẩm này.");
                            return;
                        }
                        if (item.id == 255 && (p.c.level < 30 || p.c.level >= 60)) {
                            p.conn.sendMessageLog("Trình độ của bạn không phù hợp để sử dụng vật phẩm này.");
                            return;
                        }
                        if (item.id == 256 && p.c.level < 60) {
                            p.conn.sendMessageLog("Trình độ của bạn không phù hợp để sử dụng vật phẩm này.");
                            return;
                        }
                        p.updateExp(p.c.expdown);
                        p.sendAddchatYellow("Kinh nghiệm âm của bạn đã được xoá.");
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //lam thảo dược
                    case 261: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (!p.c.tileMap.map.mapLDGT()) {
                            p.sendAddchatYellow("Vật phẩm chỉ có thể được dùng trong Lãnh Địa Gia Tộc.");
                            return;
                        }
                        p.setEffect(23, 0, 300000, 2000);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //Túi quà gia tộc
                    case 263: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        int per = (int) Util.nextInt(UseItem.idItemTuiQuaGiaToc.length);
                        p.c.addItemBag(true, ItemTemplate.itemDefault(UseItem.idItemTuiQuaGiaToc[per]));
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 268: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.useTaThuLenh == 0) {
                            p.conn.sendMessageLog("Số lần sử dụng lệnh bài hang động của bạn hôm nay đã hết.");
                            return;
                        }
                        p.c.useTaThuLenh--;
                        p.c.countTaskTaThu -= 2;
                        p.sendAddchatYellow("Số lần nhận nhiệm vụ tà thú tăng thêm 2 lần");
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //Bánh Chưng
                    case 643: {
                        if (Server.manager.event != 4) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);

                        if (p.status == 1) {
                            p.updateExp(750000L);
                            if (p.c.exptype == 1) {
                                p.c.expTN += 750000 / 1000;
                            }
                        } else {
                            p.updateExp(1500000L);
                        }
                        if (Util.nextInt(10) < 4) {
                            if (p.status == 1) {
                                p.updateExp(1500000L);
                                if (p.c.exptype == 1) {
                                    p.c.expTN += 1500000 / 1000;
                                }
                            } else {
                                p.updateExp(3000000L);
                            }
                        } else if (Util.nextInt(160) <= 1) {
                            Item itemup = ItemTemplate.itemDefault((int) Util.nextInt(654, 655));
                            itemup.isLock = false;
                            p.c.addItemBag(false, itemup);
                            break;
                        } else {
                            short idI = UseItem.idItemBanhChung[(int) Util.nextInt(UseItem.idItemBanhChung.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Bánh Tét
                    case 644: {
                        if (Server.manager.event != 4) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull < 1) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);

                        if (p.status == 1) {
                            p.updateExp(1000000L);
                            if (p.c.exptype == 1) {
                                p.c.expTN += 1000000 / 1000;
                            }
                        } else {
                            p.updateExp(2000000L);
                        }

                        int perRuong = (int) Util.nextInt(2000);
                        int rhb = (int) Util.nextInt(15000);
                        if (Util.nextInt(10) < 3) {
                            if (p.status == 1) {
                                p.updateExp(1500000L);
                                if (p.c.exptype == 1) {
                                    p.c.expTN += 1500000 / 1000;
                                }
                            } else {
                                p.updateExp(3000000L);
                            }
                            break;
                        } else if (Util.nextInt(160) <= 1) {
                            Item itemup = ItemTemplate.itemDefault((int) Util.nextInt(652, 653));
                            itemup.isLock = false;
                            p.c.addItemBag(false, itemup);
                            break;
                        } else if (rhb == 14999) {
                            Item itemUp = new Item();
                            itemUp.id = 385;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(385).name);
                            CheckRHB.checkRHBArrayList.add(new CheckRHB(p.c.name, ItemTemplate.ItemTemplateId(385).name, Util.toDateString(Date.from(Instant.now()))));
                            return;
                        } else if (perRuong == 0) {
                            Item itemUp = new Item();
                            itemUp.id = 384;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(384).name);
                            CheckRHB.checkRHBArrayList.add(new CheckRHB(p.c.name, ItemTemplate.ItemTemplateId(384).name, Util.toDateString(Date.from(Instant.now()))));
                            return;
                        } else if (perRuong == 1 || perRuong == 2) {
                            Item itemUp = new Item();
                            itemUp.id = 383;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else if (perRuong == 4) {
                            Item itemUp = new Item();
                            itemUp.id = 340;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else if (perRuong == 6 || perRuong == 7) {
                            Item itemUp = new Item();
                            itemUp.id = 539;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else {
                            short idI = UseItem.idItemBanhTet[(int) Util.nextInt(UseItem.idItemBanhTet.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            if (idI == 781 || idI == 742 || idI == 523) {
                                itemup.quantity = 1;
                                itemup.isExpires = true;
                                itemup.expires = System.currentTimeMillis() + 604800000L;
                            }
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }

                    //Đan dược
                    case 275: {
                        p.setEffect(24, 0, 600000, 500);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 276: {
                        p.setEffect(25, 0, 600000, 5000);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 277: {
                        p.setEffect(26, 0, 600000, 1000);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 278: {
                        p.setEffect(27, 0, 600000, 100000);
                        p.c.removeItemBag(index, 1);

                        m = new Message(11);
                        m.writer().writeByte(index);
                        m.writer().writeByte((int) p.c.get().speed());
                        m.writer().writeInt((int) p.c.get().getMaxHP());
                        m.writer().writeInt((int) p.c.get().getMaxMP());
                        m.writer().writeShort((int) p.c.get().eff5buffHP());
                        m.writer().writeShort((int) p.c.get().eff5buffMP());
                        m.writer().flush();
                        p.conn.sendMessage(m);
                        m.cleanup();

                        break;
                    }
                    case 280: {
                        if (p.c.useCave == 0) {
                            p.conn.sendMessageLog("Số lần sử dụng lệnh bài hang động của bạn hôm nay đã hết.");
                            return;
                        }
                        p.c.nCave++;
                        p.c.useCave--;
                        p.sendAddchatYellow("Số lần vào hang động tăng thêm 1 lần, hôm nay bạn chỉ cần có thể sử dụng lệnh bài " + p.c.useCave + " lần");
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    // lệnh bài hang động vô hạn
                    case 220: {
                        p.c.nCave++;
                        p.sendAddchatYellow("Số lần vào hang động tăng thêm 1 lần");
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //rương may mắn
                    case 272: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        if (Util.nextInt(3) == 0) {
                            int num = (int) Util.nextInt(200000, 250000);
                            p.c.upyenMessage(num);
                            p.sendAddchatYellow("Bạn nhận được " + num + " yên");
                        } else if (Util.nextInt(150) == 0) {
                            p.c.addItemBag(false, ItemTemplate.itemDefault(GameSrc.arrNgocRong[(int) Util.nextInt(GameSrc.arrNgocRong.length)], false));
                        } else {
                            short idI = UseItem.idItemRuongMayMan[(int) Util.nextInt(UseItem.idItemRuongMayMan.length)];
                            ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                            Item itemup;
                            if (data2.type < 10) {
                                if (data2.type == 1) {
                                    itemup = ItemTemplate.itemDefault(idI);
                                    itemup.sys = GameSrc.SysClass(data2.nclass);
                                } else {
                                    byte sys = (byte) Util.nextInt(1, 3);
                                    itemup = ItemTemplate.itemDefault(idI, sys);
                                }
                            } else {
                                itemup = ItemTemplate.itemDefault(idI);
                            }
                            itemup.isLock = item.isLock;
                            int idOp2;
                            for (Option Option : itemup.options) {
                                idOp2 = Option.id;
                                Option.param = (int) Util.nextInt(item.getOptionShopMin(idOp2, Option.param), Option.param);
                            }
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //rương tinh xảo
                    case 282: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (Util.nextInt(3) == 0) {
                            int num = (int) Util.nextInt(400000, 500000);
                            p.c.upyenMessage(num);
                            p.sendAddchatYellow("Bạn nhận được " + num + " yên");
                        } else if (Util.nextInt(150) == 0) {
                            p.c.addItemBag(false, ItemTemplate.itemDefault(GameSrc.arrNgocRong[(int) Util.nextInt(GameSrc.arrNgocRong.length)], false));
                        } else if (Util.nextInt(300) == 1) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(28, false));
                        } else if (Util.nextInt(300) == 0) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(383, false));
                        } else if (Util.nextInt(130) == 99) {
                            p.c.addItemBag(false, ItemTemplate.itemDefault(539, false));
                        } else {
                            short idI = UseItem.idItemRuongTinhXao[(int) Util.nextInt(UseItem.idItemRuongTinhXao.length)];
                            ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                            Item itemup;
                            if (data2.type < 10) {
                                if (data2.type == 1) {
                                    itemup = ItemTemplate.itemDefault(idI);
                                    itemup.sys = GameSrc.SysClass(data2.nclass);
                                } else {
                                    byte sys = (byte) Util.nextInt(1, 3);
                                    itemup = ItemTemplate.itemDefault(idI, sys);
                                }
                            } else {
                                itemup = ItemTemplate.itemDefault(idI);
                            }
                            itemup.isLock = item.isLock;
                            for (Option Option : itemup.options) {
                                int idOp2 = Option.id;
                                Option.param = (int) Util.nextInt(item.getOptionShopMin(idOp2, Option.param), Option.param);
                            }
                            p.c.addItemBag(true, itemup);
                        }
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //bánh pía, đậu xanh
                    case 298:
                    case 299:
                    case 300:
                    case 301: {
                        if (Server.manager.event != 2) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.updateExp(300000L);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //Hộp bánh thường
                    case 302: {
                        if (Server.manager.event != 2) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        p.updateExp(500000L);
                        if (Util.nextInt(10) < 3) {
                            p.updateExp(100000L);
                        } else {
                            short idI = UseItem.idItemHopBanhThuong[(int) Util.nextInt(UseItem.idItemHopBanhThuong.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;

                    }

                    //Hộp bánh thượng hạng
                    case 303: {
                        if (Server.manager.event != 2) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        int perRuong = (int) Util.nextInt(200);
                        p.updateExp(1000000L);

                        int tyle = (int) Util.nextInt(3000);
                        if (tyle > 1) {
                            short idI = UseItem.idItemHopBanhThuongHang[(int) Util.nextInt(UseItem.idItemHopBanhThuongHang.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                            return;

                        } else if (tyle > 2 && tyle < 10) {
                            short idI = UseItem.idItemrandom1[(int) Util.nextInt(UseItem.idItemrandom1.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            byte sys2 = -1;
                            if (Util.nextInt(2) == 1) {
                                if (p.c.get().nclass == 1 || p.c.get().nclass == 2) {
                                    sys2 = 1;
                                } else if (p.c.get().nclass == 3 || p.c.get().nclass == 4) {
                                    sys2 = 2;
                                } else if (p.c.get().nclass == 5 || p.c.get().nclass == 6) {
                                    sys2 = 3;
                                }
                                ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                                if (data2.type < 10) {
                                    if (data2.type == 1) {
                                        itemup = ItemTemplate.itemDefault(idI);
                                        sys2 = GameSrc.SysClass(data2.nclass);
                                    } else {
                                        sys2 = (byte) Util.nextInt(1, 3);
                                        itemup = ItemTemplate.itemDefault(idI, sys2);
                                    }
                                } else {
                                    itemup = ItemTemplate.itemDefault(idI);
                                }
                                long Tn = Util.nextInt(1, 2000);
                                long Tc = Util.nextInt(1, 2000);
                                itemup.isLock = item.isLock;
                                itemup.upgrade = 0;
                                itemup.quantity = 1;
                                itemup.sys = (byte) sys2;
                                itemup.upgrade = 16;
                                itemup.isLock = false;
                                itemup.isExpires = false;
                                itemup.expires = -1L;
                                Option op = new Option(58, (int) Tn);
                                itemup.options.add(op);
                                Option op1 = new Option(94, (int) Tc);
                                itemup.options.add(op1);
                                p.c.addItemBag(true, itemup);

                            }
                            break;
                        } else if (tyle < 2) {
                            short idI = UseItem.idItemrandom1[(int) Util.nextInt(UseItem.idItemrandom1.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            byte sys2 = -1;
                            if (Util.nextInt(2) == 1) {
                                if (p.c.get().nclass == 1 || p.c.get().nclass == 2) {
                                    sys2 = 1;
                                } else if (p.c.get().nclass == 3 || p.c.get().nclass == 4) {
                                    sys2 = 2;
                                } else if (p.c.get().nclass == 5 || p.c.get().nclass == 6) {
                                    sys2 = 3;
                                }
                                ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                                if (data2.type < 10) {
                                    if (data2.type == 1) {
                                        itemup = ItemTemplate.itemDefault(idI);
                                        sys2 = GameSrc.SysClass(data2.nclass);
                                    } else {
                                        sys2 = (byte) Util.nextInt(1, 3);
                                        itemup = ItemTemplate.itemDefault(idI, sys2);
                                    }
                                } else {
                                    itemup = ItemTemplate.itemDefault(idI);
                                }

                                long Tn = Util.nextInt(100, 3000);
                                long Tc = Util.nextInt(100, 3000);
                                itemup.isLock = item.isLock;
                                itemup.quantity = 1;
                                itemup.sys = (byte) sys2;
                                itemup.upgrade = 16;
                                itemup.isLock = false;
                                itemup.isExpires = false;
                                itemup.expires = -1L;
                                Option op = new Option(58, (int) Tn);
                                itemup.options.add(op);
                                Option op1 = new Option(94, (int) Tc);
                                itemup.options.add(op1);
                                p.c.addItemBag(true, itemup);

                            }
                            break;
                        }
                    }

                    //Hộp bánh thượng hạng
                    case 663: {
                        if (Server.manager.event != 9) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        p.c.diemhuyhieu++;
                        int perRuong = (int) Util.nextInt(200);
                        p.updateExp(1000000L);

                        int tyle = (int) Util.nextInt(3000);
                        if (tyle > 5) {
                            short idI = UseItem.idItemhuyhieunsotruong[(int) Util.nextInt(UseItem.idItemhuyhieunsotruong.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                            return;

                        } else if (tyle > 2 && tyle < 5) {
                            short idI = UseItem.idItemrandom1[(int) Util.nextInt(UseItem.idItemrandom1.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            byte sys2 = -1;
                            if (Util.nextInt(2) == 1) {
                                if (p.c.get().nclass == 1 || p.c.get().nclass == 2) {
                                    sys2 = 1;
                                } else if (p.c.get().nclass == 3 || p.c.get().nclass == 4) {
                                    sys2 = 2;
                                } else if (p.c.get().nclass == 5 || p.c.get().nclass == 6) {
                                    sys2 = 3;
                                }
                                ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                                if (data2.type < 10) {
                                    if (data2.type == 1) {
                                        itemup = ItemTemplate.itemDefault(idI);
                                        sys2 = GameSrc.SysClass(data2.nclass);
                                    } else {
                                        sys2 = (byte) Util.nextInt(1, 3);
                                        itemup = ItemTemplate.itemDefault(idI, sys2);
                                    }
                                } else {
                                    itemup = ItemTemplate.itemDefault(idI);
                                }
                                long Tn = Util.nextInt(10000, 25000);
                                long Tc = Util.nextInt(10000, 25000);
                                itemup.isLock = item.isLock;
                                itemup.upgrade = 0;
                                itemup.quantity = 1;
                                itemup.sys = (byte) sys2;
                                itemup.upgrade = 16;
                                itemup.isLock = true;
                                itemup.isExpires = false;
                                itemup.expires = -1L;
                                Option op = new Option(58, (int) Tn);
                                itemup.options.add(op);
                                Option op1 = new Option(94, (int) Tc);
                                itemup.options.add(op1);
                                p.c.addItemBag(true, itemup);

                            }
                            break;
                        } else if (tyle < 2) {
                            short idI = UseItem.idItemrandom2[(int) Util.nextInt(UseItem.idItemrandom2.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            byte sys2 = -1;
                            if (Util.nextInt(2) == 1) {
                                if (p.c.get().nclass == 1 || p.c.get().nclass == 2) {
                                    sys2 = 1;
                                } else if (p.c.get().nclass == 3 || p.c.get().nclass == 4) {
                                    sys2 = 2;
                                } else if (p.c.get().nclass == 5 || p.c.get().nclass == 6) {
                                    sys2 = 3;
                                }
                                ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                                if (data2.type < 10) {
                                    if (data2.type == 1) {
                                        itemup = ItemTemplate.itemDefault(idI);
                                        sys2 = GameSrc.SysClass(data2.nclass);
                                    } else {
                                        sys2 = (byte) Util.nextInt(1, 3);
                                        itemup = ItemTemplate.itemDefault(idI, sys2);
                                    }
                                } else {
                                    itemup = ItemTemplate.itemDefault(idI);
                                }

                                long Tn = Util.nextInt(10000, 30000);
                                long Tc = Util.nextInt(10000, 30000);
                                itemup.isLock = item.isLock;
                                itemup.quantity = 1;
                                itemup.sys = (byte) sys2;
                                itemup.upgrade = 16;
                                itemup.isLock = false;
                                itemup.isExpires = false;
                                itemup.expires = -1L;
                                Option op = new Option(58, (int) Tn);
                                itemup.options.add(op);
                                Option op1 = new Option(94, (int) Tc);
                                itemup.options.add(op1);
                                p.c.addItemBag(true, itemup);

                            }
                            break;
                        }
                    }
                    //Bao lì xì nhỏ
                    case 381: {
                        if (Server.manager.event != 4) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        p.updateExp(500000L);
                        if (Util.nextInt(10) < 3) {
                            p.updateExp(100000L);
                        } else {
                            short idI = UseItem.idItemBaoLiXiNho[(int) Util.nextInt(UseItem.idItemBaoLiXiNho.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Bao lì xì lớn
                    case 382: {
                        if (Server.manager.event != 4) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        int perRuong = (int) Util.nextInt(200);
                        p.updateExp(1000000L);
                        if (Util.nextInt(10) < 3) {
                            p.updateExp(1500000L);
                        } else if (perRuong == 50) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(385, false));
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(385).name);
                        } else if (perRuong <= 1) {
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(384).name);
                            p.c.addItemBag(true, ItemTemplate.itemDefault(384, false));
                        } else {
                            short idI = UseItem.idItemBaoLiXiLon[(int) Util.nextInt(UseItem.idItemBaoLiXiLon.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                            if (itemup.id == 308 || itemup.id == 309) {
                                ItemTemplate itemD = ItemTemplate.ItemTemplateId(itemup.id);
                                Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + itemD.name);
                            }
                        }
                        break;
                    }
                    //Bánh phong lôi
                    case 308: {
                        if (p.c.get().isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.get().useBanhPhongLoi < 1) {
                            p.sendAddchatYellow("Bạn đã hết số lần sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.get().useBanhPhongLoi--;
                        p.c.get().spoint += 1;
                        p.c.removeItemBag(index, 1);
                        p.loadSkill();
                        p.sendAddchatYellow("Bạn nhận được 1 điểm kỹ năng.");
                        break;
                    }
                    //bánh băng hoả
                    case 309: {
                        if (p.c.get().isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.get().useBanhBangHoa < 1) {
                            p.sendAddchatYellow("Bạn đã hết số lần sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.get().useBanhBangHoa--;
                        p.c.get().ppoint += 10;
                        p.loadPpoint();
                        p.c.removeItemBag(index, 1);
                        p.sendAddchatYellow("Bạn nhận được 10 điểm tiềm năng.");
                        break;
                    }
                    case ItemName.GIAY_CHUNG_NHAN_THO_XAY: {
                        p.setEffect(44, 0, 86400000, 0);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case ItemName.CHIA_KHOA_NHA: {
                        if (p.c.mapid != 182) {
                            Map ma = Manager.getMapid(182);
                            int maxPlayers = ma.template.maxplayers;
                            for (TileMap area : ma.area) {
                                if (area.numplayers < maxPlayers) {
                                    p.c.tileMap.leave(p);
                                    area.EnterMap0(p.c);
                                    return;
                                }
                            }
                        } else {
                            Map ma = Manager.getMapid(22);
                            int maxPlayers = ma.template.maxplayers;
                            for (TileMap area : ma.area) {
                                if (area.numplayers < maxPlayers) {
                                    p.c.tileMap.leave(p);
                                    area.EnterMap0(p.c);
                                    return;
                                }
                            }
                        }
                    }
                    //Rương bát bảo, bạch ngân, huyền bí
                    case 383:
                    case 384:
                    case 385: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.get().nclass == 0) {
                            p.conn.sendMessageLog("Hãy nhập học để sử dụng vật phẩm này.");
                            return;
                        }
                        byte sys2 = -1;
                        int idI2;
                        if (Util.nextInt(2) == 0) {
                            if (p.c.gender == 0) {
                                if (p.c.get().level < 50 && item.id != 384 && item.id != 385) {
                                    idI2 = (new short[]{171, 161, 151, 141, 131})[(int) Util.nextInt(5)];
                                } else if (p.c.get().level < 60 && item.id != 385) {
                                    idI2 = (new short[]{137, 163, 153, 143, 133})[(int) Util.nextInt(5)];
                                } else if (p.c.get().level < 70) {
                                    idI2 = (new short[]{330, 329, 328, 327, 326})[(int) Util.nextInt(5)];
                                } else {
                                    idI2 = (new short[]{368, 367, 366, 365, 364})[(int) Util.nextInt(5)];
                                }
                            } else if (p.c.get().level < 50 && item.id != 384 && item.id != 385) {
                                idI2 = (new short[]{170, 160, 102, 140, 130})[(int) Util.nextInt(5)];
                            } else if (p.c.get().level < 60 && item.id != 385) {
                                idI2 = (new short[]{172, 162, 103, 142, 132})[(int) Util.nextInt(5)];
                            } else if (p.c.get().level < 70) {
                                idI2 = (new short[]{325, 323, 333, 319, 317})[(int) Util.nextInt(5)];
                            } else {
                                idI2 = (new short[]{363, 361, 359, 357, 355})[(int) Util.nextInt(5)];
                            }
                        } else if (Util.nextInt(2) == 1) {
                            if (p.c.get().nclass == 1 || p.c.get().nclass == 2) {
                                sys2 = 1;
                            } else if (p.c.get().nclass == 3 || p.c.get().nclass == 4) {
                                sys2 = 2;
                            } else if (p.c.get().nclass == 5 || p.c.get().nclass == 6) {
                                sys2 = 3;
                            }
                            if (p.c.get().level < 50 && item.id != 384 && item.id != 385) {
                                idI2 = (new short[]{97, 117, 102, 112, 107, 122})[p.c.get().nclass - 1];
                            } else if (p.c.get().level < 60 && item.id != 385) {
                                idI2 = (new short[]{98, 118, 103, 113, 108, 123})[p.c.get().nclass - 1];
                            } else if (p.c.get().level < 70) {
                                idI2 = (new short[]{331, 332, 333, 334, 335, 336})[p.c.get().nclass - 1];
                            } else {
                                idI2 = (new short[]{369, 370, 371, 372, 373, 374})[p.c.get().nclass - 1];
                            }
                        } else if (p.c.get().level < 50 && item.id != 384 && item.id != 385) {
                            idI2 = (new short[]{192, 187, 182, 177})[(int) Util.nextInt(4)];
                        } else if (p.c.get().level < 60 && item.id != 385) {
                            idI2 = (new short[]{193, 188, 183, 178})[(int) Util.nextInt(4)];
                        } else if (p.c.get().level < 70) {
                            idI2 = (new short[]{324, 322, 320, 318})[(int) Util.nextInt(4)];
                        } else {
                            idI2 = (new short[]{362, 360, 358, 356})[(int) Util.nextInt(4)];
                        }
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI2);
                        Item itemup;
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI2);
                                sys2 = GameSrc.SysClass(data2.nclass);
                            } else {
                                sys2 = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault(idI2, sys2);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI2);
                        }
                        itemup.sys = sys2;
                        byte nextup = 12;
                        if (item.id == 384) {
                            nextup = 14;
                        } else if (item.id == 385) {
                            nextup = 16;
                        }
                        itemup.isLock = item.isLock;
                        itemup.upgradeNext(nextup);
                        p.c.addItemBag(true, itemup);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //Diều giấy
                    case 434: {
                        if (Server.manager.event != 1) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        p.updateExp(1500000L);
                        if (Util.nextInt(10) != 0) {
                            p.updateExp(3000000L);
                        } else {
                            short idI = UseItem.idItemDieuGiay[(int) Util.nextInt(UseItem.idItemDieuGiay.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Diều vải
                    case 435: {
                        if (Server.manager.event != 1) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        p.updateExp(2000000L);
                        int perRuong = (int) Util.nextInt(200);
                        if (Util.nextInt(10) != 0) {
                            p.updateExp(5000000L);
                        } else if (perRuong == 50) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(385, false));
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(385).name);
                        } else if (perRuong <= 1) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(384, false));
                        } else {
                            short idI = UseItem.idItemDieuVai[(int) Util.nextInt(UseItem.idItemDieuVai.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }

                    //xe tang
                    case 925: {
                        if (Server.manager.event != 6) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        p.c.thangtu++;
                        p.updateExp(200000000L);
                        int perRuong = (int) Util.nextInt(200);
                        if (Util.nextInt(10) != 0) {
                            p.updateExp(5000000L);
                        } else if (perRuong == 50) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(926, true));
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(926).name);
                        } else if (perRuong <= 1) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(385, true));
                        } else if (Util.nextInt(150) <= 10) {
                            Item itemup = ItemTemplate.itemDefault((int) Util.nextInt(652, 655));
                            itemup.isLock = true;
                            p.c.addItemBag(true, itemup);
                            break;
                        } else {
                            short idI = UseItem.idItemXetang[(int) Util.nextInt(UseItem.idItemXetang.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Lệnh bài kinh nghiệm gia tộc sơ, trung, cao
                    case 436:
                    case 437:
                    case 438: {
                        ClanManager clan = ClanManager.getClanName(p.c.clan.clanName);
                        if (clan == null || clan.getMem(p.c.name) == null) {
                            p.sendAddchatYellow("Cần có gia tộc để sử dụng");
                            return;
                        }
                        if (item.id == 436) {
                            if (clan.level < 1) {
                                p.sendAddchatYellow("Yêu cầu gia tộc phải đạt cấp 5");
                                return;
                            }
                            //  p.upExpClan((int) Util.nextInt(100, 200));
                            p.c.removeItemBag(index, 1);
                        } else if (item.id == 437) {
                            if (clan.level < 10) {
                                p.sendAddchatYellow("Yêu cầu gia tộc phải đạt cấp 10");
                                return;
                            }
                            //  p.upExpClan((int) Util.nextInt(300, 800));
                            p.c.removeItemBag(index, 1);
                        } else {
                            if (item.id != 438) {
                                break;
                            }
                            if (clan.level < 15) {
                                p.sendAddchatYellow("Yêu cầu gia tộc phải đạt cấp 15");
                                return;
                            }
                            //  p.upExpClan((int) Util.nextInt(1000, 2000));
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    //Chuyển tinh thạch
                    case 454: {
                        if (p.updateSysMounts()) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    //áo Phao
                    case 1159:
                    case 1158: {

                        if (numbagnull < 1) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }

                        p.c.removeItemBag(index, 1);
                        p.c.boiloi += 1;
                        int tyle = (int) Util.nextInt(3000);
                        if (tyle > 42) {
                            short idI = UseItem.idItemAoPhao[(int) Util.nextInt(UseItem.idItemAoPhao.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                            return;

                        } else if (tyle >= 40 && tyle < 42) {
                            Item itemup = ItemTemplate.itemDefault(999);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 38 && tyle < 40) {
                            Item itemup = ItemTemplate.itemDefault(1000);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 36 && tyle < 38) {
                            Item itemup = ItemTemplate.itemDefault(1001);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 34 && tyle < 36) {
                            Item itemup = ItemTemplate.itemDefault(1002);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 32 && tyle < 34) {
                            Item itemup = ItemTemplate.itemDefault(1003);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 30 && tyle < 32) {
                            Item itemup = ItemTemplate.itemDefault(1004);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 28 && tyle < 30) {
                            Item itemup = ItemTemplate.itemDefault(932);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 26 && tyle < 28) {
                            Item itemup = ItemTemplate.itemDefault(933);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 24 && tyle < 26) {
                            Item itemup = ItemTemplate.itemDefault(934);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 22 && tyle < 24) {
                            Item itemup = ItemTemplate.itemDefault(795);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 20 && tyle < 22) {
                            Item itemup = ItemTemplate.itemDefault(796);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 18 && tyle < 20) {
                            Item itemup = ItemTemplate.itemDefault(799);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 16 && tyle < 18) {
                            Item itemup = ItemTemplate.itemDefault(800);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 12 && tyle < 14) {
                            Item itemup = ItemTemplate.itemDefault(825);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 10 && tyle < 12) {
                            Item itemup = ItemTemplate.itemDefault(826);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 8 && tyle < 10) {
                            Item itemup = ItemTemplate.itemDefault(813);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 6 && tyle < 8) {
                            Item itemup = ItemTemplate.itemDefault(814);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 4 && tyle < 6) {
                            Item itemup = ItemTemplate.itemDefault(815);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 2 && tyle < 4) {
                            Item itemup = ItemTemplate.itemDefault(1122);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(1122).name);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 0 && tyle < 2) {
                            Item itemup = ItemTemplate.itemDefault(1174);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(1174).name);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 1995 && tyle <= 1999) {
                            Item itemup = ItemTemplate.itemDefault(1175);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(1175).name);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 10;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 1666 && tyle <= 1669) {
                            Item itemup = ItemTemplate.itemDefault(1176);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(1176).name);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle <= 999 && tyle <= 1001) {
                            Item itemup = ItemTemplate.itemDefault(1177);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(1177).name);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 10;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 2022 && tyle <= 2024) {
                            Item itemup = ItemTemplate.itemDefault(1178);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(1178).name);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 2019 && tyle <= 2021) {
                            Item itemup = ItemTemplate.itemDefault(1179);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(1179).name);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        } else if (tyle >= 1975 && tyle <= 1979) {
                            Item itemup = ItemTemplate.itemDefault(1181);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(1181).name);
                            itemup.isLock = item.isLock;
                            itemup.upgrade = 16;
                            p.c.addItemBag(true, itemup);
                        }

                        break;
                    }
                    //Túi quà noel
                    case 477: {
                        if (Server.manager.event != 3) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull < 1) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }

//                        Item itemup = ItemTemplate.itemDefault(Util.nextInt(652,655));
//                        itemup.isLock = item.isLock;
//                        p.c.addItemBag(true, itemup);
//                        return;
                        p.c.removeItemBag(index, 1);
                        if (p.status == 1) {
                            p.updateExp(250000L);
                            if (p.c.exptype == 1) {
                                p.c.expTN += 250000 / 1000;
                            }
                        } else {
                            p.updateExp(500000L);
                        }
                        if (Util.nextInt(10) < 7) {
                            if (p.status == 1) {
                                p.updateExp(2500000L);
                                if (p.c.exptype == 1) {
                                    p.c.expTN += 500000 / 1000;
                                }
                            } else {
                                p.updateExp(1000000L);
                            }
                        } else {
                            short idI = UseItem.idItemBanhChocolate[(int) Util.nextInt(UseItem.idItemBanhChocolate.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Hộp quà noel
                    case 478: {
                        if (Server.manager.event != 3) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull < 1) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        if (p.status == 1) {
                            p.updateExp(500000L);
                            if (p.c.exptype == 1) {
                                p.c.expTN += 500000 / 1000;
                            }
                        } else {
                            p.updateExp(1000000L);
                        }

                        int perRuong = (int) Util.nextInt(2500);
                        int rhb = (int) Util.nextInt(16500);
                        if (Util.nextInt(10) < 3) {
                            if (p.status == 1) {
                                p.updateExp(1000000L);
                                if (p.c.exptype == 1) {
                                    p.c.expTN += 1000000 / 1000;
                                }
                            } else {
                                p.updateExp(2000000L);
                            }
                            break;
                        } else if (rhb == 16008) {
                            Item itemUp = new Item();
                            itemUp.id = 385;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(385).name);
                            CheckRHB.checkRHBArrayList.add(new CheckRHB(p.c.name, ItemTemplate.ItemTemplateId(385).name, Util.toDateString(Date.from(Instant.now()))));
                            break;
                        } else if (perRuong < 1) {
                            Item itemUp = new Item();
                            itemUp.id = 384;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(384).name);
                            CheckRHB.checkRHBArrayList.add(new CheckRHB(p.c.name, ItemTemplate.ItemTemplateId(384).name, Util.toDateString(Date.from(Instant.now()))));
                            break;
                        } else if (perRuong == 1 || perRuong == 2) {
                            Item itemUp = new Item();
                            itemUp.id = 383;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            break;
                        } else if (perRuong == 3) {
                            Item itemUp = new Item();
                            itemUp.id = 540;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            break;
                        } else if (perRuong == 4 || perRuong == 5 || perRuong == 6) {
                            Item itemUp = new Item();
                            itemUp.id = 539;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            break;
                        } else if (Util.nextInt(150) <= 1) {
                            Item itemup = ItemTemplate.itemDefault((int) Util.nextInt(652, 655));
                            itemup.isLock = false;
                            p.c.addItemBag(false, itemup);
                            break;
                        } else {
                            short idI = UseItem.idItemBanhDauTay[(int) Util.nextInt(UseItem.idItemBanhDauTay.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            if (idI == 781 || idI == 742 || idI == 523) {
                                itemup.quantity = 1;
                                itemup.isExpires = true;
                                itemup.expires = System.currentTimeMillis() + 604800000L;
                            }
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Cổ lệnh
                    case 490: {
                        if (p.c.isNhanban) {
                            p.conn.sendMessageLog(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.pk > 0) {
                            p.sendAddchatYellow("Không thể vào làng cổ khi có điểm hiếu chiến lớn hơn 0");
                            return;
                        }

                        p.c.removeItemBag(index, 1);
                        p.c.tileMap.leave(p);
                        Map map = Server.maps[138];
                        byte k;
                        for (k = 0; k < map.area.length; k++) {
                            if (map.area[k].numplayers < map.template.maxplayers) {
                                map.area[k].EnterMap0(p.c);
                                break;
                            }
                        }
                        p.endLoad(true);
                        break;
                    }//Cổ lệnh VIP
                    case 1238: {
                        if (p.c.isNhanban) {
                            p.conn.sendMessageLog(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.pk > 0) {
                            p.sendAddchatYellow("Không thể vào làng VIP khi có điểm hiếu chiến lớn hơn 0");
                            return;
                        }

                        p.c.removeItemBag(index, 1);
                        p.c.tileMap.leave(p);
                        Map map = Server.maps[167];
                        byte k;
                        for (k = 0; k < map.area.length; k++) {
                            if (map.area[k].numplayers < map.template.maxplayers) {
                                map.area[k].EnterMap0(p.c);
                                break;
                            }
                        }
                        p.endLoad(true);
                        break;
                    }
                    //Đào Kho Báu
                    case 1056: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.quantityItemyTotal(707) < 1) {
                            p.sendAddchatYellow("Cần Có bản đồ để đào");
                            return;
                        }

                        if (p.c.x >= 1216 && p.c.x <= 1321 && p.c.y == 432) {

                            if (Util.percent(100, 20)) {
                                short[] itemcau = new short[]{8, 9, 10, 11, 289, 340, 340, 383, 409, 410, 419, 436, 436, 436, 436, 436, 436, 437, 437, 438, 443, 485, 524, 567, 567, 549, 550, 551, 569, 577, 742, 781};
                                short idI = itemcau[(int) Util.nextInt(itemcau.length)];
                                Item itemup = ItemTemplate.itemDefault(idI);
                                int quantity = (int) Util.nextInt(1);
                                p.c.removeItemBag(index, 1);
                                p.c.removeItemBags(707, 1);
                                p.c.khobau++;

                                p.c.addItemBag(true, itemup);

                            } else {
                                p.sendAddchatYellow((Util.nextInt(0, 1) == 0) ? "Cần cù bù siêng năng lần này thất bại rồi" : "Lần sau không đào được thì đốt sever");
                            }
                        } else {
                            p.sendAddchatYellow("Hãy Đào báu vật ở rừng kappa ");
                        }
                        break;
                    }
                    //Ma dẫn đường
                    case 823: {
                        if (p.c.level < 150) {
                            p.sendAddchatYellow("Không thể vào Linh Cảnh khi lv thấp hơn 150");
                            return;
                        }
                        p.c.removeItemBag(index, 1);
                        p.c.tileMap.leave(p);
                        Map map = Server.maps[75];
                        byte k;
                        for (k = 0; k < map.area.length; k++) {
                            if (map.area[k].numplayers < map.template.maxplayers) {
                                map.area[k].EnterMap0(p.c);
                                break;
                            }
                        }
                        p.endLoad(true);
                        break;
                    }
                    //Khai nhãn phù
                    case 537: {
                        if (p.c.get().getEffId(40) == null) {
                            p.setEffect(41, 0, 7200000, 0);
                            p.c.removeItemBag(index, 1);
                        } else {
                            p.sendAddchatYellow("Bạn đã có hiệu quả cao hơn");
                        }
                        break;
                    }
                    //Thiên nhãn phù
                    case 538: {
                        p.setEffect(40, 0, 18000000, 0);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x3 kinh nghiệm
                    case 539: {
                        p.setEffect(32, 0, 3600000, 3);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x4 kinh nghiệm
                    case 540: {
                        p.setEffect(33, 0, 3600000, 4);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x5 kinh nghiệm
                    case 806: {
                        p.setEffect(33, 0, 3600000, 5);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x10 kinh nghiệm
                    case 807: {
                        p.setEffect(33, 0, 3600000, 10);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x20 kinh nghiệm
                    case 808: {
                        p.setEffect(33, 0, 3600000, 20);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x50 kinh nghiệm
                    case 809: {
                        p.setEffect(33, 0, 3600000, 50);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 1436: {
                        p.setEffect(33, 0, 3600000, 100);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    case 1437: {
                        p.setEffect(33, 0, 3600000, 500);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x50 7 ngày
                    case 1114: {
                        p.setEffect(44, 0, 604800000, 50);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x50 5 ngày
                    case 1115: {
                        p.setEffect(44, 0, 432000000, 50);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //x50 3 ngày
                    case 1116: {
                        p.setEffect(44, 0, 259200000, 50);
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //Giày rách, bạc, vàng
                    case 549:
                    case 550:
                    case 551: {
                        long yenup = 0L;
                        yenup = 1000000L;
                        if (item.id == 550) {
                            yenup = 2000000L;
                        }
                        if (item.id == 551) {
                            yenup = 3000000L;
                        }
                        p.c.upyenMessage(yenup);
                        p.sendAddchatYellow("Bạn nhận được " + yenup + " yên.");
                        p.c.removeItemBag(index, 1);
                        break;
                    }
                    //Lục thanh hoa
                    case 573: {
                        if (p.updateXpMounts(200, (byte) 0)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    //Tử linh liên hoa
                    case 574: {
                        if (p.updateXpMounts(400, (byte) 0)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    //Linh lang hồ điệp
                    case 575: {
                        if (p.updateXpMounts(600, (byte) 0)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    //Bánh răng
                    case 576: {
                        if (p.updateXpMounts(100, (byte) 1)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    //IK
                    case 577: {
                        if (p.updateXpMounts(250, (byte) 1)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }
                    //Thuốc cải tiến
                    case 578: {
                        if (p.updateXpMounts(500, (byte) 1)) {
                            p.c.removeItemBag(index, 1);
                        }
                        break;
                    }

                    //Rương ma quái
                    case 647: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }

                        p.c.removeItemBag(index, 1);
                        if (Util.nextInt(3) == 0) {
                            int num = (int) Util.nextInt(800000, 12000000);
                            p.c.upyenMessage(num);
                            p.sendAddchatYellow("Bạn nhận được " + num + " yên");
                        } else if (Util.nextInt(130) <= 2) {
                            p.c.addItemBag(false, ItemTemplate.itemDefault(GameSrc.arrNgocRong[(int) Util.nextInt(GameSrc.arrNgocRong.length)], false));
                        } else if (Util.nextInt(800) == 1) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(28, false));
                        } else if (Util.nextInt(300) == 0) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(383, false));
                        } else if (Util.nextInt(100) < 10) {
                            Item itemupNew = ItemTemplate.itemDefault((int) Util.nextInt(801, 802), false);
                            if (Util.nextInt(5000) == 4999) {
                                itemupNew.isExpires = false;
                                itemupNew.expires = -1l;
                            } else {
                                itemupNew.isExpires = true;
                                itemupNew.expires = (int) Util.TimeDay(GameSrc.ArrdayLuck[(int) Util.nextInt(GameSrc.ArrdayLuck.length)]);;
                            }
                            p.c.addItemBag(true, itemupNew);
                        } else if (Util.nextInt(12000) == 0) {
                            p.c.addItemBag(true, ItemTemplate.itemDefault(797, false));
                        } else {
                            short idI = UseItem.idItemRuongMaQuai[(int) Util.nextInt(UseItem.idItemRuongMaQuai.length)];
                            ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                            Item itemup;
                            if (data2.type < 10) {
                                if (data2.type == 1) {
                                    itemup = ItemTemplate.itemDefault(idI);
                                    itemup.sys = GameSrc.SysClass(data2.nclass);
                                } else {
                                    byte sys = (byte) Util.nextInt(1, 3);
                                    itemup = ItemTemplate.itemDefault(idI, sys);
                                }
                            } else {
                                itemup = ItemTemplate.itemDefault(idI);
                            }
                            itemup.isLock = false;
                            int idOp2;
                            for (Option Option : itemup.options) {
                                idOp2 = Option.id;
                                Option.param = (int) Util.nextInt(item.getOptionShopMin(idOp2, Option.param), Option.param);
                            }
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Rương 10x
                    case 895: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }

                        p.c.removeItemBag(index, 1);

                        short idI = UseItem.idItemRuong10x[(int) Util.nextInt(UseItem.idItemRuong10x.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup;
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);
                                itemup.sys = GameSrc.SysClass(data2.nclass);
                            } else {
                                byte sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault(idI, sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        itemup.isLock = false;
                        int idOp2;
                        for (Option Option : itemup.options) {
                            idOp2 = Option.id;
                            Option.param = (int) Util.nextInt(item.getOptionShopMin(idOp2, Option.param), Option.param);
                        }
                        p.c.addItemBag(true, itemup);
                        break;
                    }
                    //Rương 12x
                    case 926: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }

                        p.c.removeItemBag(index, 1);

                        short idI = UseItem.idItemRuong12x[(int) Util.nextInt(UseItem.idItemRuong12x.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup;
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);
                                itemup.sys = GameSrc.SysClass(data2.nclass);
                            } else {
                                byte sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault(idI, sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        itemup.isLock = false;
                        int idOp2;
                        for (Option Option : itemup.options) {
                            idOp2 = Option.id;
                            Option.param = (int) Util.nextInt(item.getOptionShopMin(idOp2, Option.param), Option.param);
                        }
                        p.c.addItemBag(true, itemup);
                        break;
                    }
                    case 1174: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }

                        p.c.removeItemBag(index, 1);

                        short idI = UseItem.idItemRuong6x[(int) Util.nextInt(UseItem.idItemRuong6x.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup;
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);
                                itemup.sys = GameSrc.SysClass(data2.nclass);
                            } else {
                                byte sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault(idI, sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        itemup.isLock = false;
                        int idOp2;
                        for (Option Option : itemup.options) {
                            idOp2 = Option.id;
                            Option.param = (int) Util.nextInt(item.getOptionShopMin(idOp2, Option.param), Option.param);
                        }
                        itemup.upgrade = 16;
                        p.c.addItemBag(true, itemup);
                        break;
                    }
                    //Rương hai tac
                    case 993: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }

                        p.c.removeItemBag(index, 1);

                        short idI = UseItem.idItemRuonghaitac[(int) Util.nextInt(UseItem.idItemRuonghaitac.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup;
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);
                                itemup.sys = GameSrc.SysClass(data2.nclass);
                            } else {
                                byte sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault(idI, sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        itemup.isLock = false;
                        int idOp2;
                        for (Option Option : itemup.options) {
                            idOp2 = Option.id;
                            Option.param = (int) Util.nextInt(item.getOptionShopMin(idOp2, Option.param), Option.param);
                        }
                        p.c.addItemBag(true, itemup);
                        break;
                    }
                    //cohaitac
                    case 974: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }

                        p.c.removeItemBag(index, 1);

                        short idI = UseItem.idItemcohaitac[(int) Util.nextInt(UseItem.idItemcohaitac.length)];
                        ItemTemplate data2 = ItemTemplate.ItemTemplateId(idI);
                        Item itemup;
                        if (data2.type < 10) {
                            if (data2.type == 1) {
                                itemup = ItemTemplate.itemDefault(idI);

                            } else {
                                byte sys = (byte) Util.nextInt(1, 3);
                                itemup = ItemTemplate.itemDefault(idI, sys);
                            }
                        } else {
                            itemup = ItemTemplate.itemDefault(idI);
                        }
                        itemup.isLock = false;

                        p.c.addItemBag(true, itemup);
                        break;
                    }
                    case 970: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;
                        it = ItemTemplate.itemDefault(935);
                        it1 = ItemTemplate.itemDefault(936);
                        it2 = ItemTemplate.itemDefault(937);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    case 971: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;

                        it = ItemTemplate.itemDefault(938);
                        it1 = ItemTemplate.itemDefault(939);
                        it2 = ItemTemplate.itemDefault(940);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    case 968: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;
                        it = ItemTemplate.itemDefault(941);
                        it1 = ItemTemplate.itemDefault(942);
                        it2 = ItemTemplate.itemDefault(943);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    case 972: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;
                        it = ItemTemplate.itemDefault(944);
                        it1 = ItemTemplate.itemDefault(945);
                        it2 = ItemTemplate.itemDefault(946);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    case 973: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;
                        it = ItemTemplate.itemDefault(947);
                        it1 = ItemTemplate.itemDefault(948);
                        it2 = ItemTemplate.itemDefault(949);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    case 967: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;
                        it = ItemTemplate.itemDefault(950);
                        it1 = ItemTemplate.itemDefault(951);
                        it2 = ItemTemplate.itemDefault(952);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    case 966: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;
                        it = ItemTemplate.itemDefault(953);
                        it1 = ItemTemplate.itemDefault(954);
                        it2 = ItemTemplate.itemDefault(955);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    case 965: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;
                        it = ItemTemplate.itemDefault(956);
                        it1 = ItemTemplate.itemDefault(957);
                        it2 = ItemTemplate.itemDefault(958);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    case 969: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        Item it;
                        Item it1;
                        Item it2;
                        it = ItemTemplate.itemDefault(959);
                        it1 = ItemTemplate.itemDefault(960);
                        it2 = ItemTemplate.itemDefault(961);
                        it.upgrade = 16;
                        it1.upgrade = 16;
                        it2.upgrade = 16;
                        p.c.removeItemBag(index, 1);
                        p.c.addItemBag(true, it);
                        p.c.addItemBag(true, it1);
                        p.c.addItemBag(true, it2);

                        break;
                    }
                    //Bánh chocolate
                    case 671: {
                        if (Server.manager.event != 3) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);

                        if (p.status == 1) {
                            p.updateExp(750000L);
                            if (p.c.exptype == 1) {
                                p.c.expTN += 750000 / 1000;
                            }
                        } else {
                            p.updateExp(1500000L);
                        }
                        if (Util.nextInt(10) < 4) {
                            if (p.status == 1) {
                                p.updateExp(1500000L);
                                if (p.c.exptype == 1) {
                                    p.c.expTN += 1500000 / 1000;
                                }
                            } else {
                                p.updateExp(3000000L);
                            }
                        } else if (Util.nextInt(160) <= 1) {
                            Item itemup = ItemTemplate.itemDefault((int) Util.nextInt(654, 655));
                            itemup.isLock = false;
                            p.c.addItemBag(false, itemup);
                            break;
                        } else {
                            short idI = UseItem.idItemBanhChocolate[(int) Util.nextInt(UseItem.idItemBanhChocolate.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Bánh dâu tây
                    case 672: {
                        if (Server.manager.event != 3) {
                            p.sendAddchatYellow(Language.END_EVENT);
                            return;
                        }
                        if (numbagnull < 1) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);

                        if (p.status == 1) {
                            p.updateExp(1000000L);
                            if (p.c.exptype == 1) {
                                p.c.expTN += 1000000 / 1000;
                            }
                        } else {
                            p.updateExp(2000000L);
                        }

                        int perRuong = (int) Util.nextInt(2000);
                        int rhb = (int) Util.nextInt(15000);
                        int phuonghoang = (int) Util.nextInt(10000);
                        if (Util.nextInt(10) < 3) {
                            if (p.status == 1) {
                                p.updateExp(1500000L);
                                if (p.c.exptype == 1) {
                                    p.c.expTN += 1500000 / 1000;
                                }
                            } else {
                                p.updateExp(3000000L);
                            }
                            break;
                        } else if (Util.nextInt(160) <= 1) {
                            Item itemup = ItemTemplate.itemDefault((int) Util.nextInt(652, 653));
                            itemup.isLock = false;
                            p.c.addItemBag(false, itemup);
                            break;
                        } else if (rhb == 14999) {
                            Item itemUp = new Item();
                            itemUp.id = 385;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(385).name);
                            CheckRHB.checkRHBArrayList.add(new CheckRHB(p.c.name, ItemTemplate.ItemTemplateId(385).name, Util.toDateString(Date.from(Instant.now()))));
                            return;
                        } else if (perRuong == 0) {
                            Item itemUp = new Item();
                            itemUp.id = 384;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(384).name);
                            CheckRHB.checkRHBArrayList.add(new CheckRHB(p.c.name, ItemTemplate.ItemTemplateId(384).name, Util.toDateString(Date.from(Instant.now()))));
                            return;
                        } else if (perRuong == 1 || perRuong == 2) {
                            Item itemUp = new Item();
                            itemUp.id = 383;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else if (perRuong == 4) {
                            Item itemUp = new Item();
                            itemUp.id = 340;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else if (perRuong == 6 || perRuong == 7) {
                            Item itemUp = new Item();
                            itemUp.id = 539;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else {
                            short idI = UseItem.idItemBanhDauTay[(int) Util.nextInt(UseItem.idItemBanhDauTay.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            if (idI == 781 || idI == 742 || idI == 523 || idI == 828) {
                                itemup.quantity = 1;
                                itemup.isExpires = true;
                                itemup.expires = System.currentTimeMillis() + 604800000L;
                            }
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    case 827: {
                        if (numbagnull < 1) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống.");
                            return;
                        }
                        if (p.c.level < 20) {
                            p.sendAddchatYellow("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        p.c.removeItemBag(index, 1);

                        int perRuong = (int) Util.nextInt(2000);
                        int rhb = (int) Util.nextInt(15000);
                        if (Util.nextInt(10) < 3) {
                        } else if (Util.nextInt(160) <= 1) {
                            Item itemup = ItemTemplate.itemDefault((int) Util.nextInt(652, 653));
                            itemup.isLock = false;
                            p.c.addItemBag(false, itemup);
                            break;
                        } else if (rhb == 14999) {
                            Item itemUp = new Item();
                            itemUp.id = 385;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(385).name);
                            CheckRHB.checkRHBArrayList.add(new CheckRHB(p.c.name, ItemTemplate.ItemTemplateId(385).name, Util.toDateString(Date.from(Instant.now()))));
                            return;
                        } else if (perRuong == 0) {
                            Item itemUp = new Item();
                            itemUp.id = 384;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            Manager.chatKTG("Người chơi " + p.c.name + " sử dụng " + data.name + " đã nhận được " + ItemTemplate.ItemTemplateId(384).name);
                            CheckRHB.checkRHBArrayList.add(new CheckRHB(p.c.name, ItemTemplate.ItemTemplateId(384).name, Util.toDateString(Date.from(Instant.now()))));
                            return;
                        } else if (perRuong == 1 || perRuong == 2) {
                            Item itemUp = new Item();
                            itemUp.id = 383;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else if (perRuong == 4) {
                            Item itemUp = new Item();
                            itemUp.id = 340;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else if (perRuong == 6 || perRuong == 7) {
                            Item itemUp = new Item();
                            itemUp.id = 539;
                            itemUp.quantity = 1;
                            itemUp.isExpires = false;
                            itemUp.isLock = false;
                            p.c.addItemBag(false, itemUp);
                            return;
                        } else {
                            short idI = UseItem.idItemHomBlackFriday[(int) Util.nextInt(UseItem.idItemHomBlackFriday.length)];
                            Item itemup = ItemTemplate.itemDefault(idI);
                            if (idI == 781 || idI == 742 || idI == 523 || idI == 828) {
                                itemup.quantity = 1;
                                itemup.isExpires = true;
                                itemup.expires = System.currentTimeMillis() + 604800000L;
                            }
                            itemup.isLock = item.isLock;
                            p.c.addItemBag(true, itemup);
                        }
                        break;
                    }
                    //Đá danh vọng
                    case 695:
                    case 696:
                    case 697:
                    case 698:
                    case 699:
                    case 700:
                    case 701:
                    case 702:
                    case 703:
                    case 704: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.getBagNull() < 1) {
                            p.sendAddchatYellow(Language.NOT_ENOUGH_BAG);
                            return;
                        }
                        if (item.id == 704) {
                            p.sendAddchatYellow("Vật phẩm đã đạt cấp độ tối đa.");
                            return;
                        }
                        if (item.quantity < 10) {
                            p.sendAddchatYellow("Bạn cần đủ 10 viên đá để nâng cấp.");
                            return;
                        }
                        int quantity = item.quantity;
                        int plus = item.quantity / 10;
                        p.c.removeItemBag((byte) index, quantity - quantity % 10);
                        Item itemUp = ItemTemplate.itemDefault(item.id + 1, item.isLock);
                        itemUp.quantity = plus;
                        p.c.addItemBag(true, itemUp);
                        break;
                    }
                    //Danh vọng phù
                    case 705: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.useDanhVongPhu == 0) {
                            p.conn.sendMessageLog("Số lần sử dụng Danh vọng phú của bạn hôm nay đã hết.");
                            return;
                        }
                        p.c.useDanhVongPhu--;
                        p.c.countTaskDanhVong += 5;
                        p.sendAddchatYellow("Số lần nhận nhiệm vụ Danh vọng tăng thêm 5 lần");
                        p.c.removeItemBag(index, 1);
                        break;
                    }

                    //Mảnh jirai
                    case 733:
                    case 734:
                    case 735:
                    case 736:
                    case 737:
                    case 738:
                    case 739:
                    case 740:
                    case 741: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.gender == 0) {
                            p.sendAddchatYellow("Giới tính không phù hợp.");
                            return;
                        }
                        int checkID = item.id - 733;
                        if (p.c.ItemBST[checkID] == null) {
                            if (p.c.quantityItemyTotal(item.id) < 100) {
                                p.sendAddchatYellow("Bạn không đủ mảnh để ghép.");
                                return;
                            }
                            p.c.removeItemBag(p.c.getIndexBagid(item.id, true), 100);
                            p.c.ItemBST[checkID] = ItemTemplate.itemDefault(ItemTemplate.checkIdJiraiNam(checkID));
                            p.c.ItemBST[checkID].upgrade = 1;
                            p.c.ItemBST[checkID].isLock = true;
                            p.sendAddchatYellow(ItemTemplate.ItemTemplateId(p.c.ItemBST[checkID].id).name + " đã được thêm vào bộ sưu tập.");
                        } else {
                            if (p.c.ItemBST[checkID].upgrade >= 16) {
                                p.sendAddchatYellow("Bộ sưu tập này đã đạt điểm tối đa, không thể nâng cấp thêm.");
                                return;
                            }
                            if (p.c.quantityItemyTotal(item.id) < (p.c.ItemBST[checkID].upgrade + 1) * 100) {
                                p.sendAddchatYellow("Bạn không đủ mảnh để nâng cấp.");
                                return;
                            }
                            p.c.ItemBST[checkID].upgrade += 1;
                            p.c.removeItemBag(p.c.getIndexBagid(item.id, true), p.c.ItemBST[checkID].upgrade * 100);
                            p.sendAddchatYellow(ItemTemplate.ItemTemplateId(p.c.ItemBST[checkID].id).name + " đã được nâng cấp.");
                        }
                        break;
                    }

                    //Mảnh jirai
                    case 760:
                    case 761:
                    case 762:
                    case 763:
                    case 764:
                    case 765:
                    case 766:
                    case 767:
                    case 768: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.gender == 1) {
                            p.sendAddchatYellow("Giới tính không phù hợp.");
                            return;
                        }
                        int checkID = item.id - 760;
                        if (p.c.ItemBST[checkID] == null) {
                            if (p.c.quantityItemyTotal(item.id) < 100) {
                                p.sendAddchatYellow("Bạn không đủ mảnh để ghép.");
                                return;
                            }
                            p.c.removeItemBag(p.c.getIndexBagid(item.id, true), 100);
                            p.c.ItemBST[checkID] = ItemTemplate.itemDefault(ItemTemplate.checkIdJiraiNu(checkID));
                            p.c.ItemBST[checkID].upgrade = 1;
                            p.sendAddchatYellow(ItemTemplate.ItemTemplateId(p.c.ItemBST[checkID].id).name + " đã được thêm vào bộ sưu tập.");
                        } else {
                            if (p.c.ItemBST[checkID].upgrade >= 16) {
                                p.sendAddchatYellow("Bộ sưu tập này đã đạt điểm tối đa, không thể nâng cấp thêm.");
                                return;
                            }
                            if (p.c.quantityItemyTotal(item.id) < (p.c.ItemBST[checkID].upgrade + 1) * 100) {
                                p.sendAddchatYellow("Bạn không đủ mảnh để nâng cấp.");
                                return;
                            }
                            p.c.ItemBST[checkID].upgrade += 1;
                            p.c.removeItemBag(p.c.getIndexBagid(item.id, true), p.c.ItemBST[checkID].upgrade * 100);
                            p.sendAddchatYellow(ItemTemplate.ItemTemplateId(p.c.ItemBST[checkID].id).name + " đã được nâng cấp.");
                        }
                        break;
                    }

                    //Tuần thú lệnh
                    case 743: {

                        if (p.c.level < 40) {
                            p.conn.sendMessageLog("Trình độ của bạn không đủ để sử dụng vật phẩm này.");
                            return;
                        }
                        if (p.c.tileMap.map.getXHD() != -1 || p.c.mapid == 111 || p.c.mapid == 133 || p.c.tileMap.map.mapChienTruong()) {
                            p.conn.sendMessageLog("Bạn không thể sử dụng vật phẩm này tại đây.");
                            return;
                        }
                        BossTuanLoc bossTuanLoc = new BossTuanLoc(p.c.level);
                        if (bossTuanLoc != null && bossTuanLoc.map[0] != null && bossTuanLoc.map[0].area[0] != null) {
                            p.c.removeItemBag(index, 1);
                            p.c.tileMap.leave(p);
                            bossTuanLoc.map[0].area[0].EnterMap0(p.c);
                        }
                        break;
                    }
                    //Đá thăng hoa
                    case 1280: {
                        if (p.luong < 200000) {
                            p.conn.sendMessageLog("Phí thăng hoa là 200k lượng");
                        } else if (p.c.nclass == 7) {
                            p.conn.sendMessageLog("Con đã thăng hoa rồi");
                        } else if (p.c.ItemBody[1] != null) {
                            p.conn.sendMessageLog("Con phải trả lại vũ khí trước khi thăng hoa!");
                        } else {
                            p.c.removeItemBag(index, 1);
                            p.c.nclass = 7;
                            p.c.skill.clear();
                            p.upluong(-200000L);
                            p.restSpoint();
                            Item itemUp = ItemTemplate.itemDefault(1281);
                            p.c.addItemBag(true, itemUp);
                            p.conn.sendMessageLog("Thăng hoa thành công, tự động thoát sau 5 giây nữa!");
                            int TimeSeconds = 5;
                            while (TimeSeconds > 0) {
                                TimeSeconds--;
                                Thread.sleep(1000);
                            }
                            Client.gI().kickSession(p.conn);
                        }
                        break;
                    }
                    //Rương Bos TG
                    case 1262: {
                        if (numbagnull == 0) {
                            p.conn.sendMessageLog("Hành trang không đủ chỗ trống");
                            return;
                        }
                        short[] arId = new short[]{1194, 1175, 1132, 1122, 1025, 1017, 844, 845, 1378, 1379, 1380, 1383, 1384,1385, 1386, 1387}; // iditem
                        short idI = arId[(int) Util.nextInt(arId.length)];
                        item = ItemTemplate.itemDefault(idI);
                        byte cs2 = (byte) Util.nextInt(1, 16);
                        item.upgrade = 17;
                        item.options.clear();
                        short cs = (short) Util.nextInt(10000000, 50000000);
                        short cs1 = (short) Util.nextInt(50000, 900000);
                        short cs3 = (short) Util.nextInt(1000, 20000);

                        item.options.add(new Option(82, 15000000));
                        item.options.add(new Option(83, 15000000));
                        item.options.add(new Option(87, 15000000));
                        item.options.add(new Option(92, 15000000));
                        item.options.add(new Option(58, 5000000));
                        item.options.add(new Option(94, 5000000));
                        item.options.add(new Option(80, 500000));
                        item.options.add(new Option(81, 500000));
                        item.isLock = false;
                        p.c.addItemBag(false, item);
                        p.c.removeItemBag(index, 1);
                        p.upluongMessage(5);
                        p.coin += 500000;
                        p.c.vnd += 30000;
                        p.c.atm += 10000;
                    }
                    break;
                    // hợp thể
                    case 1236: {
                        if (p.c.isNhanban) {
                            p.sendAddchatYellow(Language.NOT_FOR_PHAN_THAN);
                            return;
                        }
                        if (p.c.ishopthe == true) {
                            return;
                        }
                        if (!p.c.clone.islive) {
                            p.sendAddchatYellow("Gọi phân thân ra trước.");
                            return;
                        }
                        p.c.infocl[0] = p.c.clone.dameMax();
                        p.c.infocl[1] = p.c.clone.getMaxHP();
                        p.c.infocl[2] = p.c.clone.getMaxMP();
                        p.c.infocl[3] = p.c.clone.ResFire();
                        p.c.infocl[4] = p.c.clone.ResIce();
                        p.c.infocl[5] = p.c.clone.ResWind();
                        p.c.infocl[6] = p.c.clone.Miss();
                        p.c.infocl[7] = p.c.clone.ReactDame();
                        p.c.infocl[8] = p.c.clone.Fatal();
                        p.c.infocl[9] = p.c.clone.Exactly();
                        p.c.infocl[10] = p.c.clone.dameDown();
                        p.c.clone.off();
                        synchronized (LOCK) {
                            try {
                                m = new Message(-30);
                                m.writer().writeByte(-58);
                                m.writer().writeInt(p.c.get().id);
                                m.writer().flush();
                                p.conn.sendMessage(m);
                                m.cleanup();

                                m = new Message(-30);
                                m.writer().writeByte(-57);
                                m.writer().flush();
                                p.c.tileMap.sendMessage(m);
                                m.cleanup();

                                LOCK.wait(400L);
                                p.c.get().isGoiRong = true;
                                LOCK.wait(400L);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        p.c.ishopthe = true;
                        Service.CharViewInfo(p, true);
                        break;
                    }
                    case 1258: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 1;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh Thường");
                        } else if (p.c.typeCs == 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh Thường");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    case 1259: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 2;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh VIP");
                        } else if (p.c.typeCs != 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh VIP");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    case 1260: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 3;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh VIP x2 Tiềm Năng");
                        } else if (p.c.typeCs != 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh VIP x2 Tiềm Năng");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    case 1261: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 4;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh VIP x5 Tiềm Năng");
                        } else if (p.c.typeCs != 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh VIP x5 Tiềm Năng");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    case 1283: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 5;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh VIP x10 Tiềm Năng");
                        } else if (p.c.typeCs != 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh VIP x10 Tiềm Năng");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    case 1289: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 6;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh VIP x20 Tiềm Năng");
                        } else if (p.c.typeCs != 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh VIP x20 Tiềm Năng");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    case 1290: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 7;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh VIP x50 Tiềm Năng");
                        } else if (p.c.typeCs != 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh VIP x50 Tiềm Năng");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    case 1291: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 8;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh VIP x100 Tiềm Năng");
                        } else if (p.c.typeCs != 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh VIP x100 Tiềm Năng");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    case 1292: {
                        if (p.c.typeCs == 0) {
                            p.c.typeCs = 9;
                            p.conn.sendMessageLog("Bật tự động chuyển sinh VIP x200 Tiềm Năng");
                        } else if (p.c.typeCs != 0) {
                            p.conn.sendMessageLog("Tắt tự động chuyển sinh VIP x200 Tiềm Năng");
                            p.c.typeCs = 0;
                        }
                        break;
                    }
                    default: {
                        break;
                    }
                }

                return;
            }

            if (ItemTemplate.checkIdNewItems(item.id)) {
                if (ItemTemplate.checkIdNewWP(item.id) != -1) {
                    p.c.get().ID_WEA_PONE = ItemTemplate.idNewItemWP[1][ItemTemplate.checkIdNewWP(item.id)];
                } else if (ItemTemplate.checkIdNewMatNa(item.id) != -1) {
                    p.c.get().ID_MAT_NA = ItemTemplate.idNewItemMatNa[1][ItemTemplate.checkIdNewMatNa(item.id)];
                } else if (ItemTemplate.checkIdNewMounts(item.id) != -1) {
                    p.c.get().ID_HORSE = ItemTemplate.idNewItemMounts[1][ItemTemplate.checkIdNewMounts(item.id)];
                } else if (ItemTemplate.checkIdNewBienHinh(item.id) != -1) {
                    p.c.get().ID_Bien_Hinh = ItemTemplate.idNewItemBienHinh[1][ItemTemplate.checkIdNewBienHinh(item.id)];
                } else if (ItemTemplate.checkIdNewCaiTrang(item.id) != -1) {
                    p.c.get().ID_HAIR = ItemTemplate.idNewItemCaiTrang[1][ItemTemplate.checkIdNewCaiTrang(item.id)];
                    p.c.get().ID_Body = ItemTemplate.idNewItemCaiTrang[2][ItemTemplate.checkIdNewCaiTrang(item.id)];
                    p.c.get().ID_LEG = ItemTemplate.idNewItemCaiTrang[3][ItemTemplate.checkIdNewCaiTrang(item.id)];
                }
                p.sendInfoMeNewItem();
            } else if (ItemTemplate.checkIdNewYoroi(item.id) != -1) {
                p.c.get().ID_PP = ItemTemplate.idNewItemYoroi[1][ItemTemplate.checkIdNewYoroi(item.id)];
                p.sendInfoMeNewItem();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (m != null) {
                m.cleanup();
            }
        }
    }

    public static void useItemChangeMap(Player p, Message m) {
        try {
            byte indexUI = m.reader().readByte();
            byte indexMenu = m.reader().readByte();
            m.cleanup();
            Item item = p.c.ItemBag[indexUI];
            if (item != null && (item.id == 37 || item.id == 35)) {
                if (item.id != 37) {
                    p.c.removeItemBag(indexUI);
                }
                if (p.c.mapid == 111 || p.c.mapid == 133) {
                    p.sendAddchatYellow("Không thể sử dụng chức năng này tại đây");
                    return;
                }
                if (indexMenu == 0 || indexMenu == 1 || indexMenu == 2) {
                    Map ma = Manager.getMapid(Map.arrTruong[indexMenu]);
                    if (ma == null) {
                        return;
                    }
                    for (TileMap area : ma.area) {
                        if (area.numplayers < ma.template.maxplayers) {
                            p.c.tileMap.leave(p);
                            area.EnterMap0(p.c);
                            return;
                        }
                    }
                }
                if (indexMenu == 3 || indexMenu == 4 || indexMenu == 5 || indexMenu == 6 || indexMenu == 7 || indexMenu == 8 || indexMenu == 9) {
                    Map ma = Manager.getMapid(Map.arrLang[indexMenu - 3]);
                    if (ma == null) {
                        return;
                    }
                    for (TileMap area : ma.area) {
                        if (area.numplayers < ma.template.maxplayers) {
                            p.c.tileMap.leave(p);
                            area.EnterMap0(p.c);
                            return;
                        }
                    }
                }
            }
            p.c.get().upDie();
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (m != null) {
                m.cleanup();

            }
        }

    }

    public static class idItemNVTruyenTin {

        public static int length;

        public idItemNVTruyenTin() {
        }
    }

}
