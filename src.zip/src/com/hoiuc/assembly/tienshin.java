
package com.hoiuc.assembly;

/**
 *
 * @author Admin
 */
public class tienshin {
    public static String Đôi_Lời = "Scr Kỷ Niệm Hồi Ức được mua và phát triển từ tháng 1 2021."
            + " Lưu giữ lại chút kỷ niệm về con game tuổi thơ này.";
   
}
