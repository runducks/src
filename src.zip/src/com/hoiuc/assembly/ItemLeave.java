package com.hoiuc.assembly;
//Scr By SHIN

import com.hoiuc.io.Util;
import com.hoiuc.server.AIManager;
import com.hoiuc.stream.Server;
//Scr By SHIN

public class ItemLeave {

    public static short[] arrTrangBiXeSoi = new short[]{439, 440, 441, 442, 488, 489, 487, 486};
    public static short[] arrExpXeSoi = new short[]{573, 574, 575, 576, 577, 578};
    public static short[] arrtiemnang = new short[]{770, 1237};
    public static short[] arrvip4 = new short[]{770, 1263};
    public static short[] arrvip5 = new short[]{770, 1264};
    public static short[] arrvip20 = new short[]{770, 1282};
    public static short[] arrvip100 = new short[]{770, 1288};
    public static short[] arrItemOrther = new short[]{547};
    public static short[] arrItemSuKienHe = new short[]{428, 429, 430, 431, 1256};
    public static short[] arrItemKhobau = new short[]{706, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1256};
    public static short[] arrItemHe = new short[]{1149, 1150, 1151, 1152, 1153, 1154, 1155, 1156, 1157, 1256};
    public static short[] arrItemSuKienbamuoithangtu = new short[]{919, 920, 921, 922, 923, 1256};
    public static short[] arrItemSuKienTrungThu = new short[]{298, 299, 300, 301};
    public static short[] arrItemSuKienNsoTruong = new short[]{648, 649, 650, 651, 1256};
    public static short[] arrItemSuKienNoel = new short[]{666, 667, 668, 1256};
    public static short[] arrItemLv90 = new short[]{618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637};
    public static short[] arrItemSuKienTetNguyenDan = new short[]{638, 639, 641, 642, 646, 645, 1256};
    public static short[] arrItemGioTo = new short[]{590, 591, 525, 526, 527, 528, 529, 531, 530, 1256};
    public static short[] arrItemBOSS = new short[]{275, 276, 277, 278, 443, 443, 443, 485, 485, 524, 454, 454, 456, 456, 455, 455, 455, 455, 455, 596, 601, 776, 777, 828, 798, 523, 457};
    public static short[] arrItemBOSSTG = new short[]{275, 276, 277, 278, 443, 443, 443, 485, 485, 524, 454, 454, 456, 456, 455, 455, 455, 455, 455, 596, 601, 776, 777, 828, 798, 523, 457, 1262};
    public static short[] arrItemBOSSTuanLoc = new short[]{897, 523, 443, 547};
    public static short[] arrItemLDGT = new short[]{8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10};
    public static short[] arrItemBOSSChuot = new short[]{8, 8, 9, 9, 674, 674, 674, 674, 674, 514, 514, 514, 382, 596, 601};
    public static short[] arrItemBOSST = new short[]{8, 8, 9, 9, 674, 674, 674, 674, 674, 514, 514, 514, 382, 596, 601};
    public static short[] arrItemChienTruong = new short[]{8, 8, 9, 9, 674, 674, 674, 674, 674, 514, 514, 514, 382, 596, 601};
    public static short[] arrSVC6x = new short[]{311, 312, 313, 314, 315, 316};
    public static short[] arrSVC7x = new short[]{375, 376, 377, 378, 379, 380};
    public static short[] arrSVC8x = new short[]{552, 553, 554, 555, 556, 557};
    public static short[] arrSVC10x = new short[]{558, 559, 560, 561, 562, 563};
    public static short[] RUONGSVC15X = new short[]{1372};
    public static short[] RUONG12X = new short[]{1373};
    public static short[] RUONGVK10X = new short[]{1374};
    public static short[] RUONGDANHHIEU = new short[]{1375};
    public static short[] arrItemSuKienDuaHau = new short[]{677, 678, 679};// vật phẩm sự kiện
    public static short[] NLXD = new short[]{1417, 1418, 1419, 1420, 1421, 1422};
    public static short[] do9xLangCo = new short[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 618, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 619, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 620, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 621, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 622, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 623, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 624, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 625, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 626, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 627, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 628, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 629, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 630, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 631, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 632, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 633, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 634, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 635, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 636, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 637, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,};

    public static void randomLeave(TileMap place, Mob mob3, int master, int per, int map) {
        switch (per) {
            case 1: {
                if (map == 1) {
                    leaveEXPLangCo(place, mob3, master);
                } else if (map == 0) {
                    leaveEXPVDMQ(place, mob3, master);
                }
                break;
            }
            case 2: {
                if (map == 1) {
                    leaveTTTLangCo(place, mob3, master);
                } else if (map == 0) {
                    leaveTTTVDMQ(place, mob3, master);
                }
                break;
            }
            case 3: {
                if (map == 1) {
                    leaveTrangBiThuCuoiLangCo(place, mob3, master);
                }
                break;
            }
//            case 4: {
//                if (map == 1) {
//                    leaveTrangBiLangCo(place, mob3, master);
//                }
//                break;
//            }
            default: {
                break;
            }
        }
    }

    public static void randomLeavevip(TileMap place, Mob mob3, int master, int per, int map) {
        switch (per) {
            case 1: {
                if (map == 1) {
                    leavevip(place, mob3, master);
                } else if (map == 0) {
                    leavetiemnang(place, mob3, master);
                }
                break;
            }

//            
            default: {
                break;
            }
        }
    }

    public static void randomLeavevip4(TileMap place, Mob mob3, int master, int per, int map) {
        switch (per) {
            case 1: {
                if (map == 1) {
                    leavevip(place, mob3, master);
                } else if (map == 0) {
                    leavevip4(place, mob3, master);
                }
                break;
            }

//            
            default: {
                break;
            }
        }
    }

    public static void randomLeavevip5(TileMap place, Mob mob3, int master, int per, int map) {
        switch (per) {
            case 1: {
                if (map == 1) {
                    leavevip(place, mob3, master);
                } else if (map == 0) {
                    leavevip5(place, mob3, master);
                }
                break;
            }

//            
            default: {
                break;
            }
        }
    }

    public static void randomLeavevip20(TileMap place, Mob mob3, int master, int per, int map) {
        switch (per) {
            case 1: {
                if (map == 1) {
                    leavevip(place, mob3, master);
                } else if (map == 0) {
                    leavevip20(place, mob3, master);
                }
                break;
            }

//            
            default: {
                break;
            }
        }
    }

    public static void randomLeavevip100(TileMap place, Mob mob3, int master, int per, int map) {
        switch (per) {
            case 1: {
                if (map == 1) {
                    leavevip(place, mob3, master);
                } else if (map == 0) {
                    leavevip100(place, mob3, master);
                }
                break;
            }

//            
            default: {
                break;
            }
        }
    }

    public static void addOption(Item item, int id, int param) {
        Option option = new Option(id, param);
        item.options.add(option);
    }

    public static void randomLeavenlxd(TileMap place, Mob mob3, int master, int per, int map) {
        if (per == 1 && map == 0) {
            Leavenlxd(place, mob3, master);
        }
    }

    public static void Leavenlxd(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int random = Util.nextInt(1000);
            if (random < 10) {
                im = place.LeaveItem(NLXD[Util.nextInt(NLXD.length)], mob3.x, mob3.y, mob3.templates.type, true);
            }
        } catch (Exception e) {
        }
        if (im != null) {
            im.item.isLock = true;
            im.item.quantity = 1;
            im.master = master;
        }
    }

    public static void leaveItemSuKien(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        int per = (int) Util.nextInt(5);
        try {
            switch (Server.manager.event) {
                case 1: {
                    if (per == 0) {
                        im = place.LeaveItem(arrItemSuKienHe[(int) Util.nextInt(arrItemSuKienHe.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }
                    break;
                }
                case 2: {
                    if (per < 0) {
                        im = place.LeaveItem(arrItemSuKienTrungThu[(int) Util.nextInt(arrItemSuKienTrungThu.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }
                    break;
                }
                case 3: {
                    if (per == 0) {
                        im = place.LeaveItem(arrItemSuKienNoel[(int) Util.nextInt(arrItemSuKienNoel.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }
                    break;
                }
                case 4: {
                    if (per == 0) {
                        im = place.LeaveItem(arrItemSuKienTetNguyenDan[(int) Util.nextInt(arrItemSuKienTetNguyenDan.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }
                    if (per == 3) {
                        im = place.LeaveItem(arrItemSuKienDuaHau[(int) Util.nextInt(arrItemSuKienDuaHau.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }// chạy song song với sk tết
                    break;
                }
                case 5: {
                    if (per == 0) {
                        im = place.LeaveItem(arrItemGioTo[(int) Util.nextInt(arrItemGioTo.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }
                    break;
                }
                case 6: {
                    if (per == 0) {
                        im = place.LeaveItem(arrItemSuKienbamuoithangtu[(int) Util.nextInt(arrItemSuKienbamuoithangtu.length)], mob3.x, mob3.y, mob3.templates.type, true);
                    }
                    break;
                }
                case 7: {
                    if (per < 2) {
                        im = place.LeaveItem(arrItemKhobau[(int) Util.nextInt(arrItemKhobau.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }
                    break;
                }
                case 8: {
                    if (per < 1) {
                        im = place.LeaveItem(arrItemHe[(int) Util.nextInt(arrItemHe.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }
                    break;
                }
                case 9: {
                    if (per < 1) {
                        im = place.LeaveItem(arrItemSuKienNsoTruong[(int) Util.nextInt(arrItemSuKienNsoTruong.length)], mob3.x, mob3.y, mob3.templates.type, true);
                    }
                    if (per == 3) {
                        im = place.LeaveItem(arrItemSuKienDuaHau[(int) Util.nextInt(arrItemSuKienDuaHau.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }// chạy song song 
                    break;
                }
                case 10: {
                    if (per == 3) {
                        im = place.LeaveItem(arrItemSuKienDuaHau[(int) Util.nextInt(arrItemSuKienDuaHau.length)], mob3.x, mob3.y, mob3.templates.type, false);
                    }
                    break;
                }
                default: {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.quantity = 1;
            im.item.isLock = true;
            im.master = master;
        }
    }

    public static void leaveItemOrther(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        int percent = (int) Util.nextInt(arrItemOrther.length);
        try {
            if (arrItemOrther[percent] != -1) {
                switch (arrItemOrther[percent]) {
                    case 10000: {
                        if (mob3.level < 30) {
                            im = place.LeaveItem((short) 14, mob3.x, mob3.y, mob3.templates.type, false);
                        } else if (mob3.level >= 30 && mob3.level < 50) {
                            im = place.LeaveItem((short) 15, mob3.x, mob3.y, mob3.templates.type, false);
                        } else if (mob3.level >= 50 && mob3.level < 70) {
                            im = place.LeaveItem((short) 16, mob3.x, mob3.y, mob3.templates.type, false);
                        } else if (mob3.level >= 70) {
                            im = place.LeaveItem((short) 17, mob3.x, mob3.y, mob3.templates.type, false);
                        }
                        break;
                    }
                    case 10001: {
                        if (mob3.level < 30) {
                            im = place.LeaveItem((short) 19, mob3.x, mob3.y, mob3.templates.type, false);
                        } else if (mob3.level >= 30 && mob3.level < 50) {
                            im = place.LeaveItem((short) 20, mob3.x, mob3.y, mob3.templates.type, false);
                        } else if (mob3.level >= 50 && mob3.level < 70) {
                            im = place.LeaveItem((short) 21, mob3.x, mob3.y, mob3.templates.type, false);
                        } else if (mob3.level >= 70) {
                            im = place.LeaveItem((short) 22, mob3.x, mob3.y, mob3.templates.type, false);
                        }
                        break;
                    }
                    case 4: {
                        im = place.LeaveItem((short) 4, mob3.x, mob3.y, mob3.templates.type, false);
                        break;
                    }
                    case 5: {
                        im = place.LeaveItem((short) 5, mob3.x, mob3.y, mob3.templates.type, false);
                        break;
                    }
                    case 6: {
                        im = place.LeaveItem((short) 6, mob3.x, mob3.y, mob3.templates.type, false);
                        break;
                    }
                    case 7: {
                        im = place.LeaveItem((short) 7, mob3.x, mob3.y, mob3.templates.type, false);
                        break;
                    }
                    case 38: {
                        im = place.LeaveItem((short) 38, mob3.x, mob3.y, mob3.templates.type, false);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.quantity = 1;
            im.item.isLock = false;
            im.master = master;
        }
    }

    public static void leaveYen(TileMap place, Mob mob3, int master) {
        try {
            ItemMap im = place.LeaveItem((short) 12, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
            if (im != null) {
                im.item.quantity = 0;
                im.item.isLock = false;
                im.master = master;
                im.checkMob = mob3.lvboss;
                if (mob3.isboss) {
                    im.checkMob = 4;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leaveChiaKhoa(TileMap place, Mob mob3, int master) {
        try {
            ItemMap im = place.LeaveItem((short) 260, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
            if (im != null) {
                im.item.quantity = 1;
                im.item.isLock = true;
                im.master = master;
                im.item.isExpires = true;
                im.item.expires = place.map.timeMap;
                im.checkMob = mob3.lvboss;
                if (mob3.isboss) {
                    im.checkMob = 4;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leaveLDGT(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            if (mob3.templates.id == 81) {
                int per = (int) Util.nextInt(10);
                if (per < 4) {
                    im = place.LeaveItem((short) 261, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                    if (im != null) {
                        im.item.quantity = 1;
                        im.item.isLock = true;
                        im.master = master;
                        im.item.isExpires = true;
                        im.item.expires = place.map.timeMap;
                    }
                }
            } else if (mob3.templates.id == 82) {
                int i;
                for (i = 0; i < arrItemLDGT.length; i++) {
                    im = place.LeaveItem((short) arrItemLDGT[i], mob3.x, mob3.y, mob3.templates.type, true);
                    if (im != null) {
                        im.item.quantity = 1;
                        im.item.isLock = false;
                        im.master = master;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leaveTrangBiThuCuoiVDMQ(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentTB = (int) Util.nextInt(100);
            int perCentArr = (int) Util.nextInt(arrTrangBiXeSoi.length);
            if (perCentTB < 1) {
                im = place.LeaveItem((short) arrTrangBiXeSoi[perCentArr], mob3.x, mob3.y, mob3.templates.type, false);
                im.item.quantity = 1;
                im.item.isLock = false;
                im.master = master;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leaveTrangBiThuCuoiLangCo(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentTB = (int) Util.nextInt(650);
            if (perCentTB == 0) {
                im = place.LeaveItem((short) 524, mob3.x, mob3.y, mob3.templates.type, false);
            } else if (perCentTB == 1) {
                int perCentArr = (int) Util.nextInt(arrTrangBiXeSoi.length);
                im = place.LeaveItem(arrTrangBiXeSoi[perCentArr], mob3.x, mob3.y, mob3.templates.type, false);
            } else if (perCentTB >= 5 && perCentTB < 10) {
                im = place.LeaveItem((short) 545, mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.quantity = 1;
            im.item.isLock = false;
            im.master = master;
        }
    }

//    public static void leaveTrangBiLangCo(Place place, Mob mob3, int master) {
//        ItemMap im = null;
//        try {
//            int perCentTB = Util.nextInt()(100);
//            int perCentArr = Util.nextInt()(arrItemLv90.length);
//            if(perCentTB<5) {
//                im = place.LeaveItem((short) arrItemLv90[perCentArr], mob3.x, mob3.y, mob3.templates.type, false);
//
//                im.item.quantity = 1;
//                im.item.isLock = false;
//                im.master = master;
//            }
//        } catch (Exception e) {}
//    }
    public static void leavevip(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentEXP = (int) Util.nextInt(150);
            if (perCentEXP < 7) {
                im = place.LeaveItem((short) arrItemLv90[(int) Util.nextInt(arrItemLv90.length)], mob3.x, mob3.y, mob3.templates.type, false);
                if (im != null) {
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(100, 100000);
                    long d = Util.nextInt(1000, 10000000);
                    long cm = Util.nextInt(1000, 10000);
                    Option op = new Option(58, (int) Tn);
                    im.item.options.add(op);
                    Option op1 = new Option(94, (int) Tn);
                    im.item.options.add(op1);
                    Option op2 = new Option(87, (int) d);
                    im.item.options.add(op2);
                    Option op3 = new Option(92, (int) cm);
                    im.item.options.add(op3);
                    im.master = master;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = false;
            im.item.quantity = 1;
            im.master = master;
        }
    }

    public static void leaveEXPLangCo(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentEXP = (int) Util.nextInt(150);
            if (perCentEXP < 7) {
                im = place.LeaveItem((short) arrExpXeSoi[(int) Util.nextInt(arrExpXeSoi.length)], mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = false;
            im.item.quantity = 1;
            im.master = master;
        }
    }

    public static void leaveEXPVDMQ(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentEXP = (int) Util.nextInt(375);
            if (perCentEXP < 5) {
                im = place.LeaveItem(arrExpXeSoi[(int) Util.nextInt(arrExpXeSoi.length)], mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = false;
            im.item.quantity = 1;
            im.master = master;
        }
    }

    public static void leavetiemnang(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentEXP = (int) Util.nextInt(375);
            if (perCentEXP < 20) {
                im = place.LeaveItem(arrtiemnang[(int) Util.nextInt(arrtiemnang.length)], mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = true;
            im.item.quantity = 1;
            im.master = -1;
        }
    }

    public static void leavevip4(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentEXP1 = (int) Util.nextInt(375);
            if (perCentEXP1 < 20) {
                im = place.LeaveItem(arrvip4[(int) Util.nextInt(arrvip4.length)], mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = true;
            im.item.quantity = 1;
            im.master = -1;
        }
    }

    public static void leavevip5(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentEXP = (int) Util.nextInt(375);
            if (perCentEXP < 20) {
                im = place.LeaveItem(arrvip5[(int) Util.nextInt(arrvip5.length)], mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = true;
            im.item.quantity = 1;
            im.master = -1;
        }
    }

    public static void leavevip20(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentEXP = (int) Util.nextInt(200);
            if (perCentEXP < 50) {
                im = place.LeaveItem(arrvip20[(int) Util.nextInt(arrvip20.length)], mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = true;
            im.item.quantity = 1;
            im.master = -1;
        }
    }

    public static void leavevip100(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentEXP = (int) Util.nextInt(375);
            if (perCentEXP < 20) {
                im = place.LeaveItem(arrvip100[(int) Util.nextInt(arrvip100.length)], mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = true;
            im.item.quantity = 1;
            im.master = -1;
        }
    }

    public static void leaveTTTLangCo(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            int perCentTTT = (int) Util.nextInt(410);
            if (perCentTTT >= 100 && perCentTTT <= 105) {
                //Tinh thạch sơ
                im = place.LeaveItem((short) 455, mob3.x, mob3.y, mob3.templates.type, false);
            } else if (perCentTTT >= 190 && perCentTTT <= 194) {
                //tinh thạch trung
                im = place.LeaveItem((short) 456, mob3.x, mob3.y, mob3.templates.type, false);
            } else if (perCentTTT < 1) {
                //Chuyển tinh thạch
                im = place.LeaveItem((short) 454, mob3.x, mob3.y, mob3.templates.type, false);
            } else if (Util.nextInt(2000) == 1999) {
                //tinh thạch cao
                im = place.LeaveItem((short) 457, mob3.x, mob3.y, mob3.templates.type, false);
            } else if (perCentTTT < 1) {
                im = place.LeaveItem((short) do9xLangCo[(int) Util.nextInt(do9xLangCo.length)], mob3.x, mob3.y, mob3.templates.type, false);
                if (im != null) {
                    im.item.isLock = true;
                    im.item.quantity = 1;
                    im.master = master;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = false;
            im.item.quantity = 1;
            im.master = master;
        }
    }

    public static void leaveTTTT(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            if (Util.nextInt(10) < 3) {
                //tinh thạch trung
                im = place.LeaveItem((short) 456, mob3.x, mob3.y, mob3.templates.type, false);
                if (im != null) {
                    im.item.isLock = false;
                    im.item.quantity = 1;
                    im.master = master;
                }
            }
            im = place.LeaveItem((short) 455, mob3.x, mob3.y, mob3.templates.type, false);
            if (im != null) {
                im.item.isLock = false;
                im.item.quantity = 1;
                im.master = master;
            }

            im = place.LeaveItem((short) arrExpXeSoi[(int) Util.nextInt(arrExpXeSoi.length)], mob3.x, mob3.y, mob3.templates.type, false);
            if (im != null) {
                im.item.isLock = false;
                im.item.quantity = 1;
                im.master = master;
            }
            im = place.LeaveItem((short) arrExpXeSoi[(int) Util.nextInt(arrExpXeSoi.length)], mob3.x, mob3.y, mob3.templates.type, false);
            if (im != null) {
                im.item.isLock = false;
                im.item.quantity = 1;
                im.master = master;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void leaveTTTVDMQ(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        try {
            long perCentTTT = Util.nextInt(2850);
            if (perCentTTT >= 100 && perCentTTT <= 115) {
                //tinh thạch sơ
                im = place.LeaveItem((short) 455, mob3.x, mob3.y, mob3.templates.type, false);
            } else if (perCentTTT < 1 || perCentTTT < 1) {
                //tinh thạch trung
                im = place.LeaveItem((short) 456, mob3.x, mob3.y, mob3.templates.type, false);
            } else if (perCentTTT < 1) {
                //Chuyển tinh thạch
                im = place.LeaveItem((short) 454, mob3.x, mob3.y, mob3.templates.type, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (im != null) {
            im.item.isLock = false;
            im.item.quantity = 1;
            im.master = master;
        }
    }

    public static void leaveItemBOSS(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        int i;
        try {
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1190, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                        im.checkMob = 4;
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1191, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1192, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1193, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1194, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1202, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1203, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1298, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1299, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1300, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1301, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1302, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 5000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1303, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1304, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1305, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1306, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1307, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1204, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 5) {
                im = place.LeaveItem((short) 1205, mob3.x, mob3.y, mob3.templates.type, mob3.isboss);
                if (im != null) {
                    if (mob3.isboss) {
                    }
                    long sys1 = Util.nextInt(1, 3);
                    im.item.quantity = 1;
                    im.item.upgrade = 17;
                    im.item.sys = (byte) sys1;
                    im.item.isLock = false;
                    im.item.isExpires = false;
                    im.item.expires = -1L;
                    long Tn = Util.nextInt(500000, 4000000);
                    Option op = new Option(58, (int) Tn);
                    Option op1 = new Option(94, (int) Tn);

                    im.item.options.add(op);  // Thêm Option 58
                    im.item.options.add(op1); // Thêm Option 94

                    im.master = master;
                }
            }
            //Booss TG   
            if (place.map.id == 56) {
                for (i = 0; i < arrItemBOSSTG.length; i++) {
                    im = place.LeaveItem(arrItemBOSSTG[i], mob3.x, mob3.y, mob3.templates.type, true);
                    if (im != null) {
                        im.item.quantity = 1;
                        im.item.isLock = true;
                        im.master = -1;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leaveItemBOSSTuanLoc(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        int i;
        try {

            for (i = 0; i < arrItemBOSSTuanLoc.length; i++) {
                im = place.LeaveItem(arrItemBOSSTuanLoc[i], mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }
            }
            switch ((int) Util.nextInt(1, 4)) {
                case 1: {
                    for (i = 0; i < arrSVC6x.length; i++) {
                        im = place.LeaveItem(arrSVC6x[i], mob3.x, mob3.y, mob3.templates.type, true);
                        if (im != null) {
                            im.item.quantity = 1;
                            im.item.isLock = false;
                            im.master = -1;
                        }
                    }
                    break;
                }
                case 2: {
                    for (i = 0; i < arrSVC7x.length; i++) {
                        im = place.LeaveItem(arrSVC7x[i], mob3.x, mob3.y, mob3.templates.type, true);
                        if (im != null) {
                            im.item.quantity = 1;
                            im.item.isLock = false;
                            im.master = -1;
                        }
                    }
                    break;
                }
                case 3: {
                    for (i = 0; i < arrSVC8x.length; i++) {
                        im = place.LeaveItem(arrSVC8x[i], mob3.x, mob3.y, mob3.templates.type, true);
                        if (im != null) {
                            im.item.quantity = 1;
                            im.item.isLock = false;
                            im.master = -1;
                        }
                    }
                    break;
                }
                case 4: {
                    for (i = 0; i < arrSVC10x.length; i++) {
                        im = place.LeaveItem((short) arrSVC10x[i], mob3.x, mob3.y, mob3.templates.type, true);
                        if (im != null) {
                            im.item.quantity = 1;
                            im.item.isLock = false;
                            im.master = -1;
                        }
                    }
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leaveItemBOSSChuot(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        int i;
        try {
            if (Util.nextInt(10) < 1) {
                im = place.LeaveItem((short) 383, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 1) {
                im = place.LeaveItem((short) 384, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 2) {
                im = place.LeaveItem((short) 547, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }

                im = place.LeaveItem((short) 547, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }

                im = place.LeaveItem((short) 545, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }

                im = place.LeaveItem((short) 545, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leaveItemBOSST(TileMap place, Mob mob3, int master) {
        ItemMap im = null;
        int i;
        try {
            if (Util.nextInt(10) < 1) {
                im = place.LeaveItem((short) 383, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 1) {
                im = place.LeaveItem((short) 384, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }
            }
            if (Util.nextInt(10) < 2) {
                im = place.LeaveItem((short) 547, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }

                im = place.LeaveItem((short) 547, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }

                im = place.LeaveItem((short) 545, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }

                im = place.LeaveItem((short) 545, mob3.x, mob3.y, mob3.templates.type, true);
                if (im != null) {
                    im.item.quantity = 1;
                    im.item.isLock = false;
                    im.master = master;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void leaveitembot(TileMap place, short itid, short x, short y, int i) {
        try {
            ItemMap im = place.LeaveItem(itid, x, y, (byte) 1, false);
            if (im != null) {
                im.item.quantity = 1;
                im.item.isLock = false;
                im.master = -1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
