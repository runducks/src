package com.hoiuc.assembly;
//Scr By SHIN
public class Friend {
    public String friendName;
    public byte type;
//Scr By SHIN
    public Friend(String friendName, byte type) {
        this.friendName = friendName;
        this.type = type;
    }
}
