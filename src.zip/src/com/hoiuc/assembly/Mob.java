package com.hoiuc.assembly;
//Scr By SHIN

import com.hoiuc.io.Util;
import com.hoiuc.server.Service;
import com.hoiuc.server.Session;
import com.hoiuc.stream.ChienTruong;
import com.hoiuc.stream.Client;
import com.hoiuc.stream.Server;
import com.hoiuc.template.MobTemplate;
//Scr By SHIN
import java.util.ArrayList;
import java.util.HashMap;
//Scr By SHIN

public class Mob {

    public boolean isFire;
    public boolean isIce;
    public boolean isWind;
    public long timeFire;
    public long timeIce;
    public long timeWind;
    public int id;
    public byte sys;
    public double hp;
    public int level;
    public double hpmax;
    public short x;
    public short y;
    public byte status;
    public int lvboss;
    public int dameFire;
    public long timeDameFire;
    public boolean isboss;
    public boolean isDie;
    public boolean isRefresh;
    public long xpup;
    public long timeRefresh;
    public long timeFight;
    public long timeDisable;
    public long timeDontMove;
    public boolean isDisable;
    public boolean isDontMove;
    public TileMap tileMap;
    public int idCharSkill25;
    public MobTemplate templates;
    private HashMap<Integer, Integer> nFight;
    private ArrayList<Character> sortFight;

    private static int[] arrMobLangCoId = new int[]{148, 146, 147, 148, 149, 151, 152, 154, 155, 156, 157, 159};
    private static int[] arrMobChienTruongId = new int[]{90, 91, 92, 93, 94, 95, 96, 97, 98, 99};
    private static int[] arrMobLangvip = new int[]{174, 175, 176, 179, 180};

    public Mob(int id, int idtemplate, int level, TileMap tileMap) {
        this.isRefresh = true;
        this.id = id;
        this.templates = MobTemplate.entrys.get(idtemplate);
        this.level = level;
        double hp = this.templates.hp;
        this.hpmax = hp;
        this.hp = hp;
        this.xpup = 10000L;
        this.isDie = false;
        this.dameFire = 0;
        this.timeDameFire = -1L;
        this.timeFire = -1L;
        this.nFight = new HashMap<Integer, Integer>();
        this.sortFight = new ArrayList<Character>();
        this.timeDisable = -1L;
        this.timeDontMove = -1L;
        this.isDisable = false;
        this.isDontMove = false;
        this.tileMap = tileMap;
        this.idCharSkill25 = -1;
    }

    public void setSkill25() {
        this.timeDameFire = -1L;
        this.dameFire = 0;
        this.timeFire = -1L;
        this.idCharSkill25 = -1;
    }

    public boolean checkMobLangCo() {
        int i;
        for (i = 0; i < Mob.arrMobLangCoId.length; i++) {
            if (this.templates.id == Mob.arrMobLangCoId[i]) {
                return true;
            }
        }
        return false;
    }

    public boolean checkMobLangvip() {
        int i;
        for (i = 0; i < Mob.arrMobLangvip.length; i++) {
            if (this.templates.id == Mob.arrMobLangvip[i]) {
                return true;
            }
        }
        return false;
    }

    public boolean checkMobChienTruong() {
        if (this.templates.id >= 90 && this.templates.id <= 99) {
            return true;
        }
        return false;
    }

    public void updateHP(double num, int _charId, boolean liveAttack) {
        this.hp += num;
        Char _char = this.tileMap.getNinja(_charId);
        if (!liveAttack) {
            if (_char != null) {
                this.Fight(_char.p.conn.id, Math.abs((int) num));
            }
        }
        if (this.hp <= 0) {
            this.hp = 0;
            this.status = 0;
            this.isDie = true;
            if (this.isRefresh) {
                this.timeRefresh = System.currentTimeMillis() + 7000L;
            }
            if (this.isRefresh && this.checkMobLangCo()) {
                this.timeRefresh = System.currentTimeMillis() + 7000L;
            } else if (this.isRefresh && this.checkMobLangvip()) {
                this.timeRefresh = System.currentTimeMillis() + 7000L;
            } else if (this.isRefresh && this.checkMobChienTruong()) {
                this.timeRefresh = System.currentTimeMillis() + 7000L;
            } else if (this.isRefresh && this.tileMap.map.getXHD() == 9) {
                this.timeRefresh = System.currentTimeMillis() + 7000L;
            }
            if (this.isboss) {
                if (this.templates.id != 198 && this.templates.id != 199 && this.templates.id != 200 && this.templates.id != 162) {
                    this.isRefresh = false;
                    this.timeRefresh = -1L;
                } else {
                    this.timeRefresh = System.currentTimeMillis() + 6000L;
                }
            }
            if (_char != null) {
                synchronized (this) {
                    this.handleAfterCharFight(_char);
                }
            }
        }
    }

    public void ClearFight() {
        this.nFight.clear();
    }

    public int sortNinjaFight() {
        int idN = -1;
        int dameMax = 0;
        int dame;
        Session conn;
        for (int value : this.nFight.keySet()) {
            dame = this.nFight.get(value);
            conn = Client.gI().getConn(value);
            if (conn != null && conn.player != null && conn.player.c != null) {
                if (dame <= dameMax) {
                    continue;
                }
                dameMax = this.nFight.get(value);
                idN = conn.player.c.id;
            }
        }
        return idN;
    }

    public void Fight(int id, int dame) {
        if (!this.nFight.containsKey(id)) {
            this.nFight.put(id, dame);
        } else {
            int damenew = this.nFight.get(id);
            damenew += dame;
            this.nFight.replace(id, damenew);
        }
    }

    public void removeFight(int id) {
        if (this.nFight.containsKey(id)) {
            this.nFight.remove(id);
        }
    }

    public boolean isFight(int id) {
        return this.nFight.containsKey(id);
    }

    public void setDisable(boolean isDisable, long timeDisable) {
        this.isDisable = isDisable;
        this.timeDisable = timeDisable;
    }

    public void setDonteMove(boolean isDontMove, long timeDontMove) {
        this.isDontMove = isDontMove;
        this.timeDontMove = timeDontMove;
    }

    public boolean isDisable() {
        return this.isDisable;
    }

    public boolean isDonteMove() {
        return this.isDontMove;
    }

    public void handleAfterCharFight(Char _char) {
        if (this.level > 1) {
            this.tileMap.numMobDie++;
        }
        if (this.templates.id == 0) {
            if (_char.isTaskDanhVong == 1 && _char.taskDanhVong[0] == 6) {
                _char.taskDanhVong[1]++;
                if (_char.c.taskDanhVong[1] == _char.c.taskDanhVong[2]) {
                    _char.p.sendAddchatYellow("Bạn đã hoàn thành nhiệm vụ danh vọng.");
                }
            }
        }
        if (this.templates.id == 230 && this.tileMap.map.bossTuanLoc != null) {
            this.isRefresh = false;
            ItemLeave.leaveItemBOSSTuanLoc(this.tileMap, this, -1);
            _char.pointNoel += 5;
            this.tileMap.mobs.clear();
        } else if (this.tileMap.map.mapLDGT()) {
            if (this.lvboss == 0 && this.templates.id != 81) {
                this.isRefresh = false;
                switch (this.tileMap.map.id) {
                    case 81:
                    case 82:
                    case 83:
                    case 84:
                    case 85:
                    case 86: {
                        if (this.tileMap.mobs.size() - this.tileMap.numMobDie == 1) {
                            this.tileMap.refreshMob(this.tileMap.mobs.size() - 1);
                        }
                        break;
                    }
                    case 87:
                    case 88:
                    case 89: {
                        if (this.tileMap.mobs.size() - this.tileMap.numMobDie == 5) {
                            this.tileMap.refreshMob(this.tileMap.mobs.size() - 5);
                        }
                        break;
                    }
                }
                this.tileMap.map.lanhDiaGiaToc.plusPoint(1);
                this.tileMap.map.lanhDiaGiaToc.clanManager.upExp(50);
            } else if (this.lvboss == 1 && this.templates.id != 81) {
                this.isRefresh = false;
                ItemLeave.leaveChiaKhoa(this.tileMap, this, -1);
                this.tileMap.map.lanhDiaGiaToc.plusPoint(2);
                this.tileMap.map.lanhDiaGiaToc.clanManager.upExp(100);
                if (this.tileMap.map.id >= 87 && this.tileMap.map.id <= 89) {
                    int i2;
                    for (i2 = this.tileMap.mobs.size() - 4; i2 < this.tileMap.mobs.size() - 1; i2++) {
                        this.tileMap.refreshMob(i2);
                    }
                }
            } else if (this.lvboss == 0 && this.templates.id == 81) {
                this.isRefresh = true;
                ItemLeave.leaveLDGT(this.tileMap, this, -1);
            } else if (this.lvboss == 2 && this.templates.id == 82) {
                this.isRefresh = false;
                ItemLeave.leaveYen(this.tileMap, this, -1);
                ItemLeave.leaveYen(this.tileMap, this, -1);
                ItemLeave.leaveYen(this.tileMap, this, -1);
                ItemLeave.leaveYen(this.tileMap, this, -1);
                ItemLeave.leaveYen(this.tileMap, this, -1);
                ItemLeave.leaveLDGT(this.tileMap, this, -1);
                this.tileMap.map.lanhDiaGiaToc.finish();
                this.tileMap.map.lanhDiaGiaToc.clanManager.upExp(300);
                this.tileMap.map.lanhDiaGiaToc.plusPoint(3);
            }
        } else if ((this.templates.id == 98 || this.templates.id == 99) && ChienTruong.chienTruong != null && this.tileMap.map.mapChienTruong()) {
            if (this.templates.id == 98) {
                ChienTruong.pheWin = 1;
            } else if (this.templates.id == 99) {
                ChienTruong.pheWin = 0;
            }
            ChienTruong.chienTruong.finish();
        } else if (this.level > 1) {
            if (this.tileMap.map.cave != null) {
                if (this.isboss) {
                    this.tileMap.map.cave.updatePoint(50);
                } else if (this.lvboss == 2) {
                    this.tileMap.map.cave.updatePoint(20);
                } else if (this.lvboss == 1) {
                    this.tileMap.map.cave.updatePoint(10);
                } else {
                    this.tileMap.map.cave.updatePoint(1);
                }
            } else if (ChienTruong.chienTruong != null && this.tileMap.map.mapChienTruong()) {
                _char.pointCT++;
                if (_char.pointCT > 14000) {
                    _char.pointCT = 14000;
                }
                Service.updatePointCT(_char, 1);
            } else if (this.tileMap.map.giaTocChien != null && this.tileMap.map.mapGTC()) {
                _char.pointGTC++;
                if (_char.pointGTC > 14000) {
                    _char.pointGTC = 14000;
                }
                Service.sendPointGTC(_char, 1);
            }

            if (_char.isTaskHangNgay == 1 && this.templates.id == _char.taskHangNgay[3] && _char.taskHangNgay[0] == 0 && _char.taskHangNgay[1] < _char.taskHangNgay[2]) {
                _char.taskHangNgay[1]++;
                Service.updateTaskOrder(_char, (byte) 0);
            }
            if (_char.isTaskTaThu == 1 && this.templates.id == _char.taskTaThu[3] && this.lvboss == 3 && _char.taskTaThu[0] == 1 && _char.taskTaThu[1] < _char.taskTaThu[2]) {
                _char.taskTaThu[1]++;
                Service.updateTaskOrder(_char, (byte) 1);
            }
            if (_char.isTaskDanhVong == 1 && _char.taskDanhVong[0] == 7 && Math.abs(this.level - _char.get().level) <= 10) {
                _char.taskDanhVong[1]++;
                if (_char.c.taskDanhVong[1] == _char.c.taskDanhVong[2]) {
                    _char.p.sendAddchatYellow("Bạn đã hoàn thành nhiệm vụ danh vọng.");
                }
            }
            int master = this.sortNinjaFight();
            if (this.lvboss == 1) {
                this.tileMap.numTA--;
                if (_char.isTaskDanhVong == 1 && _char.taskDanhVong[0] == 8 && Math.abs(this.level - _char.get().level) <= 10) {
                    _char.taskDanhVong[1]++;
                    if (_char.c.taskDanhVong[1] == _char.c.taskDanhVong[2]) {
                        _char.p.sendAddchatYellow("Bạn đã hoàn thành nhiệm vụ danh vọng.");
                    }
                }
            } else if (this.lvboss == 2) {
                this.tileMap.numTL--;
                if (_char.isTaskDanhVong == 1 && _char.taskDanhVong[0] == 9 && Math.abs(this.level - _char.get().level) <= 10) {
                    _char.taskDanhVong[1]++;
                    if (_char.c.taskDanhVong[1] == _char.c.taskDanhVong[2]) {
                        _char.p.sendAddchatYellow("Bạn đã hoàn thành nhiệm vụ danh vọng.");
                    }
                }
            }

            if (Math.abs(this.level - _char.get().level) <= 10 || this.tileMap.map.LangCo() || this.tileMap.map.mapChienTruong()) {
                if (this.lvboss == 1) {
                    _char.expkm += 1000000;
                    _char.p.sendAddchatYellow("bạn nhận được 1.000.000 exp kinh mạch");
                    _char.p.c.TA += 1;
                    ItemLeave.leaveYen(this.tileMap, this, master);
                } else if (this.lvboss == 2) {
                    _char.expkm += 2000000;
                    _char.p.c.TL += 1;
                    _char.p.sendAddchatYellow("bạn nhận được 2.000.000 exp kinh mạch");
                    ItemLeave.leaveYen(this.tileMap, this, master);
                }
                if (Math.abs(this.level - _char.get().level) <= 10) {
                    if (this.lvboss == 0) {
                        _char.p.upluongMessage(1);

                    } else if (this.lvboss == 1) {
                        _char.p.upluongMessage(2);

                    } else if (this.lvboss == 2) {
                        _char.p.upluongMessage(3);

                    }
                }
                //lượng Kinh Mạch
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 1) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1, 100);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 2) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1, 200);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 3) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1, 300);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 4) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1, 400);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 5) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1, 500);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 6) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10, 600);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 7) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10, 700);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 8) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10, 800);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 9) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10, 1000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 10) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 5000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(100, 1000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 11) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 50000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(1000, 10000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 12) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 60000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(2000, 20000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 13) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 70000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(3000, 70000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 14) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(40000, 80000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(4000, 80000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 15) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(50000, 100000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(5000, 100000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 16) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(60000, 110000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(6000, 110000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 17) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(70000, 120000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(7000, 120000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 18) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(80000, 130000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(8000, 130000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 19) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(90000, 140000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(9000, 140000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvkm == 20) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100000, 150000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;

                        long Xuup = Util.nextInt(10000, 150000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }

                //nhapma
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvnhapma == 10) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 500);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100, 200);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvnhapma == 11) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 600);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100, 400);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvnhapma == 12) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 700);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100, 800);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvnhapma == 13) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 800);
                        _char.p.c.luongVIP += luongUp;
                        _char.p.upluongMessage(luongUp);
                        long Xuup = Util.nextInt(100, 2000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 1;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvnhapma == 14) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 900);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100, 2000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 2;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvnhapma == 15) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 100000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 30000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 3;
                        _char.p.loadPpoint();

                    }
                }

                //honsu
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 5) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 50000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 20000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 6) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 60000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 40000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 7) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 70000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 80000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 8) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 80000);
                        _char.p.c.luongVIP += luongUp;
                        _char.p.upluongMessage(luongUp);
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 1;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 9) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 90000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 2;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 10) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 100000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100000, 300000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 3;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 11) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 50000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 20000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 12) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 60000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 40000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 13) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 70000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 80000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 14) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 80000);
                        _char.p.c.luongVIP += luongUp;
                        _char.p.upluongMessage(luongUp);
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 1;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvhonsu == 15) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100000, 900000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 200;
                        _char.p.loadPpoint();

                    }
                }
                //rank
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 5) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 50000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 20000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 6) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 60000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 40000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 7) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 70000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 80000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 8) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 80000);
                        _char.p.c.luongVIP += luongUp;
                        _char.p.upluongMessage(luongUp);
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 1;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 9) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 90000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 2;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 10) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 100000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100000, 300000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 3;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 11) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 50000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 20000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 12) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 60000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 40000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 13) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 70000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 80000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 14) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 80000);
                        _char.p.c.luongVIP += luongUp;
                        _char.p.upluongMessage(luongUp);
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 1;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 15) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100000, 900000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 200;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 16) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 50000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 20000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 17) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 60000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 40000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 18) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 70000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 80000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 19) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 80000);
                        _char.p.c.luongVIP += luongUp;
                        _char.p.upluongMessage(luongUp);
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 1;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 20) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 90000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 2;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 21) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 100000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100000, 300000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 3;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 22) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 50000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 20000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 23) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 60000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 40000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 24) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 70000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 80000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 25) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 80000);
                        _char.p.c.luongVIP += luongUp;
                        _char.p.upluongMessage(luongUp);
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 1;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 26) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100000, 900000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(100000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 200;
                        _char.p.loadPpoint();

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 27) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 50000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 20000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 28) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 60000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 40000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 29) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 70000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(10000, 80000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvrank == 30) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 80000);
                        _char.p.c.luongVIP += luongUp;
                        _char.p.upluongMessage(luongUp);
                        long Xuup = Util.nextInt(10000, 200000);
                        _char.p.c.upxuMessage(Xuup);
                        _char.p.c.ppoint2 += 1;
                        _char.p.loadPpoint();

                    }
                }

                //luyenthe
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvluyenthe == 15) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(50, 300);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvluyenthe == 16) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 400);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvluyenthe == 17) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 5000);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                        long Xuup = Util.nextInt(1000, 5000);
                        _char.p.c.upxuMessage(Xuup);

                    }
                }

                if (this.tileMap.map.LangCo() && _char.p.c.ItemBody[10].id == 1196) {
                    if (this.lvboss == 0) {
                        _char.p.c.xptieuquy += 1;
                    } else if (this.lvboss == 1) {
                        _char.p.c.xptieuquy += 10;
                    } else if (this.lvboss == 2) {
                        _char.p.c.xptieuquy += 20;
                    }
                }

                //Di hoa
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 14) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 200);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 15) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 300);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 16) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 400);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 17) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 500);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 18) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 600);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 19) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 700);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 20) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 800);
                        long xuUp = Util.nextInt(100, 2000);
                        long tn = Util.nextInt(1, 2);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 21) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 900);
                        long xuUp = Util.nextInt(100, 3000);
                        long tn = Util.nextInt(1, 3);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 22) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 1000);
                        long xuUp = Util.nextInt(100, 4000);
                        long tn = Util.nextInt(1, 4);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 23) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 30000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 24) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 50000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 25) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 26) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 27) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 28) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 29) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 30) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 31) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 31) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 32) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 33) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 34) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 35) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 36) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 37) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 38) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 39) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 40) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 41) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 42) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 43) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 44) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 45) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 46) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 47) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 48) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 49) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvdihoa == 50) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100000, 200000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }

                //khaohach
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 14) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 200);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 15) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 300);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 16) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 400);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 17) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 500);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 18) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 600);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 19) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 700);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 20) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 800);
                        long xuUp = Util.nextInt(100, 2000);
                        long tn = Util.nextInt(1, 2);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 21) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 900);
                        long xuUp = Util.nextInt(100, 3000);
                        long tn = Util.nextInt(1, 3);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 22) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 1000);
                        long xuUp = Util.nextInt(100, 4000);
                        long tn = Util.nextInt(1, 4);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 23) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(10000, 30000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 24) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 50000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 25) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 26) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 27) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 28) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 29) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 30) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 31) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 31) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 32) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 33) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 34) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 35) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 36) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 37) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 38) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 39) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 40) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 41) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 42) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 43) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 44) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 45) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 46) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 47) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 48) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 49) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 50) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100000, 1000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 51) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 52) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 53) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 54) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 55) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 800000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 56) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 800000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 57) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 800000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 58) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 800000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 59) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 800000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 60) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 1000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(100, 500);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 61) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 1000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(100, 500);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 62) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 1000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(010, 500);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 63) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 1000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.lvthan == 64) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000000, 2000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100000, 2000000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(100, 500);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                // hoitho
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 1) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 200);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 2) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 300);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 3) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 400);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 4) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 500);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 5) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 600);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 6) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 700);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 7) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 800);
                        long xuUp = Util.nextInt(100, 2000);
                        long tn = Util.nextInt(1, 2);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 8) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 900);
                        long xuUp = Util.nextInt(100, 3000);
                        long tn = Util.nextInt(1, 3);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 9) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100, 1000);
                        long xuUp = Util.nextInt(100, 4000);
                        long tn = Util.nextInt(1, 4);
                        _char.p.upluongMessage(luongUp);
                        _char.p.c.upxuMessage(xuUp);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 10) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000, 3000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 11) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(3000, 5000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 12) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 30000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 13) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 30000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 14) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 30000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 15) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 30000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 16) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 30000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 17) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 30000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 18) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 40000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 19) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 50000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 20) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 21) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 22) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 23) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 24) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 60000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 25) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 26) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 80000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 27) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 90000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 28) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 29) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 100000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 5000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 30) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(100000, 200000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(50000, 100000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 31) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(3000, 50000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 32) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 300000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 33) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 300000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 34) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 300000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 35) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 300000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 36) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 300000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 37) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 300000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 38) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 400000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 39) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(20000, 500000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 40) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(100, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 41) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 42) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 43) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 44) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 600000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 45) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 800000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 46) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 800000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 47) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(30000, 900000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(10000, 500000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 48) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 1000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 49) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(300000, 1000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(1000, 50000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 50);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                if (Math.abs(this.level - _char.get().level) <= 10 && _char.hoitho == 50) {
                    if (this.lvboss == 0) {
                        long luongUp = Util.nextInt(1000000, 2000000);
                        _char.p.upluongMessage(luongUp);
                        long xuUp = Util.nextInt(500000, 1000000);
                        _char.p.c.upxuMessage(xuUp);
                        long tn = Util.nextInt(10, 500);
                        _char.p.c.ppoint2 += tn;
                        _char.p.loadPpoint();
                        _char.p.c.luongVIP += luongUp;
                    }
                }
                //
                if (Server.manager.event != 0) {
                    ItemLeave.leaveItemSuKien(this.tileMap, this, master);
                }
                switch ((int) Util.nextInt(1, 2)) {
                    case 1: {
                        if (this.lvboss == 0 && Util.nextInt(10) < 1) {
                            ItemLeave.leaveYen(this.tileMap, this, master);
                        }
                        break;
                    }
                    case 2: {
                        if (Util.nextInt(10) < 8) {
                            ItemLeave.leaveItemOrther(this.tileMap, this, master);
                        }
                        break;
                    }

                }
            }

            if (this.tileMap.map.id == 173 && _char.vip == 2) {
                if (this.lvboss == 0) {
                    long expUp = Util.nextInt(30000, 80000);
                    _char.p.c.exphoitho += (expUp);
                    _char.p.c.expkm += (expUp);
                    _char.p.upluongMessage(expUp);
                    _char.p.c.expsinhcon += (expUp);
                }
            }
            if (this.tileMap.map.id == 174 && _char.vip == 3) {
                if (this.lvboss == 0) {
                    long expUp = Util.nextInt(50000, 100000);
                    _char.p.c.exphoitho += (expUp);
                    _char.p.c.expkm += (expUp);
                    _char.p.upluongMessage(expUp);
                    _char.p.c.expsinhcon += (expUp);
                }
            }
            if (this.tileMap.map.id == 175 && _char.vip == 4) {
                if (this.lvboss == 0) {
                    long expUp = Util.nextInt(80000, 150000);
                    _char.p.c.exphoitho += (expUp);
                    _char.p.c.expkm += (expUp);
                    _char.p.c.expthan += (expUp);
                    _char.p.c.exphonsu += (expUp);
                    _char.p.upluongMessage(expUp);
                    _char.p.c.expsinhcon += (expUp);
                }
            }
            if (this.tileMap.map.id == 176 && _char.vip == 5) {
                if (this.lvboss == 0) {
                    long expUp = Util.nextInt(100000, 200000);
                    _char.p.c.exphoitho += (expUp);
                    _char.p.c.expkm += (expUp);
                    _char.p.c.exphonsu += (expUp);
                    _char.p.c.expthan += (expUp);
                    _char.p.upluongMessage(expUp);
                    _char.p.c.expsinhcon += (expUp);
                }
            }
            if (this.tileMap.map.id == 179 && _char.vip == 20) {
                if (this.lvboss == 0) {
                    long expUp = Util.nextInt(150000, 300000);
                    _char.p.c.exphoitho += (expUp);
                    _char.p.c.expkm += (expUp);
                    _char.p.c.exphonsu += (expUp);
                    _char.p.c.expthan += (expUp);
                    _char.p.upluongMessage(expUp);
                    _char.p.c.upxuMessage(expUp);
                    _char.p.c.expsinhcon += (expUp);
                }
            }
            if (this.tileMap.map.id == 180 && _char.vip == 100) {
                if (this.lvboss == 0) {
                    long expUp = Util.nextInt(1000000, 2000000);
                    _char.p.c.exphoitho += (expUp);
                    _char.p.c.expkm += (expUp);
                    _char.p.c.exphonsu += (expUp);
                    _char.p.c.exprank += (expUp);
                    _char.p.c.expthan += (expUp);
                    _char.p.upluongMessage(expUp);
                    _char.p.c.upxuMessage(expUp);
                    _char.p.c.expsinhcon += (expUp);
                }
            }
            if (this.tileMap.map.id == 172 && _char.vip == 1) {
                if (this.lvboss == 0) {
                    long expUp = Util.nextInt(40000, 60000);
                    _char.p.c.exphoitho += (expUp);
                    _char.p.c.expkm += (expUp);
                    _char.p.upluongMessage(expUp);
                    _char.p.c.expsinhcon += (expUp);
                }
            }

            if (this.tileMap.map.id == 174 && _char.vip == 3) {
                ItemLeave.randomLeavevip(this.tileMap, this, master, (int) Util.nextInt(1, 2), 0);
            }
            if (this.tileMap.map.id == 175 && _char.vip == 4) {
                ItemLeave.randomLeavevip4(this.tileMap, this, master, (int) Util.nextInt(1, 2), 0);
            }
            if (this.tileMap.map.id == 176 && _char.vip == 5) {
                ItemLeave.randomLeavevip5(this.tileMap, this, master, (int) Util.nextInt(1, 2), 0);
            }
            if (this.tileMap.map.id == 179 && _char.vip == 20) {
                ItemLeave.randomLeavevip20(this.tileMap, this, master, (int) Util.nextInt(1, 2), 0);
            }
            if (this.tileMap.map.id == 180 && _char.vip == 100) {
                ItemLeave.randomLeavevip100(this.tileMap, this, master, (int) Util.nextInt(1, 2), 0);
            }
            if (this.tileMap.map.id == 112 && _char.vip >= 3) {
                ItemLeave.randomLeavenlxd(this.tileMap, this, master, (int) Util.nextInt(1, 2), 0);
            }

            if (this.tileMap.map.VDMQ() && (_char.get().getEffId(40) != null || _char.get().getEffId(41) != null) && Math.abs(this.level - _char.get().level) <= 10) {
                ItemLeave.randomLeave(this.tileMap, this, master, (int) Util.nextInt(1, 2), 0);
                long luongUp = Util.nextInt(100, 500);
                _char.p.upluongMessage(luongUp);

            } else if (this.tileMap.map.LangCo()) {
                ItemLeave.randomLeave(this.tileMap, this, master, (int) Util.nextInt(1, 3), 1);
                long luongUp = Util.nextInt(100, 1000);
                _char.p.upluongMessage(luongUp);

                if (this.lvboss == 2) {
                    ItemLeave.leaveTTTT(this.tileMap, this, master);
                }
            }

            if (this.isboss) {
                if (this.tileMap.map.cave == null) {
                    _char.expkm += 3000;
                    _char.p.sendAddchatYellow("bạn nhận được 3000 exp kinh mạch");
                    _char.p.c.Boss += 1;
                    Service.chatKTG(_char.name + " đã tiêu diệt " + this.templates.name);
                    int i;
                    for (i = 0; i < 10; i++) {
                        ItemLeave.leaveYen(this.tileMap, this, master);
                    }
                    ItemLeave.leaveItemBOSS(this.tileMap, this, master);
                    int coinReward = Util.nextInt(10000, 50001);
                    _char.p.coin += coinReward;
                    _char.p.sendAddchatYellow("Bạn nhận được " + coinReward + " coin");
                    int vndReward = Util.nextInt(5000, 20001);
                    _char.p.c.vnd += vndReward;
                    _char.p.sendAddchatYellow("Bạn nhận được " + vndReward + " VND");
                } else if (this.tileMap.map.cave != null && this.tileMap.map.getXHD() == 9 && ((this.tileMap.map.id == 157 && this.tileMap.map.cave.level == 0) || (this.tileMap.map.id == 158 && this.tileMap.map.cave.level == 1) || (this.tileMap.map.id == 159 && this.tileMap.map.cave.level == 2)) && Util.nextInt(3) < 3) {
                    ItemLeave.leaveYen(this.tileMap, this, master);
                    ItemLeave.leaveYen(this.tileMap, this, master);
                    this.tileMap.map.cave.updatePoint(this.tileMap.mobs.size());
                    short k2;
                    Mob var12;
                    for (k2 = 0; k2 < this.tileMap.mobs.size(); k2++) {
                        if (this.tileMap.mobs.get(k2) == null) {
                            continue;
                        }
                        var12 = this.tileMap.mobs.get(k2);
                        if (!var12.isDie) {
                            var12.updateHP(-var12.hpmax, _char.id, true);
                        }
                        var12.isRefresh = false;
                        short h;
                        for (h = 0; h < this.tileMap.players.size(); h++) {
                            Service.setHPMob(this.tileMap.players.get(h).c, var12.id, 0);
                        }
                    }
                    this.tileMap.map.cave.level++;
                }
            }

            if (this.tileMap.map.cave != null && this.tileMap.map.getXHD() < 9) {
                this.isRefresh = false;
                if (this.tileMap.numMobDie == this.tileMap.mobs.size()) {
                    if (this.tileMap.map.getXHD() == 5) {
                        if (this.tileMap.map.id == 105) {
                            this.tileMap.map.cave.openMap();
                            this.tileMap.map.cave.openMap();
                            this.tileMap.map.cave.openMap();
                        } else if (this.tileMap.map.id != 106 && this.tileMap.map.id != 107 && this.tileMap.map.id != 108) {
                            this.tileMap.map.cave.openMap();
                        } else {
                            this.tileMap.map.cave.finsh++;
                            if (this.tileMap.map.cave.finsh >= 3) {
                                this.tileMap.map.cave.openMap();
                            }
                        }
                    } else if (this.tileMap.map.getXHD() == 6 && this.tileMap.map.id == 116) {
                        if (this.tileMap.map.cave.finsh == 0) {
                            this.tileMap.map.cave.openMap();
                        } else {
                            this.tileMap.map.cave.finsh++;
                        }
                        this.tileMap.numMobDie = 0;
                        short l2;
                        for (l2 = 0; l2 < this.tileMap.mobs.size(); l2++) {
                            this.tileMap.refreshMob(l2);
                        }
                    } else {
                        this.tileMap.map.cave.openMap();
                    }
                }
            }
        }
    }
}
