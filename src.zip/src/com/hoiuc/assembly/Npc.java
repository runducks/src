package com.hoiuc.assembly;
//Scr By SHIN
public class Npc {
    public byte type;
    public short x;
    public short y;
    public byte id;
}
