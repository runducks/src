package com.hoiuc.io;
//Scr By Truongbk
public interface ISession {
    boolean isConnected();
//Scr By Truongbk
    void sendMessage(Message message);

    void close();
}
