package com.hoiuc.io;
//Scr By Truongbk
import com.hoiuc.server.Session;
//Scr By Truongbk
public interface IMessageHandler {
    void processMessage(Session var1, Message var2);

    void onConnectionFail(Session var1);

    void onDisconnected(Session var1);

    void onConnectOK(Session var1);
}
